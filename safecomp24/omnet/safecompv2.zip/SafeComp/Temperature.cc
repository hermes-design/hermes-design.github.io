#include <string.h>
#include <string>
#include <omnetpp.h>
#include <sstream>
#include <random>
    #include <omnetpp.h>

    using namespace omnetpp;

    using namespace std;

    class Temperature : public cSimpleModule
    {
    public:
        Temperature();
    private:
                cMessage*  TRIGGER;
                cMessage*  TRANSMIT;
                int pld; //generated payload
                double lambda;  // Rate parameter for the exponential distribution
                std::default_random_engine generator;
                std::exponential_distribution<double> distribution;
                std::vector<std::string> extractSubstrings(const std::string& inputString);
                void transmit(int pld);
      protected:
                // The following redefined virtual function holds the algorithm.
                virtual void initialize() override;
                virtual void handleMessage(cMessage *msg) override;
    };


    Define_Module(Temperature);


    Temperature::Temperature() {
        lambda = 0.5;
    }

    void Temperature::initialize()
    {
        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);
    }
    void Temperature::handleMessage(cMessage *msg)
    {
        pld=intuniform(0, 100);
        transmit(pld);

        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);

    }

    void Temperature::transmit(int pld)
    {
        std::string result = std::string("TRANSMIT/TM/") + std::string(std::to_string(pld));
        TRANSMIT = new cMessage(result.c_str());
        send(TRANSMIT, "TemperatureData"); // send out the message
    }
