#include <string.h>
#include <string>
#include <omnetpp.h>
#include <sstream>
#include <random>
    using namespace omnetpp;

    /**
     * Derive the Txc1 class from cSimpleModule. In the Tictoc1 network,
     * both the `tic' and `toc' modules are Txc1 objects, created by OMNeT++
     * at the beginning of the simulation.
     */
    class Ph : public cSimpleModule
    {
    public:
        Ph();
    private:
        cMessage*  TRIGGER;
        cMessage*  TRANSMIT;
        //cMessage*  PUSH;
        int pld; //generated payload
        int pldc; //collected payload
        double lambda;  // Rate parameter for the exponential distribution
        std::default_random_engine generator;
        std::exponential_distribution<double> distribution;
        std::vector<std::string> extractSubstrings(const std::string& inputString);

        void transmit(int pld);
protected:
        // The following redefined virtual function holds the algorithm.
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;

    };

    // The module class needs to be registered with OMNeT++
    Define_Module(Ph);


    Ph::Ph() {
        lambda = 0.5;
        pldc=0;
        pld =0;
    }

    void Ph::initialize()
    {
        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);
    }

    /**
     * Send push messages
     */

    void Ph::handleMessage(cMessage *msg)
    {
        EV << "Received PHC " << msg->getName()  << endl;
        std::string s = msg->getName();

        bool isFound = s.find("TRANSMIT") != std::string::npos;

        if(isFound){
            pldc=0;
            std::vector<std::string> extractedSubstrings = extractSubstrings( msg->getName());
            std::string PLD = extractedSubstrings[2];
            pldc = std::stoi(PLD);
        }else{
            pld=intuniform(1, 10)+pldc;
            pldc=0;
            transmit(pld);
        }



        TRIGGER = new cMessage();
        double interval = distribution(generator, std::exponential_distribution<double>::param_type(lambda));
        scheduleAt(simTime() + interval, TRIGGER);

    }

    void Ph::transmit(int pld)
    {

        std::string result = std::string("TRANSMIT/PH/") + std::string(std::to_string(pld));
        TRANSMIT = new cMessage(result.c_str());
        send(TRANSMIT, "PhData"); // send out the message


    }

    std::vector<std::string> Ph::extractSubstrings(const std::string& inputString) {
        std::vector<std::string> substrings;
        std::istringstream iss(inputString);
        std::string substring;

        while (std::getline(iss, substring, '/')) {
            substrings.push_back(substring);
        }

        return substrings;
    }
