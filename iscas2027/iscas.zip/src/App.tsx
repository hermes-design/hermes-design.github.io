/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import rawData from './data.json';
import { ResearchData } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SystemParametersSection } from './components/SystemParametersSection';
import { PrismModelSection } from './components/PrismModelSection';
import { GnuRadioSection } from './components/GnuRadioSection';
import { PythonArtifactsSection } from './components/PythonArtifactsSection';
import { UsageInstructionsSection } from './components/UsageInstructionsSection';
import { Footer } from './components/Footer';
import { ArtifactDownloadModal } from './components/ArtifactDownloadModal';

const data = rawData as unknown as ResearchData;

export default function App() {
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  const showSystemParameters =
    data.systemParameters?.showSystemParameters ??
    data.systemParameters?.show ??
    data.paper?.showSystemParameters ??
    true;

  return (
    <div className="min-h-screen bg-gray-50 text-slate-800 font-sans antialiased selection:bg-slate-200 selection:text-slate-900 flex flex-col">
      {/* Navigation Bar */}
      <Navbar
        title={data.paper.shortTitle || `${data.paper.conferenceShort} Artifacts`}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
        showSystemParameters={showSystemParameters}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Abstract & Hero Section */}
        <Hero
          paper={data.paper}
          data={data}
          onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
        />

        {/* Content Container */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 py-12">
          {/* Section 1: System Parameters */}
          {showSystemParameters && (
            <SystemParametersSection parameters={data.systemParameters} />
          )}

          {/* Section 2: Formal Verification Model (PRISM Artifacts) */}
          <PrismModelSection data={data.prismArtifacts} />

          {/* Section 3: GNU Radio SDR Artifacts */}
          <GnuRadioSection data={data.sdrArtifacts} />

          {/* Section 4: Python Artifacts */}
          <PythonArtifactsSection data={data.pythonArtifacts} />

          {/* Section 5: Usage Instructions */}
          <UsageInstructionsSection usage={data.usageInstructions} />
        </div>
      </main>

      {/* Footer */}
      <Footer
        title={`${data.paper.conferenceShort || 'Conference'} Research Artifacts`}
        footerText={data.footer.text}
        projectFramework={data.paper.projectFramework}
        projectUrl={data.paper.projectUrl}
        partners={data.footer.partners}
      />

      {/* Artifact Download Dialog */}
      <ArtifactDownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        data={data}
      />
    </div>
  );
}
