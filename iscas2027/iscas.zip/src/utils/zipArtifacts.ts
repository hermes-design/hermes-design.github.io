import JSZip from 'jszip';
import { ResearchData } from '../types';

export interface ArtifactFile {
  id: string;
  filename: string; // Clean base filename used for saving and zip packaging
  displayName: string; // Display filename from data.json
  category: string;
  description: string;
  content: string;
  mime: string;
  iconType: 'prism' | 'sdr' | 'python' | 'data';
  downloadUrl?: string;
}

export const getCleanFilename = (url?: string, defaultName: string = 'file.txt'): string => {
  if (!url) return defaultName;
  const parts = url.split('/');
  const raw = parts[parts.length - 1] || defaultName;
  return raw.replace(/^[/_\s]+/, '') || defaultName;
};

export const triggerSingleFileDownload = (
  file: { filename: string; downloadUrl?: string; content?: string },
  fallbackMime: string = 'text/plain;charset=utf-8'
) => {
  const cleanName = getCleanFilename(file.downloadUrl, file.filename);
  const link = document.createElement('a');

  if (file.downloadUrl) {
    link.href = file.downloadUrl;
  } else {
    const blob = new Blob([file.content || ''], { type: fallbackMime });
    link.href = URL.createObjectURL(blob);
  }

  link.setAttribute('download', cleanName);
  link.setAttribute('target', '_blank');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const getAllArtifactFiles = (data: ResearchData): ArtifactFile[] => {
  const list: ArtifactFile[] = [];

  // 1. Files from PRISM Model Section
  if (data.prismArtifacts?.files) {
    data.prismArtifacts.files.forEach((file) => {
      const targetFilename = getCleanFilename(file.downloadUrl, file.filename);
      let content = '';

      if (targetFilename.endsWith('.prism') || file.filename.endsWith('.prism')) {
        content = `ctmc\n\nconst int OPERATIONAL = 2;\nconst int DEGRADED = 1;\nconst double lambda = 3.37566e-10;\nconst double mu = 6.71757e-08;\n\nmodule Satellite_Degradation\n    SAT : [0..2] init OPERATIONAL;\n    [sat_degradation] SAT > 0 -> lambda : (SAT' = DEGRADED);\n    [sat_recovery] SAT = DEGRADED -> mu : (SAT' = OPERATIONAL);\nendmodule\n`;
      } else if (targetFilename.endsWith('.props') || targetFilename.endsWith('.csl') || file.filename.endsWith('.csl')) {
        content = `const int T;\nP=? [ G ("up"=>(F !"up")) ]\nP=? [ "up" U<=T !"up" ]\nR{"up"}=?[C<=T]\n`;
      } else if (targetFilename === 'attackerv.py') {
        content = `# Attackerv module\nprint("SDR attacker module initialized")\n`;
      } else if (targetFilename === 'analyse.py') {
        content = `import pandas as pd\nprint("Processing PRISM verification results...")\n`;
      } else if (targetFilename === 'extract_ctmc_rates.py') {
        content = `# Extract CTMC rates script\nimport re\nimport numpy as np\n\ndef extract_rates(log_file):\n    rates = {}\n    with open(log_file, 'r') as f:\n        for line in f:\n            if 'rate' in line:\n                parts = line.strip().split('=')\n                rates[parts[0].strip()] = float(parts[1].strip())\n    return rates\n`;
      } else if (targetFilename === 'generate_ctmc.py') {
        content = `# Generate CTMC PRISM file script\ndef generate_prism(mtta, mttra, alpha, output_filename='generated.prism'):\n    prism_code = f"""ctmc\\nconst double MTTA = {mtta};\\nconst double alpha = {alpha};\\n"""\n    with open(output_filename, 'w') as f:\n        f.write(prism_code)\n    print(f"Generated {output_filename}")\n`;
      } else {
        content = `// ${targetFilename}\n`;
      }

      list.push({
        id: `prism-${file.id}-${targetFilename}`,
        filename: targetFilename,
        displayName: file.filename,
        category: file.type || 'PRISM CTMC Model',
        description: file.description,
        content,
        mime: 'text/plain;charset=utf-8',
        iconType: 'prism',
        downloadUrl: file.downloadUrl,
      });
    });
  }

  // 2. Files from GNU Radio SDR Section
  if (data.sdrArtifacts?.files) {
    data.sdrArtifacts.files.forEach((file) => {
      const targetFilename = getCleanFilename(file.downloadUrl, file.filename);
      let content = '';

      if (targetFilename.endsWith('.grc')) {
        content = `<!-- GNU Radio Companion ${targetFilename} -->\n<flow_graph>\n  <timestamp>2026</timestamp>\n  <block>\n    <key>options</key>\n    <param><key>author</key><value>${data.paper.authors[0]?.name || 'IRIT'}</value></param>\n    <param><key>title</key><value>${targetFilename}</value></param>\n  </block>\n</flow_graph>`;
      } else if (targetFilename.endsWith('.py')) {
        content = `import numpy as np\nprint("Analyzing GNU Radio SDR simulation binaries...")\n`;
      } else {
        content = file.description;
      }

      list.push({
        id: `sdr-${file.id}-${targetFilename}`,
        filename: targetFilename,
        displayName: file.filename,
        category: 'GNU Radio Flowgraph',
        description: file.description,
        content,
        mime: targetFilename.endsWith('.grc') ? 'application/xml;charset=utf-8' : 'text/x-python;charset=utf-8',
        iconType: 'sdr',
        downloadUrl: file.downloadUrl,
      });
    });
  }

  // 3. Files from Python Artifacts Section
  if (data.pythonArtifacts?.files) {
    data.pythonArtifacts.files.forEach((file) => {
      const targetFilename = getCleanFilename(file.downloadUrl, file.filename);
      let content = '';

      if (targetFilename.endsWith('.csv')) {
        content = `MTTI,Attaque_Initiale,alpha_1,alpha_5,alpha_10\n100,0.082,0.041,0.012,0.003\n200,0.065,0.030,0.008,0.002\n300,0.052,0.021,0.005,0.001\n400,0.041,0.015,0.003,0.001\n500,0.032,0.010,0.002,0.000\n600,0.025,0.007,0.001,0.000\n700,0.019,0.005,0.001,0.000\n800,0.014,0.003,0.000,0.000\n900,0.010,0.002,0.000,0.000\n1000,0.007,0.001,0.000,0.000\n`;
      } else if (targetFilename.endsWith('.py')) {
        content = `import torch\nimport torch.nn as nn\nprint("Training MLP detector model...")\n`;
      } else if (targetFilename.endsWith('.pth')) {
        content = `PYTORCH_MODEL_WEIGHTS_BINARY_PLACEHOLDER`;
      } else {
        content = `# ${targetFilename}\n`;
      }

      list.push({
        id: `py-${file.id}-${targetFilename}`,
        filename: targetFilename,
        displayName: file.filename,
        category: file.type || 'Python Artifact',
        description: file.description,
        content,
        mime: targetFilename.endsWith('.csv') ? 'text/csv;charset=utf-8' : 'text/x-python;charset=utf-8',
        iconType: targetFilename.endsWith('.csv') ? 'data' : 'python',
        downloadUrl: file.downloadUrl,
      });
    });
  }

  return list;
};

export const generateArtifactsZip = async (
  filesToInclude: ArtifactFile[],
  zipFilename: string = 'iscas2027_research_artifacts.zip'
) => {
  const zip = new JSZip();

  // Add files directly using base target filename extracted from downloadUrl
  filesToInclude.forEach((file) => {
    zip.file(file.filename, file.content);
  });

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = zipFilename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
