import React, { useState } from 'react';
import { ResearchData } from '../types';
import { Code2, Download, Check, FileText } from 'lucide-react';
import { triggerSingleFileDownload } from '../utils/zipArtifacts';

interface PythonArtifactsProps {
  data: ResearchData['pythonArtifacts'];
}

export const PythonArtifactsSection: React.FC<PythonArtifactsProps> = ({ data }) => {
  const [downloadedFile, setDownloadedFile] = useState<string | null>(null);

  const handleDownload = (file: { filename: string; downloadUrl?: string }, content: string) => {
    triggerSingleFileDownload({ filename: file.filename, downloadUrl: file.downloadUrl, content }, 'text/x-python;charset=utf-8');
    setDownloadedFile(file.filename);
    setTimeout(() => setDownloadedFile(null), 2000);
  };

  const getFileContent = (filename: string) => {
    if (filename === 'analyse_prism.py') return data.prismAnalyseCode;
    if (filename === 'analyse_sdr.py') return data.sdrAnalyseCode;
    if (filename === 'satcom_jamming_mlp.py' || filename === 'train_mlp_detector.py') return data.mlpCode;
    return '# Python artifact script\nprint("Executing python artifact...")\n';
  };

  return (
    <section id="python" className="scroll-mt-24 py-12 border-b border-slate-200">
      <div className="flex items-center mb-8">
        <div className="bg-slate-900 p-2.5 rounded-lg shadow-sm mr-4 text-white">
          <Code2 className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-slate-950">{data.title}</h2>
          <p className="text-slate-600 mt-1 text-sm sm:text-base">
            {data.subtitle}{data.description && data.description.trim() ? ` — ${data.description.trim()}` : ''}
          </p>
        </div>
      </div>

      {/* Artifact Files List from data.json */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-6 sm:p-8">
        <h3 className="text-lg font-serif font-bold text-slate-900 mb-4 flex items-center">
          <FileText className="w-5 h-5 mr-2 text-slate-700" />
          <span>Configured Python Artifact Files</span>
        </h3>

        <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-mono font-medium text-slate-500 uppercase tracking-wider">
                    Filename
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-mono font-medium text-slate-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-mono font-medium text-slate-500 uppercase tracking-wider hidden sm:table-cell">
                    Description
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-mono font-medium text-slate-500 uppercase tracking-wider">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {data.files.map((file) => {
                  const isDownloaded = downloadedFile === file.filename;
                  const fileContent = getFileContent(file.filename);

                  return (
                    <tr key={file.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-mono font-semibold text-slate-900">
                        <div className="flex items-center gap-2">
                          <span>{file.filename}</span>
                          <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-xs border border-slate-200 font-mono">
                            {file.version}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-600">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800 border border-slate-200">
                          {file.type}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-600 hidden sm:table-cell max-w-md leading-relaxed">
                        {file.description}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => handleDownload(file, fileContent)}
                          className="text-slate-900 hover:text-slate-950 inline-flex items-center bg-slate-100 hover:bg-slate-200 border border-slate-300 px-3 py-1.5 rounded-md transition-colors text-xs font-medium cursor-pointer shadow-2xs"
                        >
                          {isDownloaded ? (
                            <>
                              <Check className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                              <span className="text-emerald-700 font-semibold">Downloaded</span>
                            </>
                          ) : (
                            <>
                              <Download className="w-3.5 h-3.5 mr-1.5" />
                              <span>Download</span>
                            </>
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};
