import React, { useState, useEffect } from 'react';
import { Menu, X, ShieldAlert } from 'lucide-react';

interface NavbarProps {
  title?: string;
  onOpenDownloadModal: () => void;
  showSystemParameters?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  title = 'ISCAS Artifacts',
  onOpenDownloadModal,
  showSystemParameters = true,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Abstract', href: '#abstract' },
    ...(showSystemParameters ? [{ label: 'System Parameters', href: '#parameters' }] : []),
    { label: 'PRISM Code', href: '#prism' },
    { label: 'GNU Radio SDR', href: '#gnuradio' },
    { label: 'Python Artifacts', href: '#python' },
    { label: 'Usage Guide', href: '#guide' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/90 backdrop-blur-md shadow-xs border-b border-slate-200 py-3'
          : 'bg-white border-b border-slate-200 py-4'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        {/* Brand */}
        <a href="#abstract" className="flex items-center space-x-2 text-slate-950 font-serif font-bold text-lg tracking-tight">
          <ShieldAlert className="w-5 h-5 text-slate-900" />
          <span>{title}</span>
        </a>

        {/* Nav Links */}
        <div className="hidden md:flex items-center space-x-6">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-xs font-mono font-medium text-slate-600 hover:text-slate-950 transition-colors"
            >
              {link.label}
            </a>
          ))}

          <button
            onClick={onOpenDownloadModal}
            className="px-3 py-1.5 text-xs font-mono font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
          >
            <span>Download Artifacts (.zip)</span>
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden flex items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-slate-600 hover:text-slate-900 focus:outline-none p-1"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white border-b border-slate-200 shadow-lg">
          <div className="px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block text-sm font-mono text-slate-700 hover:text-slate-950 hover:bg-slate-50 px-3 py-2 rounded-md"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};
