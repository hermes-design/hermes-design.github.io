import React, { useState } from 'react';
import { Partner } from '../types';

interface FooterProps {
  footerText: string;
  projectFramework?: string;
  projectUrl?: string;
  partners: Partner[];
  title?: string;
}

export const Footer: React.FC<FooterProps> = ({
  footerText,
  projectFramework,
  projectUrl,
  partners,
  title = 'Research Artifacts',
}) => {
  const [logoErrors, setLogoErrors] = useState<Record<string, boolean>>({});

  const handleImageError = (partnerName: string) => {
    setLogoErrors((prev) => ({ ...prev, [partnerName]: true }));
  };

  // Filter out partners deleted in UI selection (NEWCAS, ICO)
  const filteredPartners = partners.filter((p) => p.name !== 'NEWCAS' && p.name !== 'ICO');

  return (
    <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <p className="font-semibold text-white mb-2 text-base font-serif">
            {title}
          </p>
          <p className="text-sm text-slate-400 leading-relaxed max-w-lg">
            {footerText}
            {projectFramework && (
              <span className="block mt-2">
                Developed under the framework of the{' '}
                {projectUrl ? (
                  <a
                    href={projectUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:text-blue-300 transition-colors font-medium hover:underline underline-offset-4"
                  >
                    {projectFramework}
                  </a>
                ) : (
                  <span className="font-medium text-slate-300">{projectFramework}</span>
                )}
                , these resources are intended for academic review and scientific reproducibility.
              </span>
            )}
          </p>
        </div>

        <div className="flex flex-row md:justify-end items-center gap-4 sm:gap-6 flex-wrap">
          {filteredPartners.map((partner) => (
            <a
              key={partner.name}
              href={partner.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block h-14 sm:h-16 group transition-opacity hover:opacity-90"
              title={partner.title || `Visit ${partner.name} Website`}
            >
              {!logoErrors[partner.name] && partner.logo ? (
                <img
                  src={partner.logo}
                  alt={partner.alt || `${partner.name} Logo`}
                  onError={() => handleImageError(partner.name)}
                  referrerPolicy="no-referrer"
                  style={{ backgroundColor: partner.bgColor || '#ffffff' }}
                  className="h-full w-auto rounded shadow-md p-1.5 object-contain border border-slate-700"
                />
              ) : (
                <div
                  style={{ backgroundColor: partner.bgColor || '#1e293b' }}
                  className="h-full px-4 py-2 rounded border border-slate-700 flex items-center justify-center text-xs font-mono font-bold text-white shadow-sm"
                >
                  {partner.name}
                </div>
              )}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
};
