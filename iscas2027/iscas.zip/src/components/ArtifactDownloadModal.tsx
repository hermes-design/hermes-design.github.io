import React, { useState, useMemo } from 'react';
import { ResearchData } from '../types';
import {
  X,
  Download,
  Binary,
  Radio,
  Code2,
  Check,
  PackageCheck,
  FileText,
  Database,
  CheckSquare,
  Square,
  Archive,
  Loader2,
} from 'lucide-react';
import {
  getAllArtifactFiles,
  generateArtifactsZip,
  triggerSingleFileDownload,
  ArtifactFile,
} from '../utils/zipArtifacts';

interface ArtifactDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: ResearchData;
}

export const ArtifactDownloadModal: React.FC<ArtifactDownloadModalProps> = ({
  isOpen,
  onClose,
  data,
}) => {
  const allFiles = useMemo(() => getAllArtifactFiles(data), [data]);
  
  // Default: All files selected
  const [selectedIds, setSelectedIds] = useState<Set<string>>(
    () => new Set(allFiles.map((f) => f.id))
  );
  const [downloadedSingleItem, setDownloadedSingleItem] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);

  if (!isOpen) return null;

  const toggleSelectAll = () => {
    if (selectedIds.size === allFiles.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(allFiles.map((f) => f.id)));
    }
  };

  const toggleFileSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const downloadSingleFile = (file: ArtifactFile) => {
    triggerSingleFileDownload({ filename: file.filename, downloadUrl: file.downloadUrl, content: file.content }, file.mime);
    setDownloadedSingleItem(file.filename);
    setTimeout(() => setDownloadedSingleItem(null), 2500);
  };

  const handleDownloadSelectedZip = async () => {
    const filesToZip = allFiles.filter((f) => selectedIds.has(f.id));
    if (filesToZip.length === 0) return;

    setIsZipping(true);
    try {
      await generateArtifactsZip(
        filesToZip,
        filesToZip.length === allFiles.length
          ? 'iscas2027_all_artifacts.zip'
          : 'iscas2027_selected_artifacts.zip'
      );
    } catch (err) {
      console.error('Failed to create ZIP package:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const handleDownloadAllZip = async () => {
    // Select all first
    setSelectedIds(new Set(allFiles.map((f) => f.id)));
    setIsZipping(true);
    try {
      await generateArtifactsZip(allFiles, 'iscas2027_all_artifacts.zip');
    } catch (err) {
      console.error('Failed to create ZIP package:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const renderIcon = (type: ArtifactFile['iconType']) => {
    switch (type) {
      case 'prism':
        return <Binary className="w-4 h-4 text-blue-600" />;
      case 'sdr':
        return <Radio className="w-4 h-4 text-purple-600" />;
      case 'python':
        return <Code2 className="w-4 h-4 text-emerald-600" />;
      case 'data':
      default:
        return <Database className="w-4 h-4 text-amber-600" />;
    }
  };

  const isAllSelected = selectedIds.size === allFiles.length;
  const isNoneSelected = selectedIds.size === 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div
        className="bg-white rounded-2xl max-w-3xl w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
          <div>
            <h3 className="font-serif text-lg font-bold text-slate-950 flex items-center gap-2">
              <Archive className="w-5 h-5 text-slate-900" />
              <span>Download Research Artifacts (.zip)</span>
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Select files below to bundle into a standard <code className="font-mono bg-slate-200 px-1 py-0.5 rounded text-[11px]">.zip</code> archive or download individually.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar / Selection bar */}
        <div className="px-6 py-3 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between text-xs shrink-0">
          <button
            onClick={toggleSelectAll}
            className="flex items-center gap-2 text-slate-800 font-medium hover:text-slate-950 transition-colors cursor-pointer"
          >
            {isAllSelected ? (
              <CheckSquare className="w-4 h-4 text-slate-900" />
            ) : (
              <Square className="w-4 h-4 text-slate-500" />
            )}
            <span>
              {isAllSelected ? 'Deselect All' : 'Select All Files'}
            </span>
          </button>

          <span className="font-mono text-slate-600 font-semibold">
            {selectedIds.size} of {allFiles.length} selected for ZIP
          </span>
        </div>

        {/* Artifacts List */}
        <div className="p-6 overflow-y-auto space-y-3 divide-y divide-slate-100 flex-1">
          {allFiles.map((file) => {
            const isSelected = selectedIds.has(file.id);
            const isSaved = downloadedSingleItem === file.filename;

            return (
              <div
                key={file.id}
                className={`pt-3 first:pt-0 flex items-start justify-between gap-4 p-2 rounded-lg transition-colors ${
                  isSelected ? 'bg-slate-50/80' : 'hover:bg-slate-50/40'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Selection Checkbox */}
                  <button
                    onClick={() => toggleFileSelect(file.id)}
                    className="mt-1 text-slate-600 hover:text-slate-950 transition-colors cursor-pointer"
                    aria-label={`Select ${file.filename} for ZIP`}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-4.5 h-4.5 text-slate-900" />
                    ) : (
                      <Square className="w-4.5 h-4.5 text-slate-400" />
                    )}
                  </button>

                  <div className="p-2 bg-slate-100 rounded-lg shrink-0 mt-0.5">
                    {renderIcon(file.iconType)}
                  </div>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-bold text-slate-900">
                        {file.filename}
                      </span>
                      <span className="text-[10px] font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                        {file.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5 leading-snug">
                      {file.description}
                    </p>
                  </div>
                </div>

                {/* Individual Download */}
                <button
                  onClick={() => downloadSingleFile(file)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 rounded-md transition-colors shrink-0 shadow-2xs cursor-pointer"
                  title={`Download single file ${file.filename}`}
                >
                  {isSaved ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700 font-semibold text-[11px]">Saved</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3 h-3 text-slate-600" />
                      <span className="text-[11px]">Single File</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500 font-mono">
            {selectedIds.size === 0
              ? 'Please select at least 1 file to download ZIP'
              : `Ready to package ${selectedIds.size} file(s) into .zip`}
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2 w-full sm:w-auto">
            <button
              onClick={handleDownloadAllZip}
              disabled={isZipping}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-200 hover:bg-slate-300 rounded-md shadow-2xs transition-colors cursor-pointer disabled:opacity-50"
            >
              <PackageCheck className="w-4 h-4 text-slate-700" />
              <span>Download All Artifacts (.zip)</span>
            </button>

            <button
              onClick={handleDownloadSelectedZip}
              disabled={isNoneSelected || isZipping}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-950 hover:bg-slate-800 rounded-md shadow-2xs transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isZipping ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Creating ZIP...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download Selected ({selectedIds.size}) (.zip)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
