import React from 'react';
import { PythonArtifactsSection } from './PythonArtifactsSection';
import { ResearchData } from '../types';

interface PythonAndMlpSectionProps {
  data: ResearchData['pythonArtifacts'];
}

export const PythonAndMlpSection: React.FC<PythonAndMlpSectionProps> = ({ data }) => {
  return <PythonArtifactsSection data={data} />;
};
