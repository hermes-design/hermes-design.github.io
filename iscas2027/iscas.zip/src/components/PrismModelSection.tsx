import React, { useState } from 'react';
import { ResearchData } from '../types';
import { Binary, Download, Check, FileText } from 'lucide-react';
import { triggerSingleFileDownload } from '../utils/zipArtifacts';

interface PrismModelSectionProps {
  data: ResearchData['prismArtifacts'];
}

export const PrismModelSection: React.FC<PrismModelSectionProps> = ({ data }) => {
  const [downloadedFile, setDownloadedFile] = useState<string | null>(null);

  const handleDownload = (file: { filename: string; downloadUrl?: string }, content: string) => {
    triggerSingleFileDownload({ filename: file.filename, downloadUrl: file.downloadUrl, content }, 'text/plain;charset=utf-8');
    setDownloadedFile(file.filename);
    setTimeout(() => setDownloadedFile(null), 2000);
  };

  return (
    <section id="prism" className="scroll-mt-24">
      <div className="flex items-center mb-8">
        <div className="bg-blue-600 p-2 rounded-lg shadow-lg mr-4">
          <Binary className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Formal Verification Model</h2>
          <p className="text-gray-500 mt-1 text-sm sm:text-base">
            PRISM source code and property specifications
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
        <div className="space-y-10">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <FileText className="w-5 h-5 mr-2 text-blue-600" />
              <span>Paper Artifacts</span>
            </h3>

            <div className="bg-white border border-gray-200 rounded-lg shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Filename
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Type
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden sm:table-cell">
                        Description
                      </th>
                      <th scope="col" className="relative px-6 py-3 text-right">
                        <span className="sr-only">Download</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {data.files.map((file) => {
                      const isDownloaded = downloadedFile === file.filename;
                      let fileContent = '';
                      if (file.filename === 'attack.prism') fileContent = data.attackPrismCode;
                      else if (file.filename === 'defence.prism') fileContent = data.defencePrismCode;
                      else if (file.filename === 'properties.props') fileContent = data.propertiesCode;
                      else if (file.filename === 'analyse.py') fileContent = data.prismAnalyseCode;
                      else fileContent = 'MTTI,Attaque_Initiale,alpha_1,alpha_5,alpha_10\n100,0.082,0.041,0.012,0.003\n200,0.065,0.030,0.008,0.002\n';

                      return (
                        <tr key={file.id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600 font-mono">
                            {file.filename}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                              {file.type}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500 hidden sm:table-cell">
                            {file.description}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => handleDownload(file, fileContent)}
                              className="text-blue-600 hover:text-blue-900 inline-flex items-center bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-md transition-colors text-xs font-medium cursor-pointer"
                            >
                              {isDownloaded ? (
                                <>
                                  <Check className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                                  <span className="text-emerald-700">Downloaded</span>
                                </>
                              ) : (
                                <>
                                  <Download className="w-3.5 h-3.5 mr-1.5" />
                                  <span>Download</span>
                                </>
                              )}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
