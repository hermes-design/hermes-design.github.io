import React, { useState } from 'react';
import { ResearchData } from '../types';
import { Radio, Download, Check } from 'lucide-react';
import { triggerSingleFileDownload } from '../utils/zipArtifacts';

interface GnuRadioSectionProps {
  data: ResearchData['sdrArtifacts'];
}

export const GnuRadioSection: React.FC<GnuRadioSectionProps> = ({ data }) => {
  const [downloadedFile, setDownloadedFile] = useState<string | null>(null);

  const handleDownload = (file: { filename: string; downloadUrl?: string }, content: string) => {
    triggerSingleFileDownload({ filename: file.filename, downloadUrl: file.downloadUrl, content }, 'text/plain;charset=utf-8');
    setDownloadedFile(file.filename);
    setTimeout(() => setDownloadedFile(null), 2000);
  };

  return (
    <section id="gnuradio" className="scroll-mt-24">
      <div className="flex items-center mb-8">
        <div className="bg-blue-600 p-2 rounded-lg shadow-lg mr-4">
          <Radio className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">GNU Radio Artifacts</h2>
          <p className="text-gray-500 mt-1 text-sm sm:text-base">
            Implementation files and flowgraph visualizations
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
        <div className="bg-white border border-gray-200 rounded-lg shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Filename
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden sm:table-cell">
                    Description
                  </th>
                  <th scope="col" className="relative px-6 py-3 text-right">
                    <span className="sr-only">Download</span>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {data.files.map((file) => {
                  const isDownloaded = downloadedFile === file.filename;
                  const mockContent = file.filename.endsWith('.py')
                    ? data.sdrAnalyseCode
                    : `<!-- GNU Radio Companion ${file.filename} -->\n<flow_graph>\n  <block><key>options</key><param><key>title</key><value>${file.filename}</value></param></block>\n</flow_graph>`;

                  return (
                    <tr key={file.id} className="hover:bg-gray-50 transition-colors duration-150">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 font-mono">
                        <div className="flex flex-col">
                          <span>{file.filename}</span>
                          <span className="inline-block mt-1 text-xs text-gray-500 font-sans">
                            <span className="bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded border border-gray-200 font-mono">
                              {file.version}
                            </span>
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 hidden sm:table-cell align-top pt-5">
                        {file.description}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium align-middle">
                        <button
                          onClick={() => handleDownload(file, mockContent)}
                          className="inline-flex items-center text-blue-600 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-md transition-colors font-sans text-xs font-medium cursor-pointer"
                        >
                          {isDownloaded ? (
                            <>
                              <Check className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                              <span className="text-emerald-700">Downloaded</span>
                            </>
                          ) : (
                            <>
                              <Download className="w-3.5 h-3.5 mr-1.5" />
                              <span>Download</span>
                            </>
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};
