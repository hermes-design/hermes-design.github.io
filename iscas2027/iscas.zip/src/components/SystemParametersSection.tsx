import React from 'react';
import { ResearchData } from '../types';
import { Sliders, Activity, ExternalLink, ShieldCheck, CheckCircle2, Clock } from 'lucide-react';

interface SystemParametersProps {
  parameters: ResearchData['systemParameters'];
}

export const SystemParametersSection: React.FC<SystemParametersProps> = ({ parameters }) => {
  return (
    <section id="parameters" className="scroll-mt-24">
      <div className="flex items-center mb-8">
        <div className="bg-blue-600 p-2 rounded-lg shadow-lg mr-4">
          <Sliders className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">System Parameters</h2>
          <p className="text-gray-500 mt-1 text-sm sm:text-base">
            Operational metrics and references for the verified satellite systems
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column: System Context & References */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-xs h-full">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <Activity className="w-5 h-5 mr-2 text-blue-600" />
              <span>{parameters.context.title}</span>
            </h3>

            <div className="text-gray-600 leading-relaxed text-sm sm:text-base">
              <p className="mb-4">
                Our verification parameters are derived from the <strong>COSPAS-SARSAT</strong> system integration with <strong>Galileo</strong>. The model is grounded in the following real-world performance metrics:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li><strong>Reliability:</strong> &gt; 88% over a 12-year lifespan</li>
                <li><strong>Service Availability:</strong> 99.5%</li>
                <li><strong>Signal Health Availability:</strong> 99.22%</li>
                <li><strong>Recovery Time:</strong> &lt; 15 hours</li>
              </ul>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-100">
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
                References &amp; Data Sources
              </h4>
              <ul className="space-y-3 text-sm">
                {parameters.context.references.map((ref) => (
                  <li key={ref.title}>
                    <a
                      href={ref.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-start text-gray-600 hover:text-blue-700 transition-colors p-2 -ml-2 rounded-lg hover:bg-gray-50"
                    >
                      <ExternalLink className="w-4 h-4 mr-2.5 mt-0.5 shrink-0 text-blue-400 group-hover:text-blue-600" />
                      <span>
                        <strong className="block text-gray-900 group-hover:text-blue-800">
                          {ref.title}
                        </strong>
                        {ref.description}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right Column: Metric Cards Stack */}
        <div className="space-y-4">
          <div className="bg-blue-50 rounded-xl p-5 border border-blue-100 shadow-xs transition-all hover:shadow-md hover:border-blue-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-blue-800">Satellite Reliability</span>
              <ShieldCheck className="w-5 h-5 text-blue-600" />
            </div>
            <div className="text-3xl font-bold text-blue-900 font-mono">&gt; 88%</div>
            <div className="text-xs text-blue-600 mt-1 font-medium">Over 12-year lifespan</div>
          </div>

          <div className="bg-emerald-50 rounded-xl p-5 border border-emerald-100 shadow-xs transition-all hover:shadow-md hover:border-emerald-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-emerald-800">Service Availability</span>
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            </div>
            <div className="text-3xl font-bold text-emerald-900 font-mono">99.5%</div>
            <div className="text-xs text-emerald-600 mt-1 font-medium">Global service uptime</div>
          </div>

          <div className="bg-blue-50 rounded-xl p-5 border border-blue-100 shadow-xs transition-all hover:shadow-md hover:border-blue-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-blue-800">Signal Health</span>
              <CheckCircle2 className="w-5 h-5 text-blue-600" />
            </div>
            <div className="text-3xl font-bold text-blue-900 font-mono">99.22%</div>
            <div className="text-xs text-blue-600 mt-1 font-medium">Healthy signal availability</div>
          </div>

          <div className="bg-purple-50 rounded-xl p-5 border border-purple-100 shadow-xs transition-all hover:shadow-md hover:border-purple-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-purple-800">Recovery Time</span>
              <Clock className="w-5 h-5 text-purple-600" />
            </div>
            <div className="text-3xl font-bold text-purple-900 font-mono">&lt; 15 hrs</div>
            <div className="text-xs text-purple-600 mt-1 font-medium">Max operational recovery</div>
          </div>
        </div>
      </div>
    </section>
  );
};
