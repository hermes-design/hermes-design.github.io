import React, { useState } from 'react';
import { PaperData, ResearchData } from '../types';
import { Download, FileText, UserCheck, Archive, Loader2 } from 'lucide-react';
import { getAllArtifactFiles, generateArtifactsZip } from '../utils/zipArtifacts';

interface HeroProps {
  paper: PaperData;
  data: ResearchData;
  onOpenDownloadModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  paper,
  data,
  onOpenDownloadModal,
}) => {
  const [isZipping, setIsZipping] = useState(false);
  const authorNamesStr = paper.authors.map((a) => a.name).join(', ');
  const affiliationsStr = paper.affiliations.map((aff) => `${aff.name} (${aff.city}, ${aff.country})`).join('; ');

  const handleDownloadAllZip = async () => {
    setIsZipping(true);
    try {
      const files = getAllArtifactFiles(data);
      await generateArtifactsZip(files, 'iscas2027_all_artifacts.zip');
    } catch (err) {
      console.error('Error generating ZIP:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <section id="abstract" className="pt-28 pb-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
      <div className="text-center mb-10">
        {/* Paper Title */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-950 tracking-tight mb-6 leading-tight font-serif max-w-5xl mx-auto">
          {paper.title}
        </h1>

        {/* Authors & Affiliations */}
        <div className="flex flex-col items-center gap-2.5 text-slate-700 mb-8">
          {paper.showAuthors !== false && (
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-slate-800 shrink-0" />
              <span className="text-base sm:text-lg font-medium text-slate-900 font-sans">
                {authorNamesStr}
              </span>
            </div>
          )}

          {paper.showAffiliations !== false && (
            <div className="text-xs sm:text-sm text-slate-500 italic max-w-3xl leading-relaxed font-serif">
              {affiliationsStr}
            </div>
          )}

          {(paper.showAuthors !== false || paper.showAffiliations !== false) && (
            <div className="h-px w-20 bg-slate-200 my-1" />
          )}

          <div className="text-xs sm:text-sm font-semibold text-slate-800 uppercase tracking-wider font-mono">
            {paper.conference} &bull; {paper.conferenceLocation}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={handleDownloadAllZip}
            disabled={isZipping}
            className="inline-flex items-center px-6 py-2.5 shadow-xs text-xs font-mono font-semibold rounded-lg text-white bg-slate-900 hover:bg-slate-800 transition-all transform hover:scale-[1.01] active:scale-[0.99] cursor-pointer disabled:opacity-50"
          >
            {isZipping ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin text-white" />
                <span>Generating ZIP...</span>
              </>
            ) : (
              <>
                <Archive className="w-4 h-4 mr-2 text-white" />
                <span>Download All Artifacts (.zip)</span>
              </>
            )}
          </button>

          <button
            onClick={onOpenDownloadModal}
            className="inline-flex items-center px-5 py-2.5 shadow-2xs text-xs font-mono font-semibold rounded-lg text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 mr-2 text-slate-700" />
            <span>Select Files to Download</span>
          </button>
        </div>
      </div>

      {/* Abstract Card */}
      {paper.showAbstract !== false && (
        <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-6 sm:p-10 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1.5 h-full bg-slate-900" />
          <h2 className="text-lg sm:text-xl font-serif font-bold text-slate-950 mb-3 flex items-center">
            <span className="bg-slate-100 text-slate-900 p-1.5 rounded-md mr-2.5">
              <FileText className="w-4 h-4" />
            </span>
            <span>Abstract</span>
          </h2>
          <p className="text-slate-800 leading-relaxed font-serif text-sm sm:text-base text-justify">
            {paper.abstract}
          </p>

          {paper.keywords && paper.keywords.length > 0 && (
            <div className="mt-6 pt-6 border-t border-slate-100 flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono font-semibold text-slate-500 uppercase mr-1">Keywords:</span>
              {paper.keywords.map((kw, idx) => (
                <span key={idx} className="text-xs font-mono bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md border border-slate-200">
                  {kw}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </section>
  );
};
