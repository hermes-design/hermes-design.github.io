import React, { useState } from 'react';
import { Quote, Copy, Check, Download } from 'lucide-react';

interface CitationSectionProps {
  citation: {
    bibtex: string;
    ieee: string;
  };
}

export const CitationSection: React.FC<CitationSectionProps> = ({ citation }) => {
  const [copiedBibtex, setCopiedBibtex] = useState(false);
  const [copiedIeee, setCopiedIeee] = useState(false);

  const copyBibtex = () => {
    navigator.clipboard.writeText(citation.bibtex);
    setCopiedBibtex(true);
    setTimeout(() => setCopiedBibtex(false), 2000);
  };

  const copyIeee = () => {
    navigator.clipboard.writeText(citation.ieee);
    setCopiedIeee(true);
    setTimeout(() => setCopiedIeee(false), 2000);
  };

  const downloadBibFile = () => {
    const blob = new Blob([citation.bibtex], { type: 'application/x-bibtex;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'baouya2025leosecverify.bib');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="citation" className="py-14 sm:py-20 border-b border-slate-200 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2.5 text-slate-800 mb-2">
              <span className="p-1.5 bg-slate-100 rounded-md text-slate-900">
                <Quote className="w-5 h-5" />
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-slate-950 tracking-tight">
                Citation &amp; BibTeX Reference
              </h2>
            </div>
            <p className="text-sm text-slate-600 max-w-2xl">
              If you use these formal models, GNU Radio flowgraphs, or datasets in your research, please cite our IEEE NEWCAS publication.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={downloadBibFile}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .bib</span>
            </button>
          </div>
        </div>

        {/* IEEE Formatted Citation Box */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-6 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-semibold uppercase text-slate-500">
              IEEE Citation Format
            </span>
            <button
              onClick={copyIeee}
              className="inline-flex items-center gap-1.5 text-xs font-mono text-slate-600 hover:text-slate-900"
            >
              {copiedIeee ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">Copied Text</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Text</span>
                </>
              )}
            </button>
          </div>
          <p className="text-xs sm:text-sm text-slate-800 font-serif leading-relaxed">
            {citation.ieee}
          </p>
        </div>

        {/* BibTeX Code Viewer */}
        <div className="bg-slate-950 rounded-xl overflow-hidden shadow-md border border-slate-800">
          <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
              <span className="font-mono text-slate-300 font-medium">baouya2025leosecverify.bib</span>
            </div>

            <button
              onClick={copyBibtex}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors text-xs font-mono"
            >
              {copiedBibtex ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied BibTeX</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy BibTeX</span>
                </>
              )}
            </button>
          </div>

          <pre className="p-4 sm:p-5 text-xs sm:text-[13px] text-slate-200 font-mono overflow-x-auto leading-relaxed">
            <code>{citation.bibtex}</code>
          </pre>
        </div>
      </div>
    </section>
  );
};
