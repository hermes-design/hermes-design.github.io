import React from 'react';
import { ResearchData } from '../types';
import { Terminal, Radio, Binary, CheckCircle2 } from 'lucide-react';

interface UsageInstructionsProps {
  usage: ResearchData['usageInstructions'];
}

export const UsageInstructionsSection: React.FC<UsageInstructionsProps> = ({ usage }) => {
  return (
    <section id="guide" className="scroll-mt-24">
      <div className="flex items-center mb-8">
        <div className="bg-teal-600 p-2 rounded-lg shadow-lg mr-4">
          <Terminal className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Usage Instructions</h2>
          <p className="text-gray-500 mt-1 text-sm sm:text-base">
            Guides for reproducing the results
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* GNU Radio Guide */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-orange-100 p-2 rounded-lg">
              <Radio className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">
              {usage.gnuRadio.title}
            </h3>
          </div>

          <div className="space-y-4 text-sm text-gray-600">
            <p>
              The provided <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800 text-xs font-mono">.grc</code> files are compatible with GNU Radio 3.10+. Follow these steps to execute the flowgraphs:
            </p>
            <ol className="space-y-3 list-none pl-0">
              <li className="flex items-start">
                <span className="shrink-0 bg-orange-50 text-orange-600 font-bold w-6 h-6 rounded-full flex items-center justify-center text-xs mt-0.5 mr-3">
                  1
                </span>
                <span>
                  <strong>Install GNU Radio:</strong> On Ubuntu/Debian, run:
                  <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800 text-xs mt-1 block w-fit font-mono">
                    sudo apt-get install gnuradio
                  </code>
                </span>
              </li>

              <li className="flex items-start">
                <span className="shrink-0 bg-orange-50 text-orange-600 font-bold w-6 h-6 rounded-full flex items-center justify-center text-xs mt-0.5 mr-3">
                  2
                </span>
                <span>
                  <strong>Open Flowgraph:</strong> Launch GNU Radio Companion:
                  <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800 text-xs mt-1 block w-fit font-mono">
                    gnuradio-companion filename.grc
                  </code>
                </span>
              </li>

              <li className="flex items-start">
                <span className="shrink-0 bg-orange-50 text-orange-600 font-bold w-6 h-6 rounded-full flex items-center justify-center text-xs mt-0.5 mr-3">
                  3
                </span>
                <span>
                  <strong>Generate &amp; Execute:</strong> Click the &quot;Generate&quot; icon (F5) followed by the &quot;Execute&quot; icon (F6) in the toolbar.
                </span>
              </li>
            </ol>
          </div>
        </div>

        {/* PRISM Guide */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-blue-100 p-2 rounded-lg">
              <Binary className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">
              {usage.prism.title}
            </h3>
          </div>

          <div className="space-y-4 text-sm text-gray-600">
            <p>
              PRISM 4.7+ is required to verify the formal CTMC models. Follow these steps to run verification:
            </p>
            <ul className="space-y-2 list-none pl-0">
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />
                <span>Open the GUI via <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800 text-xs font-mono">bin/xprism</code></span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />
                <span>Load the Model: <strong>Model &gt; Open Model</strong></span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />
                <span>Load Properties: <strong>Properties &gt; Open Properties</strong></span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />
                <span>Right click a property and select <strong>Verify</strong></span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
