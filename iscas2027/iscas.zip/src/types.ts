export interface Author {
  name: string;
  affiliationIds: number[];
  email: string;
  orcid?: string;
  isCorresponding?: boolean;
}

export interface Affiliation {
  id: number;
  name: string;
  city: string;
  country: string;
  url?: string;
}

export interface PaperData {
  title: string;
  shortTitle: string;
  conference: string;
  conferenceShort: string;
  conferenceLocation: string;
  conferenceDates: string;
  projectFramework?: string;
  projectUrl?: string;
  doi: string;
  paperPdfUrl: string;
  githubUrl: string;
  zenodoDoi: string;
  showAuthors?: boolean;
  showAffiliations?: boolean;
  showAbstract?: boolean;
  showSystemParameters?: boolean;
  authors: Author[];
  affiliations: Affiliation[];
  abstract: string;
  keywords: string[];
}

export interface ResearchStat {
  label: string;
  value: string;
  unit: string;
  subtext: string;
}

export interface ContextMetric {
  name: string;
  value: string;
  period: string;
}

export interface ContextReference {
  title: string;
  description: string;
  url: string;
}

export interface SystemParameter {
  name: string;
  symbol: symbol;
  value: string;
  unit: string;
  category: string;
  notes: string;
}

export interface PrismFileItem {
  id: number;
  filename: string;
  type: string;
  description: string;
  size: string;
  downloadUrl: string;
}

export interface SdrFileItem {
  id: number;
  filename: string;
  description: string;
  repositoryPath: string;
  version: string;
  downloadUrl: string;
}

export interface PythonFileItem {
  id: number;
  filename: string;
  type: string;
  description: string;
  version: string;
  downloadUrl: string;
}

export interface UsageStep {
  step: number;
  name: string;
  details: string;
}

export interface UsageCategory {
  title: string;
  description: string;
  steps: UsageStep[];
}

export interface Partner {
  name: string;
  description: string;
  url: string;
  logo?: string;
  bgColor?: string;
  title?: string;
  alt?: string;
  type: string;
}

export interface ResearchData {
  paper: PaperData;
  stats: ResearchStat[];
  systemParameters: {
    show?: boolean;
    showSystemParameters?: boolean;
    context: {
      title: string;
      description: string;
      metrics: ContextMetric[];
      references: ContextReference[];
    };
    table: SystemParameter[];
  };
  prismArtifacts: {
    title: string;
    subtitle: string;
    description: string;
    files: PrismFileItem[];
    attackPrismCode: string;
    defencePrismCode: string;
    propertiesCode: string;
    prismAnalyseCode: string;
  };
  sdrArtifacts: {
    title: string;
    subtitle: string;
    description: string;
    files: SdrFileItem[];
    sdrAnalyseCode: string;
  };
  pythonArtifacts: {
    title: string;
    subtitle: string;
    description: string;
    files: PythonFileItem[];
    prismAnalyseCode: string;
    sdrAnalyseCode: string;
    mlpCode: string;
  };
  usageInstructions: {
    gnuRadio: UsageCategory;
    prism: UsageCategory;
  };
  citation: {
    bibtex: string;
    ieee: string;
  };
  footer: {
    text: string;
    projectFramework?: string;
    partners: Partner[];
  };
}
