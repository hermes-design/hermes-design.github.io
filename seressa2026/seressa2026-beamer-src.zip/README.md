# SERESSA 2026 — Beamer version

* `seressa2026.tex` — main lecture (same content as SERESSA2026_Baouya_Lecture_v5.pptx, incl. the HERMES Modeler "Try It" slides)
* `seressa2026_ports.tex` — dedicated version with the synchronous vs asynchronous ports slides (Part 6)
* `beamerthemeHermes.sty` — theme reproducing the PowerPoint style (blue title bar, blue/green/orange cards)
* `parts/` — slide sources (`tryit.tex` = hands-on slides, `ports.tex` = ports slides), `img/` — logos, icons, tool screenshots

Compile twice with XeLaTeX (or LuaLaTeX):

    xelatex seressa2026.tex && xelatex seressa2026.tex
    xelatex seressa2026_ports.tex && xelatex seressa2026_ports.tex

Fonts: Carlito (metric-compatible with Calibri), Liberation Sans (Arial), DejaVu Sans Mono.
The "About the Speaker" slide (hidden in the PowerPoint) is available with `\speakertrue` in `seressa2026.tex`.
