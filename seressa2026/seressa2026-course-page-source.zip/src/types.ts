export interface Author {
  name: string;
  link: string;
  isPresenter?: boolean;
  role?: string;
  university?: string;
  department?: string;
}

export interface Presentation {
  title: string;
  subtitle?: string;
  authors: Author[];
  slidesLink: string;
  pptxLink?: string;
  modelerLink?: string;
}

export interface ResourceLink {
  label: string;
  url: string;
  kind?: 'json' | 'code' | 'props';
}

export interface Material {
  name: string;
  description: string;
  url: string;
  format: string;
  primary?: boolean;
  secondary?: ResourceLink;
}

export interface RoadmapItem {
  part: string;
  title: string;
  detail: string;
}

export interface UseCase {
  id: string;
  name: string;
  part: string;
  partOrder: number;
  formalism: string;
  slides?: string;
  summary: string;
  states?: number;
  links: ResourceLink[];
}

export interface Tool {
  name: string;
  url: string;
  description: string;
  badge?: string;
  image?: string;
  sourceUrl?: string;
  gated?: boolean;
}

export interface Artifact {
  name: string;
  url: string;
  description: string;
}

export interface Project {
  name: string;
  url: string;
}

export interface ToolAccess {
  enabled: boolean;
  password: string;
  sheetDbUrl: string;
  note?: string;
}

export interface SiteData {
  event: string;
  eventShort: string;
  eventLink?: string;
  eventDates?: string;
  eventVenue?: string;
  deliveryMode?: string;
  toolAccess: ToolAccess;
  presentation: Presentation;
  sections: {
    roadmap: { title: string; items: RoadmapItem[] };
    useCases: { title: string; items: UseCase[] };
    tools: { title: string; items: Tool[] };
    artifacts: { title: string; publications: string[] };
    relatedProjects: { title: string; items: Project[] };
  };
}
