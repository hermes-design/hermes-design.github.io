/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import data from './data.json';
import type { SiteData } from './types';
import { Hero } from './components/Hero';
import { RoadmapSection } from './components/RoadmapSection';
import { UseCasesSection } from './components/UseCasesSection';
import { ToolsSection } from './components/ToolsSection';
import { ArtifactsSection } from './components/ArtifactsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { OrganizersSection } from './components/OrganizersSection';
import { Footer } from './components/Footer';
import { ToolAccessProvider } from './components/ToolAccess';

const siteData = data as SiteData;

const NAV = [
  ['#roadmap', 'Roadmap'],
  ['#use-cases', 'Use Cases'],
  ['#tools', 'Tools'],
  ['#publications', 'Publications'],
];

export default function App() {
  const { sections, presentation } = siteData;
  const useCaseParts: Record<string, { id: string; name: string }[]> = {};
  sections.useCases.items.forEach(u => {
    const part = u.part.split(' — ')[0];
    (useCaseParts[part] ||= []).push({ id: u.id, name: u.name });
  });

  return (
    <ToolAccessProvider config={siteData.toolAccess}>
      <div className="min-h-screen bg-white font-sans selection:bg-blue-100">
        <nav aria-label="Sections" className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur border-b border-slate-800">
          <div className="max-w-5xl mx-auto px-6 lg:px-8 h-12 flex items-center gap-1 overflow-x-auto">
            <span className="text-xs font-bold text-blue-400 tracking-wider uppercase mr-4 shrink-0">{siteData.eventShort}</span>
            {NAV.map(([href, label]) => (
              <a key={href} href={href} className="text-xs font-medium text-slate-300 hover:text-white px-2.5 py-1.5 rounded-md hover:bg-slate-800 transition-colors shrink-0">{label}</a>
            ))}
          </div>
        </nav>

        <Hero
          event={siteData.event}
          eventLink={siteData.eventLink}
          eventDates={siteData.eventDates}
          eventVenue={siteData.eventVenue}
          deliveryMode={siteData.deliveryMode}
          presentation={presentation}
        />

        <main>
          <RoadmapSection title={sections.roadmap.title} items={sections.roadmap.items} useCaseParts={useCaseParts} />
          <UseCasesSection
            title={sections.useCases.title}
            items={sections.useCases.items}
            modelerUrl={presentation.modelerLink || 'modeler/'}
          />
          <ToolsSection title={sections.tools.title} items={sections.tools.items} gateEnabled={siteData.toolAccess.enabled} />
          <ArtifactsSection title={sections.artifacts.title} publications={sections.artifacts.publications} />
          <ProjectsSection title={sections.relatedProjects.title} items={sections.relatedProjects.items} />
          <OrganizersSection />
        </main>

        <Footer />
      </div>
    </ToolAccessProvider>
  );
}
