import { Wrench, ExternalLink, Lock, Sparkles } from 'lucide-react';
import { SectionHeader } from './SectionHeader';
import { PrismGuide } from './PrismGuide';
import { useToolAccess } from './ToolAccess';
import type { Tool } from '../types';

export function ToolsSection({ title, items, gateEnabled }: { title: string; items: Tool[]; gateEnabled: boolean }) {
  const { openTool } = useToolAccess();
  return (
    <section id="tools" className="py-12 border-b border-slate-200 bg-slate-50 scroll-mt-16">
      <div className="max-w-5xl mx-auto px-6 lg:px-8">
        <SectionHeader title={title} icon={<Wrench className="w-6 h-6" />} />
        <div className="grid grid-cols-1 gap-6">
          {items.map(tool => (
            <div key={tool.name} className={`bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden ${tool.image ? 'grid grid-cols-1 lg:grid-cols-2' : ''}`}>
              <div className="p-6 md:p-8 flex flex-col justify-between gap-6">
                <div>
                  {tool.badge && (
                    <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md mb-3">
                      <Sparkles className="w-3 h-3" /> {tool.badge}
                    </span>
                  )}
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">{tool.name}</h3>
                  <p className="text-slate-600 leading-relaxed text-sm">{tool.description}</p>
                </div>
                <div className="flex flex-wrap gap-3">
                  {tool.gated ? (
                    <button onClick={() => openTool(tool.url, tool.name)}
                      className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-slate-900 text-white hover:bg-slate-700 rounded-lg font-medium transition-colors cursor-pointer">
                      Open {tool.name}
                      {gateEnabled ? <Lock className="w-4 h-4 text-slate-400" /> : <ExternalLink className="w-4 h-4" />}
                    </button>
                  ) : (
                    <a href={tool.url} target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-white text-slate-800 hover:bg-slate-100 border border-slate-300 rounded-lg font-medium transition-colors">
                      Open <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
              {tool.image && (
                <div className="bg-slate-100 border-t lg:border-t-0 lg:border-l border-slate-200 p-4 flex items-center">
                  <img src={tool.image} alt={`${tool.name}: Use Cases tab`} width={1280} height={720} className="w-full rounded-lg border border-slate-200 shadow-sm" />
                </div>
              )}
            </div>
          ))}
        </div>
        <PrismGuide />
      </div>
    </section>
  );
}
