import { Presentation } from 'lucide-react';
import { SectionHeader } from './SectionHeader';
import type { RoadmapItem } from '../types';

export function RoadmapSection({ title, items, useCaseParts }: { title: string; items: RoadmapItem[]; useCaseParts: Record<string, { id: string; name: string }[]> }) {
  return (
    <section id="roadmap" className="py-12 border-b border-slate-200 bg-slate-50 scroll-mt-16">
      <div className="max-w-5xl mx-auto px-6 lg:px-8">
        <SectionHeader title={title} icon={<Presentation className="w-6 h-6" />} />
        <ol className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {items.map((it, i) => (
            <li key={it.part} className="flex gap-4 p-5 bg-white border border-slate-200 rounded-xl">
              <span className="w-9 h-9 rounded-full bg-blue-100 text-blue-700 font-bold text-sm flex items-center justify-center shrink-0">{i + 1}</span>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">{it.part}</p>
                <h3 className="text-sm font-semibold text-slate-900 mt-0.5">{it.title}</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">{it.detail}</p>
                {(useCaseParts[it.part] || []).length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {useCaseParts[it.part].map(u => (
                      <a key={u.id} href={`#uc-${u.id}`} className="text-[11px] font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 px-2 py-0.5 rounded-md transition-colors">
                        Try it: {u.name}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
