import { SectionHeader } from './SectionHeader';
import { Handshake } from 'lucide-react';

export function OrganizersSection() {
  return (
    <section className="py-16 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <SectionHeader title="Organizers and Supporters" icon={<Handshake className="w-6 h-6 text-blue-500" />} />
        <div className="mt-8 p-6 md:p-8 bg-white border border-slate-200/80 rounded-2xl shadow-sm">
          <p className="text-sm md:text-base text-slate-700 leading-relaxed text-center italic mx-auto max-w-3xl">
            "We express our sincere gratitude to the organizers of SERESSA 2026 — Concordia University (Gina Cody School of Engineering and Computer Science, Mark Pathy Space Institute) and CY Cergy Paris Université — and to the General Chairs Prof. Otmane Ait Mohamed and Prof. Ricardo Reis, the Honorary Chair Dr. Raoul Velazco, the Program Chair Prof. Fakhreddine Ghaffari and the Local Chair Prof. Mounir Boukadoum, for inviting this lecture and for their dedication to the school."
          </p>
        </div>
      </div>
    </section>
  );
}
