import { BookMarked } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

export function ArtifactsSection({ title, publications }: { title: string; publications: string[] }) {
  return (
    <section id="publications" className="py-12 border-b border-slate-200 scroll-mt-16">
      <div className="max-w-5xl mx-auto px-6 lg:px-8">
        <SectionHeader title={title} icon={<BookMarked className="w-6 h-6" />} />
        <ul className="space-y-3">
          {publications.map(p => (
            <li key={p} className="text-sm text-slate-600 leading-relaxed pl-4 border-l-2 border-blue-200">{p}</li>
          ))}
        </ul>
      </div>
    </section>
  );
}
