import { FlaskConical, Code2, Sliders, FileJson, ExternalLink } from 'lucide-react';
import { SectionHeader } from './SectionHeader';
import { useToolAccess } from './ToolAccess';
import type { UseCase } from '../types';

const FORMALISM: Record<string, string> = {
  CSG: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  CTMC: 'bg-emerald-50 text-emerald-700 border-emerald-200',
};

const LINK_ICON = { json: FileJson, code: Code2, props: Sliders };

interface Props {
  title: string;
  items: UseCase[];
  modelerUrl: string;
}

export function UseCasesSection({ title, items, modelerUrl }: Props) {
  const { openTool } = useToolAccess();
  return (
    <section id="use-cases" className="py-12 border-b border-slate-200 scroll-mt-16">
      <div className="max-w-5xl mx-auto px-6 lg:px-8">
        <SectionHeader title={title} icon={<FlaskConical className="w-6 h-6" />} />

        <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          {[
            ['1', 'Open a case in HERMES Modeler', 'Its Use Cases tab opens on the case linked to the slide you are on.'],
            ['2', 'Change the parameters', 'MTBF, rates, human priorities: the PRISM model is regenerated from them.'],
            ['3', 'Verify with PRISM / PRISM-games', 'Compare with the results of the “Try It” slides.'],
          ].map(([n, t, d]) => (
            <div key={n} className="flex gap-3 p-4 rounded-xl bg-blue-50/60 border border-blue-100">
              <span className="w-7 h-7 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center shrink-0">{n}</span>
              <div><p className="font-semibold text-slate-900">{t}</p><p className="text-xs text-slate-500 mt-0.5 leading-relaxed">{d}</p></div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {items.map(uc => (
            <article key={uc.id} id={`uc-${uc.id}`} className="scroll-mt-20 flex flex-col bg-white border border-slate-200 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between gap-3">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">{uc.part}</p>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border shrink-0 ${FORMALISM[uc.formalism] || 'bg-slate-50 text-slate-600 border-slate-200'}`}>{uc.formalism}</span>
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mt-1">{uc.name}</h3>
              <p className="text-sm text-slate-600 leading-relaxed mt-2 flex-1">{uc.summary}</p>
              <p className="text-xs text-slate-400 mt-3">
                {uc.slides ? `${uc.slides} · ` : ''}{uc.states} states · verified with PRISM-games
              </p>

              <div className="flex flex-wrap gap-2 mt-5">
                <button onClick={() => openTool(`${modelerUrl}?usecase=${uc.id}`, 'HERMES Modeler')}
                  className="inline-flex items-center gap-2 px-3.5 py-2 bg-slate-900 hover:bg-slate-700 text-white rounded-lg text-sm font-semibold transition-colors cursor-pointer">
                  <ExternalLink className="w-4 h-4" /> Open in HERMES Modeler
                </button>
                {uc.links.map(link => {
                  const Icon = LINK_ICON[link.kind || 'code'];
                  return (
                    <a key={link.url} href={link.url} download
                      className="inline-flex items-center gap-2 px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg text-sm font-medium transition-colors border border-slate-200">
                      <Icon className={`w-4 h-4 ${link.kind === 'props' ? 'text-blue-500' : link.kind === 'json' ? 'text-amber-500' : 'text-emerald-600'}`} />
                      {link.label}
                    </a>
                  );
                })}
              </div>
            </article>
          ))}
        </div>

      </div>
    </section>
  );
}
