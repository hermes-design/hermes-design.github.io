import { BookOpen, FileDown, Presentation as PptIcon, Users, Mic, Mail, CalendarDays, MapPin, Radio, Boxes } from 'lucide-react';
import type { Presentation } from '../types';
import { useToolAccess } from './ToolAccess';

interface HeroProps {
  event: string;
  eventLink?: string;
  eventDates?: string;
  eventVenue?: string;
  deliveryMode?: string;
  presentation: Presentation;
}

export function Hero({ event, eventLink, eventDates, eventVenue, deliveryMode, presentation }: HeroProps) {
  const presenter = presentation.authors.find(a => a.isPresenter) || presentation.authors[0];
  const coAuthors = presentation.authors.filter(a => a.name !== presenter.name);
  const { openTool } = useToolAccess();

  return (
    <header className="bg-slate-900 text-white py-16 md:py-24 border-b border-slate-800 relative overflow-hidden">
      {/* faint orbit motif */}
      <svg aria-hidden="true" className="absolute -right-40 -top-40 w-[640px] h-[640px] text-blue-500/10 pointer-events-none" viewBox="0 0 640 640" fill="none">
        <ellipse cx="320" cy="320" rx="300" ry="120" stroke="currentColor" strokeWidth="1.5" transform="rotate(-25 320 320)" />
        <ellipse cx="320" cy="320" rx="220" ry="80" stroke="currentColor" strokeWidth="1.5" transform="rotate(20 320 320)" />
        <circle cx="560" cy="210" r="6" fill="currentColor" />
      </svg>

      <div className="max-w-5xl mx-auto px-6 lg:px-8 relative">
        {eventLink ? (
          <a href={eventLink} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-start gap-2 text-blue-400 hover:text-blue-300 mb-5 text-sm font-medium uppercase tracking-wider transition-colors group max-w-3xl">
            <BookOpen className="w-5 h-5 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
            <span className="underline decoration-dotted underline-offset-4 decoration-blue-400 leading-relaxed">{event}</span>
          </a>
        ) : (
          <div className="flex items-center gap-2 text-blue-400 mb-5 text-sm font-medium uppercase tracking-wider"><BookOpen className="w-5 h-5" /><span>{event}</span></div>
        )}

        <div className="flex flex-wrap gap-2 mb-8 text-xs">
          {eventDates && <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700/60"><CalendarDays className="w-3.5 h-3.5 text-blue-400" />{eventDates}</span>}
          {eventVenue && <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700/60"><MapPin className="w-3.5 h-3.5 text-blue-400" />{eventVenue}</span>}
          {deliveryMode && <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30"><Radio className="w-3.5 h-3.5" />{deliveryMode}</span>}
        </div>

        <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-4 leading-tight max-w-4xl">{presentation.title}</h1>
        {presentation.subtitle && <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-3xl leading-relaxed">{presentation.subtitle}</p>}

        {/* Presenter card + main actions */}
        <div className="mb-8 p-5 bg-slate-950/50 border border-slate-800/80 rounded-2xl max-w-4xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400 shrink-0"><Mic className="w-5 h-5" /></div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-md inline-block mb-1.5">{presenter.role || 'Speaker / Presenter'}</span>
              <h2 className="text-lg font-bold text-slate-100 leading-snug">{presenter.name}</h2>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {presenter.department && <>{presenter.department}<br /></>}{presenter.university}
              </p>
              <a href={presenter.link} className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-blue-400 transition-colors mt-2">
                <Mail className="w-3.5 h-3.5" />{presenter.link.replace('mailto:', '')}
              </a>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 w-full lg:w-auto shrink-0">
            <a href={presentation.slidesLink} download
              className="inline-flex items-center justify-center gap-2 text-white bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/10">
              <FileDown className="w-5 h-5" /> Download Slides (PDF)
            </a>
            {presentation.pptxLink && (
              <a href={presentation.pptxLink} download
                className="inline-flex items-center justify-center gap-2 text-slate-200 bg-slate-800 hover:bg-slate-700 px-4 py-3 rounded-xl font-semibold transition-all border border-slate-700">
                <PptIcon className="w-4 h-4" /> PPTX
              </a>
            )}
            {presentation.modelerLink && (
              <button onClick={() => openTool(presentation.modelerLink!, 'HERMES Modeler')}
                className="inline-flex items-center justify-center gap-2 text-slate-900 bg-white hover:bg-slate-100 px-4 py-3 rounded-xl font-bold transition-all cursor-pointer">
                <Boxes className="w-4 h-4 text-blue-600" /> HERMES Modeler
              </button>
            )}
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-800/60 max-w-4xl">
          <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-400/85" /> Co-Authors & Academic Collaborators
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {coAuthors.map(author => (
              <a key={author.name} href={author.link}
                className="flex flex-col p-4 rounded-xl bg-slate-950/45 border border-slate-800/75 hover:border-blue-500/40 hover:bg-slate-950/80 transition-all group">
                <div className="flex items-center gap-2 mb-1 text-slate-200 group-hover:text-blue-400 transition-colors">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500/80 shrink-0" />
                  <span className="font-bold text-sm tracking-tight leading-none">{author.name}</span>
                </div>
                <span className="text-[11px] font-semibold text-slate-400 tracking-wide mt-1">{author.role || 'Collaborator'}</span>
                {author.department && <span className="text-[10px] text-slate-400 leading-normal mt-0.5">{author.department}</span>}
                {author.university && <span className="text-[10px] text-slate-400 leading-normal">{author.university}</span>}
              </a>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
