import React, { createContext, useContext, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, User, Mail, ShieldAlert, CheckCircle2, X } from 'lucide-react';
import type { ToolAccess } from '../types';

/**
 * Registration gate in front of HERMES Modeler (same mechanism as the previous summer school page):
 * name + email + access password, recorded in SheetDB. Once verified, the gate is skipped for the
 * rest of the browser session. Disabled when toolAccess.enabled is false in data.json.
 */
interface AccessContextValue {
  openTool: (url: string, name: string) => void;
}

const AccessContext = createContext<AccessContextValue>({ openTool: url => window.open(url, '_blank', 'noopener') });
export const useToolAccess = () => useContext(AccessContext);

const SESSION_KEY = 'seressa2026-tool-access';

function isVerified(): boolean {
  try { return sessionStorage.getItem(SESSION_KEY) === 'ok'; } catch { return false; }
}

export function ToolAccessProvider({ config, children }: { config: ToolAccess; children: React.ReactNode }) {
  const [pending, setPending] = useState<{ url: string; name: string } | null>(null);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const openTool = (url: string, name: string) => {
    if (!config.enabled || isVerified()) {
      window.open(url, '_blank', 'noopener,noreferrer');
      return;
    }
    setPending({ url, name });
    setError(null);
    setSuccess(false);
  };

  const close = () => {
    if (isSubmitting) return;
    setPending(null);
    setPassword('');
    setError(null);
    setSuccess(false);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !email.trim() || !password.trim()) return setError('Please fill out all fields.');
    if (!email.includes('@') || !email.includes('.')) return setError('Please enter a valid email address.');
    if (password !== config.password) return setError('Invalid access password. It is given at the start of the lecture.');

    setError(null);
    setIsSubmitting(true);
    try {
      const response = await fetch(config.sheetDbUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ data: [{ user: username, email, timestamp: new Date().toLocaleString() }] }),
      });
      if (!response.ok) throw new Error(`Server responded with status ${response.status}`);
    } catch (err) {
      // the registration could not be saved: do not block the student
      console.error('SheetDB registration failed:', err);
    }
    try { sessionStorage.setItem(SESSION_KEY, 'ok'); } catch { /* private mode */ }
    setIsSubmitting(false);
    setSuccess(true);
    const target = pending!;
    setTimeout(() => {
      window.open(target.url, '_blank', 'noopener,noreferrer');
      setPending(null);
      setSuccess(false);
      setPassword('');
    }, 1200);
  };

  const input = 'block w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder-slate-400 disabled:opacity-50';

  return (
    <AccessContext.Provider value={{ openTool }}>
      {children}
      <AnimatePresence>
        {pending && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={close} className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" />
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="access-title"
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              transition={{ duration: 0.2 }}
              className="relative w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden z-10"
            >
              <div className="px-6 pt-6 pb-4 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-600"><Lock className="w-4 h-4" /></div>
                  <h4 id="access-title" className="font-bold text-slate-900">Register to open {pending.name}</h4>
                </div>
                <button onClick={close} disabled={isSubmitting} aria-label="Close" className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-6">
                {success ? (
                  <div className="flex flex-col items-center justify-center py-6 text-center">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center mb-4"><CheckCircle2 className="w-7 h-7" /></div>
                    <h5 className="font-bold text-base text-slate-900 mb-1.5">Welcome, {username}!</h5>
                    <p className="text-xs text-slate-500">Opening {pending.name} in a new tab…</p>
                  </div>
                ) : (
                  <form onSubmit={submit} className="space-y-4">
                    <p className="text-xs text-slate-500 leading-normal">
                      Enter your name, your email and the access password given during the lecture. You only need to do this once per session.
                    </p>
                    {error && (
                      <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/20 text-xs text-red-600 flex items-start gap-2.5">
                        <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" /><span>{error}</span>
                      </div>
                    )}
                    {[
                      { label: 'Name', icon: User, type: 'text', value: username, set: setUsername, placeholder: 'Your full name' },
                      { label: 'Email Address', icon: Mail, type: 'email', value: email, set: setEmail, placeholder: 'name@university.edu' },
                      { label: 'Access Password', icon: Lock, type: 'password', value: password, set: setPassword, placeholder: '••••••••••' },
                    ].map(f => (
                      <div key={f.label}>
                        <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">{f.label}</label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400"><f.icon className="w-4 h-4" /></div>
                          <input type={f.type} required disabled={isSubmitting} value={f.value} onChange={e => f.set(e.target.value)} placeholder={f.placeholder} aria-label={f.label} className={input} />
                        </div>
                      </div>
                    ))}
                    <div className="pt-2 flex justify-end gap-3">
                      <button type="button" onClick={close} disabled={isSubmitting} className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-all">Cancel</button>
                      <button type="submit" disabled={isSubmitting} className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-all disabled:opacity-50">
                        {isSubmitting ? 'Saving…' : 'Verify & Open'}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AccessContext.Provider>
  );
}
