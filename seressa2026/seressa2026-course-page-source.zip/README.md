# SERESSA 2026 — course page

Course page of the lecture **From Particle Strikes to Mission Dependability** (A. Baouya) at
[SERESSA 2026](https://seressa2026.encs.concordia.ca/), Concordia University, Montréal, November 23–27, 2026.
Built from the course page of the 7th Summer School on CPS and IoT (same stack: React + Vite + Tailwind).

## Deploy

The site is fully static and uses relative links, so it works from any folder of a web server:

```bash
npm install
npm run build          # -> dist/
```

Upload the **content** of `dist/` (or of `seressa2026-course-page-dist.zip`) to the target folder, e.g.
`…/web/seressa2026/`. It contains:

| Path | Content |
|---|---|
| `index.html`, `assets/` | the page |
| `downloads/` | slides (PDF and PPTX) |
| `artifacts/` | one `.json` (use case), `.prism` and `.props` file per use case |
| `modeler/` | HERMES Modeler (compiled build only, no sources) — `modeler/?usecase=<id>` opens a use case directly |
| `img/` | screenshot used on the page |

## Edit the content

Everything shown on the page comes from `src/data.json` (event, authors, slides, roadmap, use cases, tools, publications).
Files referenced there live in `public/`.

* **Registration gate** (as on the previous page): `toolAccess.enabled`, `toolAccess.password` (`seressa2026`)
  and `toolAccess.sheetDbUrl`. Students give their name, email and the password once per browser session before
  HERMES Modeler opens; the record is sent to SheetDB (the tool still opens if SheetDB is unreachable).
  Set `enabled` to `false` to open the modeler directly. The password is visible in the page's JavaScript, so it
  is a registration step, not a protection.
* **Updating the modeler**: build HERMES Modeler (`npm run build` in its folder, `base: './'`) and copy its
  `dist/` into `public/modeler/`.
* The Histats counter of the previous page is kept in `index.html`.
