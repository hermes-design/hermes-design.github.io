/**
 * Exports every use case of public/usecases/ to PRISM files:
 *   npm run usecases:export -- [outDir]       (default: prism-out/)
 * Produces <id>.prism and <id>.props, ready for `prism <id>.prism <id>.props`.
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { UseCase } from '../src/types';
import { applyParameters, generatePrismCode, generatePropertiesFile } from '../src/lib/prismGenerator';

const dir = join(process.cwd(), 'public', 'usecases');
const out = process.argv[2] || join(process.cwd(), 'prism-out');
mkdirSync(out, { recursive: true });
const index = JSON.parse(readFileSync(join(dir, 'index.json'), 'utf8'));
for (const entry of index.usecases) {
  const uc: UseCase = JSON.parse(readFileSync(join(dir, entry.file), 'utf8'));
  const m = applyParameters(uc.model, uc.parameters);
  writeFileSync(join(out, `${uc.id}.prism`), generatePrismCode(m));
  writeFileSync(join(out, `${uc.id}.props`), generatePropertiesFile(m));
  console.log(`${uc.id}: ${uc.formalism.toUpperCase()} -> ${out}/${uc.id}.prism`);
}
