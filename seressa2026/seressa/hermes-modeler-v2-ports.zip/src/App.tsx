import React, { useState, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { Canvas } from './components/Canvas';
import { PropertiesPanel } from './components/PropertiesPanel';
import { StateMachineEditor } from './components/StateMachineEditor';
import { MonitorEditor } from './components/MonitorEditor';
import { ArchitectureModel, CPCComponent, Connector, ComponentType, StateMachine, MonitorDefinition, RewardStructure, Constant, Label, Formula, Port, ModelType, PropertySpec, UseCase } from './types';
import { GlobalDefinitionsEditor } from './components/GlobalDefinitionsEditor';
import { generatePrismCode, generatePropertiesFile } from './lib/prismGenerator';
import { UseCasesView } from './components/UseCasesView';
import { PrismCodeModal } from './components/PrismCodeModal';
import { v4 as uuidv4 } from 'uuid';
import { Code, Share2, Play, Info, Save, FolderOpen, Coins, Hash, Image as ImageIcon, FilePlus, BookOpen, PenTool, X } from 'lucide-react';
import { RewardEditor } from './components/RewardEditor';

export default function App() {
  const [components, setComponents] = useState<CPCComponent[]>([]);
  const [connectors, setConnectors] = useState<Connector[]>([]);
  const [rewards, setRewards] = useState<RewardStructure[]>([]);
  const [constants, setConstants] = useState<Constant[]>([]);
  const [labels, setLabels] = useState<Label[]>([]);
  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [modelType, setModelType] = useState<ModelType>('csg');
  const [includeRounds, setIncludeRounds] = useState(true);
  const [properties, setProperties] = useState<PropertySpec[]>([]);
  const [activeTab, setActiveTab] = useState<'modeler' | 'usecases'>('modeler');
  const [isCodeOpen, setIsCodeOpen] = useState(false);
  const [loadedUseCase, setLoadedUseCase] = useState<UseCase | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editingComponentId, setEditingComponentId] = useState<string | null>(null);
  const [editingMonitorId, setEditingMonitorId] = useState<string | null>(null);
  const [isEditingRewards, setIsEditingRewards] = useState(false);
  const [isGlobalDefsOpen, setIsGlobalDefsOpen] = useState(false);
  const stageRef = React.useRef<any>(null);

  const model: ArchitectureModel = useMemo(() => ({
    modelType,
    includeRounds,
    properties,
    components,
    connectors,
    rewards,
    constants,
    labels,
    formulas
  }), [modelType, includeRounds, properties, components, connectors, rewards, constants, labels, formulas]);

  const prismCode = useMemo(() => generatePrismCode(model), [model]);
  const propsCode = useMemo(() => generatePropertiesFile(model), [model]);

  const applyModel = (m: ArchitectureModel) => {
    setModelType(m.modelType || 'csg');
    setIncludeRounds(m.includeRounds !== false);
    setProperties(m.properties || []);
    setComponents(m.components);
    setConnectors(m.connectors);
    setRewards(m.rewards || []);
    setConstants(m.constants || []);
    setLabels(m.labels || []);
    setFormulas(m.formulas || []);
    setSelectedId(null);
    setEditingComponentId(null);
    setEditingMonitorId(null);
    setCanvasKey(prev => prev + 1);
  };

  const handleLoadUseCase = (m: ArchitectureModel, uc: UseCase) => {
    const doLoad = () => {
      applyModel(JSON.parse(JSON.stringify(m)));
      setLoadedUseCase(uc);
      setActiveTab('modeler');
    };
    if (components.length > 0 && !window.confirm(`Load "${uc.title}"? The model currently open in the modeler will be replaced (save it first if needed).`)) return;
    doLoad();
  };

  const handleExportImage = () => {
    if (!stageRef.current) return;
    
    // Get stage as data URL
    const dataURL = stageRef.current.toDataURL({
      pixelRatio: 2, // High resolution
      mimeType: 'image/png'
    });
    
    const link = document.createElement('a');
    link.href = dataURL;
    link.download = `cpc_diagram_${new Date().toISOString().split('T')[0]}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddComponent = (type: ComponentType) => {
    let newPorts: Port[] = [
      { id: uuidv4(), name: 'p1', type: 'INPUT', commMode: 'SYNCHRONOUS' },
      { id: uuidv4(), name: 'p2', type: 'OUTPUT', commMode: 'SYNCHRONOUS' },
    ];
    let newStateMachine: StateMachine | undefined = undefined;

    if (type === 'ATTACKER') {
      const idleId = uuidv4();
      
      newPorts = [
        { id: uuidv4(), name: 'spoof', type: 'OUTPUT', commMode: 'SYNCHRONOUS', side: 'RIGHT', offset: 30 },
        { id: uuidv4(), name: 'tamper', type: 'OUTPUT', commMode: 'SYNCHRONOUS', side: 'RIGHT', offset: 60 },
        { id: uuidv4(), name: 'dos', type: 'OUTPUT', commMode: 'SYNCHRONOUS', side: 'RIGHT', offset: 90 },
      ];

      newStateMachine = {
        variables: [
          { id: uuidv4(), name: 's', min: 0, max: 0, init: 0 },
          { id: uuidv4(), name: 'success', min: 0, max: 1, init: 0 },
          { id: uuidv4(), name: 'detected', min: 0, max: 1, init: 0 }
        ],
        states: [
          { id: idleId, name: 'idle', variableName: 's', value: 0, x: 200, y: 150 }
        ],
        transitions: [
          {
            id: uuidv4(),
            sourceStateId: idleId,
            targetStateId: idleId,
            action: 'spoof',
            updates: [
              { probability: 'ATTACK_SUCCESS', assignments: { 'success': '1', 'detected': '0' } },
              { probability: '1-ATTACK_SUCCESS', assignments: { 'success': '0', 'detected': '1' } }
            ]
          },
          {
            id: uuidv4(),
            sourceStateId: idleId,
            targetStateId: idleId,
            action: 'tamper',
            updates: [
              { probability: 'ATTACK_SUCCESS', assignments: { 'success': '1', 'detected': '0' } },
              { probability: '1-ATTACK_SUCCESS', assignments: { 'success': '0', 'detected': '1' } }
            ]
          },
          {
            id: uuidv4(),
            sourceStateId: idleId,
            targetStateId: idleId,
            action: 'dos',
            updates: [
              { probability: 'ATTACK_SUCCESS', assignments: { 'success': '1', 'detected': '0' } },
              { probability: '1-ATTACK_SUCCESS', assignments: { 'success': '0', 'detected': '1' } }
            ]
          }
        ]
      };

      // Ensure ATTACK_SUCCESS exists
      if (!constants.some(c => c.name === 'ATTACK_SUCCESS')) {
        setConstants(prev => [...prev, { id: uuidv4(), name: 'ATTACK_SUCCESS', type: 'double', value: '0.5' }]);
      }
    } else if (type === 'GATEWAY') {
      newPorts = [
        { id: uuidv4(), name: 'push', type: 'INPUT', commMode: 'SYNCHRONOUS', side: 'LEFT', offset: 50 },
        { id: uuidv4(), name: 'pull', type: 'OUTPUT', commMode: 'SYNCHRONOUS', side: 'RIGHT', offset: 50 },
      ];
      
      // Ensure N exists for FIFO capacity
      if (!constants.some(c => c.name === 'N')) {
        setConstants(prev => [...prev, { id: uuidv4(), name: 'N', type: 'int', value: '5' }]);
      }

      const operationalId = uuidv4();
      newStateMachine = {
        variables: [
          { id: uuidv4(), name: 'head', min: 0, max: 4, init: 0 },
          { id: uuidv4(), name: 'tail', min: 0, max: 4, init: 0 },
          { id: uuidv4(), name: 'count', min: 0, max: 5, init: 0 }
        ],
        states: [
          { id: operationalId, name: 'operational', variableName: 's', value: 0, x: 200, y: 150 }
        ],
        transitions: [
          {
            id: uuidv4(),
            sourceStateId: operationalId,
            targetStateId: operationalId,
            action: 'push',
            guard: 'count < N',
            updates: [{ probability: 1, assignments: { 'tail': '(tail + 1) mod N', 'count': 'count + 1' } }]
          },
          {
            id: uuidv4(),
            sourceStateId: operationalId,
            targetStateId: operationalId,
            action: 'pull',
            guard: 'count > 0',
            updates: [{ probability: 1, assignments: { 'head': '(head + 1) mod N', 'count': 'count - 1' } }]
          }
        ]
      };
    } else if (type === 'ACTUATOR') {
      newPorts = [
        { id: uuidv4(), name: 'pull', type: 'INPUT', commMode: 'ASYNCHRONOUS', side: 'LEFT', offset: 50 },
      ];
      const idleId = uuidv4();
      const activeId = uuidv4();
      newStateMachine = {
        variables: [{ id: uuidv4(), name: 's', min: 0, max: 1, init: 0 }],
        states: [
          { id: idleId, name: 'idle', variableName: 's', value: 0, x: 100, y: 100 },
          { id: activeId, name: 'active', variableName: 's', value: 1, x: 300, y: 100 }
        ],
        transitions: [
          {
            id: uuidv4(),
            sourceStateId: idleId,
            targetStateId: activeId,
            action: 'pull',
            updates: [{ probability: 1, assignments: { 's': '1' } }]
          },
          {
            id: uuidv4(),
            sourceStateId: activeId,
            targetStateId: idleId,
            updates: [{ probability: 1, assignments: { 's': '0' } }]
          }
        ]
      };
    } else if (type !== 'MONITOR') {
      newStateMachine = {
        variables: [{ id: uuidv4(), name: 's', min: 0, max: 1, init: 0 }],
        states: [
          { id: uuidv4(), name: 'idle', x: 100, y: 100 },
          { id: uuidv4(), name: 'active', x: 300, y: 100 }
        ],
        transitions: []
      };
    }

    const newComp: CPCComponent = {
      id: uuidv4(),
      type,
      name: `${type}_${components.length + 1}`,
      x: 50 + Math.random() * 100,
      y: 50 + Math.random() * 100,
      ports: newPorts,
      properties: {
        successRate: 0.5,
      },
      stateMachine: newStateMachine,
      monitorDefinition: type === 'MONITOR' ? {
        variables: [{ id: uuidv4(), name: 's', min: 0, max: 10, init: 0 }],
        transitions: []
      } : undefined
    };
    setComponents([...components, newComp]);
    setSelectedId(newComp.id);
  };

  const handleUpdateComponent = (updated: CPCComponent) => {
    setComponents(components.map(c => c.id === updated.id ? updated : c));
  };

  const handleUpdateConnector = (updated: Connector) => {
    setConnectors(connectors.map(c => c.id === updated.id ? updated : c));
  };

  const handleDuplicateComponent = (id: string) => {
    const original = components.find(c => c.id === id);
    if (!original) return;

    // Deep copy and regenerate IDs
    const newCompId = uuidv4();
    
    // Map old port IDs to new port IDs
    const portIdMap: Record<string, string> = {};
    const newPorts = original.ports.map(p => {
      const newId = uuidv4();
      portIdMap[p.id] = newId;
      return { ...p, id: newId };
    });

    const newComp: CPCComponent = {
      ...JSON.parse(JSON.stringify(original)), // Deep copy everything
      id: newCompId,
      name: `${original.name}_copy`,
      x: original.x + 40,
      y: original.y + 40,
      ports: newPorts,
    };

    // Regenerate IDs for state machine if it exists
    if (newComp.stateMachine) {
      const sm = newComp.stateMachine;
      const stateIdMap: Record<string, string> = {};
      
      sm.states = sm.states.map(s => {
        const newId = uuidv4();
        stateIdMap[s.id] = newId;
        return { ...s, id: newId };
      });

      sm.transitions = sm.transitions.map(t => ({
        ...t,
        id: uuidv4(),
        sourceStateId: stateIdMap[t.sourceStateId] || t.sourceStateId,
        targetStateId: stateIdMap[t.targetStateId] || t.targetStateId,
      }));

      sm.variables = sm.variables.map(v => ({ ...v, id: uuidv4() }));
    }

    // Regenerate IDs for monitor definition if it exists
    if (newComp.monitorDefinition) {
      const md = newComp.monitorDefinition;
      md.variables = md.variables.map(v => ({ ...v, id: uuidv4() }));
      md.transitions = md.transitions.map(t => ({ ...t, id: uuidv4() }));
    }

    // Duplicate connectors
    const newConnectors: Connector[] = connectors
      .filter(c => c.sourceComponentId === id || c.targetComponentId === id)
      .map(c => {
        const isSource = c.sourceComponentId === id;
        return {
          ...c,
          id: uuidv4(),
          sourceComponentId: isSource ? newCompId : c.sourceComponentId,
          sourcePortId: isSource ? portIdMap[c.sourcePortId] : c.sourcePortId,
          targetComponentId: !isSource ? newCompId : c.targetComponentId,
          targetPortId: !isSource ? portIdMap[c.targetPortId] : c.targetPortId,
        };
      });

    setComponents([...components, newComp]);
    setConnectors([...connectors, ...newConnectors]);
    setSelectedId(newCompId);
  };

  const handleDelete = (id: string) => {
    setComponents(components.filter(c => c.id !== id));
    setConnectors(connectors.filter(c => c.id !== id && c.sourceComponentId !== id && c.targetComponentId !== id));
    setSelectedId(null);
  };

  const handleManualConnect = (sourceCompId: string, sourcePortId: string, targetCompId: string, targetPortId: string) => {
    // Check if connection already exists
    const exists = connectors.some(c => 
      (c.sourceComponentId === sourceCompId && c.sourcePortId === sourcePortId && c.targetComponentId === targetCompId && c.targetPortId === targetPortId) ||
      (c.sourceComponentId === targetCompId && c.sourcePortId === targetPortId && c.targetComponentId === sourceCompId && c.targetPortId === sourcePortId)
    );
    if (exists) return;

    // Validate port types (optional: could enforce output -> input)
    const sourceComp = components.find(c => c.id === sourceCompId);
    const targetComp = components.find(c => c.id === targetCompId);
    const sourcePort = sourceComp?.ports.find(p => p.id === sourcePortId);
    const targetPort = targetComp?.ports.find(p => p.id === targetPortId);

    if (!sourcePort || !targetPort) return;

    // Ensure communication modes match
    if (sourcePort.commMode !== targetPort.commMode) {
      alert(`Cannot connect ${sourcePort.commMode} port to ${targetPort.commMode} port.`);
      return;
    }

    const newConn: Connector = {
      id: uuidv4(),
      sourceComponentId: sourceCompId,
      sourcePortId: sourcePortId,
      targetComponentId: targetCompId,
      targetPortId: targetPortId,
      type: 'PUSH'
    };
    setConnectors([...connectors, newConn]);
    setSelectedId(newConn.id);
  };

  const viewPrismCode = () => setIsCodeOpen(true);

  const handleSaveProject = () => {
    const projectData = JSON.stringify(model, null, 2);
    const blob = new Blob([projectData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `cpc_project_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleLoadProject = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const loadedModel = JSON.parse(content) as ArchitectureModel;
        
        // A use-case file (from the Use Cases tab) is also accepted: its model is loaded
        const asAny = loadedModel as any;
        const m: ArchitectureModel = asAny.model && asAny.model.components ? asAny.model : loadedModel;
        if (m.components && m.connectors) {
          applyModel(m);
          setLoadedUseCase(m === loadedModel ? null : asAny);
        } else {
          alert('Invalid project file format.');
        }
      } catch (err) {
        console.error('Error loading project:', err);
        alert('Failed to load project file.');
      }
    };
    reader.readAsText(file);
    // Reset the input value so the same file can be loaded again if needed
    event.target.value = '';
  };

  const [showNewModelConfirm, setShowNewModelConfirm] = useState(false);
  const [canvasKey, setCanvasKey] = useState(0);

  const handleNewModel = () => {
    if (components.length > 0 || constants.length > 0) {
      setShowNewModelConfirm(true);
    } else {
      executeNewModel();
    }
  };

  const executeNewModel = () => {
    setComponents([]);
    setConnectors([]);
    setRewards([]);
    setConstants([]);
    setLabels([]);
    setFormulas([]);
    setProperties([]);
    setModelType('csg');
    setIncludeRounds(true);
    setLoadedUseCase(null);
    setSelectedId(null);
    setEditingComponentId(null);
    setEditingMonitorId(null);
    setIsEditingRewards(false);
    setIsGlobalDefsOpen(false);
    setCanvasKey(prev => prev + 1);
    setShowNewModelConfirm(false);
  };

  const selectedElement = useMemo(() => {
    return components.find(c => c.id === selectedId) || connectors.find(c => c.id === selectedId) || null;
  }, [selectedId, components, connectors]);

  const editingComponent = useMemo(() => {
    return components.find(c => c.id === editingComponentId) || null;
  }, [editingComponentId, components]);

  const editingMonitor = useMemo(() => {
    return components.find(c => c.id === editingMonitorId) || null;
  }, [editingMonitorId, components]);

  const availableActions = useMemo(() => {
    const actions = new Set<string>();
    components.forEach(c => {
      if (c.stateMachine) {
        c.stateMachine.transitions.forEach(t => {
          if (t.action) actions.add(t.action);
        });
      }
    });
    return Array.from(actions);
  }, [components]);

  const handleEditBehavior = (id: string) => {
    const comp = components.find(c => c.id === id);
    if (!comp) return;
    if (comp.type === 'MONITOR') {
      setEditingMonitorId(id);
    } else {
      setEditingComponentId(id);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-neutral-50 overflow-hidden">
      {/* Header */}
      <header className="h-16 bg-white border-b border-neutral-200 px-6 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
            <Share2 className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-neutral-900 tracking-tight whitespace-nowrap">HERMES Modeler</h1>
            <p className="text-[10px] font-medium text-neutral-400 uppercase tracking-widest whitespace-nowrap hidden 2xl:block">CPC models · CSG &amp; CTMC</p>
          </div>
          <nav className="flex items-center bg-neutral-100 p-1 rounded-lg ml-4">
            <button
              onClick={() => setActiveTab('modeler')}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap rounded-md transition-all ${activeTab === 'modeler' ? 'bg-white text-blue-600 shadow-sm' : 'text-neutral-500 hover:text-neutral-800'}`}
            >
              <PenTool className="w-4 h-4" /> Modeler
            </button>
            <button
              onClick={() => setActiveTab('usecases')}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap rounded-md transition-all ${activeTab === 'usecases' ? 'bg-white text-blue-600 shadow-sm' : 'text-neutral-500 hover:text-neutral-800'}`}
            >
              <BookOpen className="w-4 h-4" /> Use Cases
            </button>
          </nav>
        </div>

        <div className={`flex items-center gap-3 ${activeTab === 'modeler' ? '' : 'invisible'}`}>
          <div className="flex items-center gap-2 mr-1" title="Target PRISM model type">
            <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider hidden xl:inline">Model</span>
            <select
              value={modelType}
              onChange={(e) => setModelType(e.target.value as ModelType)}
              className="px-2 py-1.5 text-xs font-bold text-neutral-700 bg-neutral-100 border border-transparent rounded-md outline-none focus:border-blue-400"
            >
              <option value="csg">CSG (PRISM-games)</option>
              <option value="ctmc">CTMC</option>
              <option value="mdp">MDP</option>
              <option value="dtmc">DTMC</option>
            </select>
            {modelType === 'csg' && (
              <label className="flex items-center gap-1 text-[10px] font-bold text-neutral-500 uppercase" title="Generate the rounds counter module">
                <input type="checkbox" checked={includeRounds} onChange={(e) => setIncludeRounds(e.target.checked)} /> rounds
              </label>
            )}
          </div>
          <div className="flex items-center bg-neutral-100 p-1 rounded-lg mr-2">
            <button
              onClick={handleNewModel}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap text-neutral-600 hover:bg-white hover:text-red-600 rounded-md transition-all"
              title="Start New Model"
            >
              <FilePlus className="w-4 h-4" /> New
            </button>
            <button
              onClick={() => setIsGlobalDefsOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap text-neutral-600 hover:bg-white hover:text-indigo-600 rounded-md transition-all"
              title="Edit Constants, Labels & Formulas"
            >
              <Hash className="w-4 h-4" /> Definitions
            </button>
            <button
              onClick={() => setIsEditingRewards(true)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap text-neutral-600 hover:bg-white hover:text-amber-600 rounded-md transition-all"
              title="Edit Reward Structures"
            >
              <Coins className="w-4 h-4" /> Rewards
            </button>
            <button
              onClick={handleSaveProject}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap text-neutral-600 hover:bg-white hover:text-blue-600 rounded-md transition-all"
              title="Save Project to JSON"
            >
              <Save className="w-4 h-4" /> Save
            </button>
            <label className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap text-neutral-600 hover:bg-white hover:text-blue-600 rounded-md transition-all cursor-pointer" title="Load Project from JSON">
              <FolderOpen className="w-4 h-4" /> Load
              <input
                type="file"
                accept=".json"
                onChange={handleLoadProject}
                className="hidden"
              />
            </label>
            <button
              onClick={handleExportImage}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold whitespace-nowrap text-neutral-600 hover:bg-white hover:text-emerald-600 rounded-md transition-all"
              title="Export Diagram as PNG"
            >
              <ImageIcon className="w-4 h-4" /> PNG
            </button>
          </div>

          <button
            onClick={viewPrismCode}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium shadow-lg shadow-blue-100 transition-all whitespace-nowrap"
          >
            <Code className="w-4 h-4" />
            PRISM Code
          </button>
        </div>
      </header>

      {/* Main Content */}
      {activeTab === 'usecases' && (
        <main className="flex-1 flex overflow-hidden">
          <UseCasesView onLoad={handleLoadUseCase} currentModel={model} />
        </main>
      )}
      <main className={`flex-1 flex overflow-hidden ${activeTab === 'modeler' ? '' : 'hidden'}`}>
        <Sidebar onAddComponent={handleAddComponent} />
        
        <div className="flex-1 p-6 flex flex-col gap-4">
          <div className="flex items-center justify-between px-2">
            {loadedUseCase ? (
              <div className="flex items-center gap-2 text-xs font-medium text-blue-700 bg-blue-50 border border-blue-100 rounded-lg px-3 py-1.5">
                <BookOpen className="w-4 h-4" />
                <span>Use case: <b>{loadedUseCase.title}</b> · {loadedUseCase.formalism.toUpperCase()}{loadedUseCase.slides ? ` · ${loadedUseCase.slides}` : ''}</span>
                <button onClick={() => setActiveTab('usecases')} className="underline hover:text-blue-900 ml-1">details</button>
                <button onClick={() => setLoadedUseCase(null)} className="ml-1 text-blue-400 hover:text-blue-700"><X className="w-3.5 h-3.5" /></button>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-neutral-500">
                <Info className="w-4 h-4" />
                <span className="text-xs font-medium">Click on a port to start connection, then click another port to finish.</span>
              </div>
            )}
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                <span className="text-[10px] font-bold text-neutral-400 uppercase">Synchronous</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                <span className="text-[10px] font-bold text-neutral-400 uppercase">Asynchronous</span>
              </div>
            </div>
          </div>
          
          <Canvas
            key={canvasKey}
            components={components}
            connectors={connectors}
            onUpdateComponents={setComponents}
            onUpdateConnectors={setConnectors}
            selectedId={selectedId}
            onSelect={setSelectedId}
            onConnect={handleManualConnect}
            onEditBehavior={handleEditBehavior}
            stageRef={stageRef}
          />
        </div>

        <PropertiesPanel
          selectedElement={selectedElement}
          onUpdateComponent={handleUpdateComponent}
          onUpdateConnector={handleUpdateConnector}
          onDelete={handleDelete}
          onDuplicateComponent={handleDuplicateComponent}
          onEditBehavior={handleEditBehavior}
        />
      </main>

      {/* State Machine Editor Overlay */}
      {editingComponent && editingComponent.stateMachine && (
        <StateMachineEditor
          componentName={editingComponent.name}
          stateMachine={editingComponent.stateMachine}
          constants={constants}
          modelType={modelType}
          onUpdate={(sm) => handleUpdateComponent({ ...editingComponent, stateMachine: sm })}
          onClose={() => setEditingComponentId(null)}
        />
      )}

      {/* Monitor Editor Overlay */}
      {editingMonitor && (
        <MonitorEditor
          monitorName={editingMonitor.name}
          monitorDefinition={editingMonitor.monitorDefinition || { variables: [], transitions: [] }}
          availableActions={availableActions}
          constants={constants}
          modelType={modelType}
          onUpdate={(def) => handleUpdateComponent({ ...editingMonitor, monitorDefinition: def })}
          onClose={() => setEditingMonitorId(null)}
        />
      )}

      {/* Reward Editor Overlay */}
      {isGlobalDefsOpen && (
        <GlobalDefinitionsEditor
          constants={constants}
          labels={labels}
          formulas={formulas}
          components={components}
          onUpdateConstants={setConstants}
          onUpdateLabels={setLabels}
          onUpdateFormulas={setFormulas}
          onClose={() => setIsGlobalDefsOpen(false)}
        />
      )}

      {isEditingRewards && (
        <RewardEditor
          rewards={rewards}
          components={components}
          formulas={formulas}
          onUpdate={setRewards}
          onClose={() => setIsEditingRewards(false)}
        />
      )}

      {isCodeOpen && (
        <PrismCodeModal
          modelType={modelType}
          prismCode={prismCode}
          propsCode={propsCode}
          properties={properties}
          onUpdateProperties={setProperties}
          onClose={() => setIsCodeOpen(false)}
        />
      )}

      {/* New Model Confirmation Dialog */}
      {showNewModelConfirm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[100]">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full mx-4 border border-neutral-200">
            <div className="flex items-center gap-3 mb-4 text-amber-600">
              <div className="p-2 bg-amber-50 rounded-lg">
                <Info className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-neutral-900">Start New Model?</h3>
            </div>
            <p className="text-neutral-600 mb-6">
              Are you sure you want to start a new model? All unsaved changes in your current project will be permanently lost.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowNewModelConfirm(false)}
                className="px-4 py-2 text-sm font-bold text-neutral-600 hover:bg-neutral-100 rounded-lg transition-all"
              >
                Cancel
              </button>
              <button
                onClick={executeNewModel}
                className="px-4 py-2 text-sm font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg shadow-lg shadow-red-100 transition-all"
              >
                Clear Everything
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer / Status Bar */}
      <footer className="h-8 bg-white border-t border-neutral-200 px-6 flex items-center justify-between text-[10px] font-bold text-neutral-400 uppercase tracking-widest">
        <div className="flex gap-6">
          <span>Components: {components.length}</span>
          <span>Connectors: {connectors.length}</span>
          <span>Type: {modelType.toUpperCase()}</span>
          <span>Properties: {properties.length}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
          <span>PRISM Engine Ready</span>
        </div>
      </footer>
    </div>
  );
}
