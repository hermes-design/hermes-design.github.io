/**
 * Communication semantics of CPC ports in PRISM.
 *
 * PRISM has a single communication primitive: CSP-style multi-way synchronisation on a shared
 * action label. Hence:
 *
 *  - SYNCHRONOUS connector
 *      * DTMC / MDP / CTMC : direct — both endpoints share one action label (rendezvous).
 *                            If the two port actions have different names they are renamed to a
 *                            common label `sync_<a>_<b>`.
 *      * CSG               : NOT direct — PRISM-games requires the action sets of the players to be
 *                            disjoint. The rendezvous is the joint action [a_s, a_r]; its effect must
 *                            be written in a non-player module (Monitor). A reward "rdv_<k>" counting
 *                            the rendezvous is generated.
 *  - ASYNCHRONOUS connector — always a transformation: a FIFO channel module `chk` (message counter
 *                            of capacity CAP_chk) is inserted between the endpoints.
 *      * DTMC / MDP / CTMC : the channel synchronises on the send action (push) and on the receive
 *                            action (pop). Overflow policy BLOCK (sender waits) or DROP (message lost).
 *      * CSG               : players move simultaneously, so push and pop can happen in the same round.
 *                            Two independent [send] / [recv] commands in the channel are rejected by
 *                            PRISM-games, and a shared global variable silently loses one of the two
 *                            updates. The channel is therefore written over joint actions:
 *                              [s, r]           push + pop  (count unchanged)
 *                              [s, b] (b != r)  push        (DROP when full: a player cannot be blocked)
 *                              [a, r] (a != s)  pop
 *
 * See docs/sync-async-ports.md for the experiments behind these rules.
 */
import { ArchitectureModel, CPCComponent, Connector, ModelType, Port } from '../types';

export interface PortSemantics {
  /** compId -> (action -> renamed action), used when printing the component's commands */
  renames: Map<string, Map<string, string>>;
  constants: string;
  modules: string;
  labels: string;
  rewards: string;
  notes: string[];
}

interface Endpoint { comp: CPCComponent; port: Port; action: string }

const sanitize = (s: string) => s.replace(/[^A-Za-z0-9_]/g, '_');

export function portAction(port: Port): string {
  return sanitize((port.action && port.action.trim()) || port.name);
}

/** All action labels used by a component's own commands. */
export function componentActions(comp: CPCComponent): string[] {
  const set = new Set<string>();
  comp.stateMachine?.transitions.forEach(t => t.action && set.add(t.action));
  comp.monitorDefinition?.transitions.forEach(t => t.actions.forEach(a => set.add(a)));
  return Array.from(set);
}

function endpoints(model: ArchitectureModel, conn: Connector): [Endpoint, Endpoint] | null {
  const a = model.components.find(c => c.id === conn.sourceComponentId);
  const b = model.components.find(c => c.id === conn.targetComponentId);
  const pa = a?.ports.find(p => p.id === conn.sourcePortId);
  const pb = b?.ports.find(p => p.id === conn.targetPortId);
  if (!a || !b || !pa || !pb) return null;
  let s: Endpoint = { comp: a, port: pa, action: portAction(pa) };
  let r: Endpoint = { comp: b, port: pb, action: portAction(pb) };
  // the OUTPUT port is the sender, whatever the direction the connector was drawn in
  if (pa.type === 'INPUT' && pb.type === 'OUTPUT') [s, r] = [r, s];
  return [s, r];
}

const isPlayer = (c: CPCComponent) => c.type !== 'MONITOR' && c.properties?.isPlayer !== false;

export function computePortSemantics(model: ArchitectureModel): PortSemantics {
  const modelType: ModelType = model.modelType || 'csg';
  const csg = modelType === 'csg';
  const out: PortSemantics = { renames: new Map(), constants: '', modules: '', labels: '', rewards: '', notes: [] };

  const resolved = model.connectors
    .map(c => ({ conn: c, ep: endpoints(model, c) }))
    .filter((x): x is { conn: Connector; ep: [Endpoint, Endpoint] } => !!x.ep);

  // A connector only has a semantics if both port actions are carried by commands of their
  // components; otherwise it is kept as documentation (architecture view only).
  const missing = (e: Endpoint) => !componentActions(e.comp).includes(e.action);
  const all = resolved;
  const active = all.filter(({ ep }) => !missing(ep[0]) && !missing(ep[1]));
  all.filter(x => !active.includes(x)).forEach(({ ep: [s, r] }) => {
    const why = [s, r].filter(missing).map(e => `${e.comp.name} has no action "${e.action}"`).join(', ');
    out.notes.push(`Connector ${s.comp.name}.${s.port.name} -> ${r.comp.name}.${r.port.name}: documentation only (${why})`);
  });

  /* ---------------- synchronous connectors ---------------- */
  const sync = active.filter(x => x.ep[0].port.commMode === 'SYNCHRONOUS' && x.ep[1].port.commMode === 'SYNCHRONOUS');

  if (!csg) {
    // union-find over (component, action) so that chains / broadcasts get one shared label
    const parent = new Map<string, string>();
    const key = (e: Endpoint) => `${e.comp.id}|${e.action}`;
    const find = (k: string): string => {
      if (!parent.has(k)) parent.set(k, k);
      const p = parent.get(k)!;
      if (p === k) return k;
      const r = find(p);
      parent.set(k, r);
      return r;
    };
    sync.forEach(({ ep: [s, r] }) => parent.set(find(key(s)), find(key(r))));
    const classes = new Map<string, string[]>();
    Array.from(parent.keys()).forEach(k => {
      const root = find(k);
      if (!classes.has(root)) classes.set(root, []);
      classes.get(root)!.push(k);
    });
    classes.forEach(members => {
      const names = Array.from(new Set(members.map(m => m.split('|')[1]))).sort();
      if (names.length < 2) return; // same label already: native PRISM rendezvous
      const label = `sync_${names.join('_')}`;
      members.forEach(m => {
        const [compId, action] = m.split('|');
        if (!out.renames.has(compId)) out.renames.set(compId, new Map());
        out.renames.get(compId)!.set(action, label);
      });
    });
    sync.forEach(({ ep: [s, r] }) => {
      out.notes.push(`Sync connector ${s.comp.name}.${s.port.name} -> ${r.comp.name}.${r.port.name}: rendezvous on [${rename(out, s)}]`);
    });
  } else {
    sync.forEach(({ ep: [s, r] }, i) => {
      const k = i + 1;
      if (!isPlayer(s.comp) || !isPlayer(r.comp)) {
        out.notes.push(`WARNING: sync connector ${s.comp.name} -> ${r.comp.name}: both endpoints must be players in a CSG; skipped`);
        return;
      }
      if (s.action === r.action) {
        out.notes.push(`WARNING: sync connector ${s.comp.name} -> ${r.comp.name}: PRISM-games requires disjoint action sets, rename one of the two "${s.action}" actions`);
        return;
      }
      out.notes.push(`Sync connector ${s.comp.name}.${s.port.name} -> ${r.comp.name}.${r.port.name}: rendezvous = joint action [${s.action},${r.action}] (write its effect in a Monitor; player updates on ${s.action} / ${r.action} happen even without the partner)`);
      out.rewards += `rewards "rdv_${k}"\n  [${s.action},${r.action}] true : 1;\nendrewards\n\n`;
    });
  }

  /* ---------------- asynchronous connectors ---------------- */
  const asyncConns = active.filter(x => x.ep[0].port.commMode === 'ASYNCHRONOUS' && x.ep[1].port.commMode === 'ASYNCHRONOUS');

  asyncConns.forEach(({ conn, ep: [s, r] }, i) => {
    const ch = `ch${i + 1}`;
    const cap = `CAP_${ch}`;
    const n = `${ch}_n`;
    const capacity = Math.max(1, Math.floor(conn.capacity ?? 1));
    let overflow = conn.overflow ?? (csg ? 'DROP' : 'BLOCK');
    const sa = rename(out, s), ra = rename(out, r);
    const title = `${s.comp.name}.${s.port.name} -> ${r.comp.name}.${r.port.name}`;

    if (csg && (!isPlayer(s.comp) || !isPlayer(r.comp))) {
      out.notes.push(`WARNING: async connector ${title}: both endpoints must be players in a CSG; skipped`);
      return;
    }
    if (csg && overflow === 'BLOCK') {
      out.notes.push(`Async connector ${title}: BLOCK is impossible in a CSG (players choose freely) — DROP used`);
      overflow = 'DROP';
    }

    out.constants += `const int ${cap} = ${capacity}; // capacity of channel ${ch} (${title})\n`;
    let m = `// Asynchronous connector ${title}: FIFO channel, capacity ${cap}, overflow ${overflow}\n`;
    m += `module ${ch}\n  ${n} : [0..${cap}] init 0;\n\n`;

    if (!csg) {
      m += `  [${sa}] ${n}<${cap} -> (${n}'=${n}+1);  // push\n`;
      if (overflow === 'DROP') m += `  [${sa}] ${n}=${cap} -> true;  // full: message dropped\n`;
      m += `  [${ra}] ${n}>0 -> (${n}'=${n}-1);  // pop (the receiver waits while empty)\n`;
      out.rewards += `rewards "${ch}_received"\n  [${ra}] true : 1;\nendrewards\n\n`;
      if (overflow === 'DROP') out.rewards += `rewards "${ch}_lost"\n  [${sa}] ${n}=${cap} : 1;\nendrewards\n\n`;
    } else {
      const A = componentActions(s.comp).filter(a => a !== s.action);
      const B = componentActions(r.comp).filter(b => b !== r.action);
      m += `  [${s.action},${r.action}] true -> true;  // push and pop in the same round\n`;
      B.forEach(b => {
        m += `  [${s.action},${b}] ${n}<${cap} -> (${n}'=${n}+1);  // push\n`;
        m += `  [${s.action},${b}] ${n}=${cap} -> true;  // full: message dropped\n`;
      });
      A.forEach(a => {
        m += `  [${a},${r.action}] ${n}>0 -> (${n}'=${n}-1);  // pop\n`;
      });
      out.rewards += `rewards "${ch}_received"\n  [${s.action},${r.action}] true : 1;\n${A.map(a => `  [${a},${r.action}] ${n}>0 : 1;\n`).join('')}endrewards\n\n`;
      out.rewards += `rewards "${ch}_lost"\n${B.map(b => `  [${s.action},${b}] ${n}=${cap} : 1;\n`).join('')}endrewards\n\n`;
      out.notes.push(`Async connector ${title}: channel ${ch} written over ${1 + 2 * B.length + A.length} joint-action commands`);
    }
    m += `endmodule\n\n`;
    out.modules += m;
    out.labels += `label "${ch}_full" = ${n}=${cap};\nlabel "${ch}_empty" = ${n}=0;\n`;
  });

  return out;
}

function rename(sem: PortSemantics, e: Endpoint): string {
  return sem.renames.get(e.comp.id)?.get(e.action) ?? e.action;
}

