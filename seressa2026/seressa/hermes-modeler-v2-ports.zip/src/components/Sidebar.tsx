import React from 'react';
import { Cpu, Radio, ShieldAlert, Activity, Plus, Satellite, TowerControl, Box, Monitor as MonitorIcon } from 'lucide-react';
import { ComponentType } from '../types';

interface SidebarProps {
  onAddComponent: (type: ComponentType) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onAddComponent }) => {
  const tools = [
    { type: 'SENSOR' as ComponentType, label: 'Sensor', icon: Activity, color: 'text-blue-600' },
    { type: 'ACTUATOR' as ComponentType, label: 'Actuator', icon: Radio, color: 'text-green-600' },
    { type: 'GATEWAY' as ComponentType, label: 'Edge Gateway', icon: Cpu, color: 'text-purple-600' },
    { type: 'SATELLITE' as ComponentType, label: 'Satellite', icon: Satellite, color: 'text-indigo-600' },
    { type: 'STATION' as ComponentType, label: 'Station', icon: TowerControl, color: 'text-orange-600' },
    { type: 'BASIC' as ComponentType, label: 'Basic Component', icon: Box, color: 'text-neutral-600' },
    { type: 'MONITOR' as ComponentType, label: 'Monitor', icon: MonitorIcon, color: 'text-cyan-600' },
    { type: 'ATTACKER' as ComponentType, label: 'Attacker', icon: ShieldAlert, color: 'text-red-600' },
  ];

  return (
    <div className="w-64 bg-white border-r border-neutral-200 p-4 flex flex-col gap-6">
      <div>
        <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-4">Components</h3>
        <div className="grid grid-cols-1 gap-2">
          {tools.map((tool) => (
            <button
              key={tool.type}
              onClick={() => onAddComponent(tool.type)}
              className="flex items-center gap-3 p-3 rounded-lg border border-neutral-100 hover:border-blue-200 hover:bg-blue-50 transition-all group text-left"
            >
              <tool.icon className={`w-5 h-5 ${tool.color}`} />
              <span className="text-sm font-medium text-neutral-700">{tool.label}</span>
              <Plus className="w-4 h-4 ml-auto text-neutral-300 group-hover:text-blue-400" />
            </button>
          ))}
        </div>
      </div>

      <div className="mt-auto p-4 bg-neutral-50 rounded-xl border border-neutral-100">
        <p className="text-xs text-neutral-500 leading-relaxed">
          Drag components to the workspace and connect them to model your Edge/IoT architecture.
        </p>
      </div>
    </div>
  );
};
