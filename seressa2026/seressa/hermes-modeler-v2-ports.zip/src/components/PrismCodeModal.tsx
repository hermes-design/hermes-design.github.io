import React, { useState } from 'react';
import { X, Download, Copy, Check, Plus, Trash2 } from 'lucide-react';
import { ModelType, PropertySpec } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface PrismCodeModalProps {
  modelType: ModelType;
  prismCode: string;
  propsCode: string;
  properties: PropertySpec[];
  onUpdateProperties: (p: PropertySpec[]) => void;
  onClose: () => void;
}

function download(name: string, content: string) {
  const url = URL.createObjectURL(new Blob([content], { type: 'text/plain' }));
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

const EXAMPLES: Record<ModelType, string> = {
  csg: '<<p1>> Pmax=? [ F "goal" ]',
  ctmc: 'P=? [ F<=T "failure" ]',
  mdp: 'Pmax=? [ F "goal" ]',
  dtmc: 'P=? [ F "goal" ]',
};

export const PrismCodeModal: React.FC<PrismCodeModalProps> = ({ modelType, prismCode, propsCode, properties, onUpdateProperties, onClose }) => {
  const [tab, setTab] = useState<'model' | 'props'>('model');
  const [copied, setCopied] = useState(false);
  const code = tab === 'model' ? prismCode : propsCode;
  const ext = 'prism';

  const update = (id: string, patch: Partial<PropertySpec>) =>
    onUpdateProperties(properties.map(p => (p.id === id ? { ...p, ...patch } : p)));

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[90] p-6">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[85vh] flex flex-col overflow-hidden border border-neutral-200">
        <div className="h-14 px-5 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h3 className="font-bold text-neutral-900">Generated PRISM code</h3>
            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">{modelType}</span>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-neutral-100 text-neutral-500"><X className="w-5 h-5" /></button>
        </div>
        <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="px-5 py-2 flex items-center justify-between border-b border-neutral-100">
              <div className="flex gap-1">
                {(['model', 'props'] as const).map(t => (
                  <button key={t} onClick={() => setTab(t)} className={`px-3 py-1.5 rounded-md text-xs font-bold ${tab === t ? 'bg-neutral-900 text-white' : 'text-neutral-500 hover:bg-neutral-100'}`}>
                    {t === 'model' ? `model.${ext}` : 'model.props'}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => navigator.clipboard?.writeText(code).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1200); })}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 rounded-md"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />} Copy
                </button>
                <button onClick={() => download(`model.${ext}`, prismCode)} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-md">
                  <Download className="w-3.5 h-3.5" /> Model
                </button>
                <button onClick={() => download('model.props', propsCode)} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-md">
                  <Download className="w-3.5 h-3.5" /> Properties
                </button>
              </div>
            </div>
            <pre className="flex-1 overflow-auto bg-neutral-900 text-neutral-100 text-xs font-mono p-5 leading-relaxed">{code}</pre>
          </div>
          <aside className="w-96 border-l border-neutral-200 flex flex-col">
            <div className="px-4 py-3 border-b border-neutral-100 flex items-center justify-between">
              <h4 className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Properties ({modelType === 'csg' ? 'rPATL' : modelType === 'ctmc' ? 'CSL' : 'PCTL'})</h4>
              <button
                onClick={() => onUpdateProperties([...properties, { id: uuidv4(), name: '', formula: EXAMPLES[modelType] }])}
                className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2">
              {properties.length === 0 && <p className="text-xs text-neutral-400 p-2">No property yet. Example: <code>{EXAMPLES[modelType]}</code></p>}
              {properties.map(p => (
                <div key={p.id} className="border border-neutral-200 rounded-lg p-2.5 flex flex-col gap-1.5 group">
                  <div className="flex items-center gap-2">
                    <input value={p.name || ''} onChange={e => update(p.id, { name: e.target.value })} placeholder="Name" className="flex-1 text-xs font-semibold outline-none" />
                    <button onClick={() => onUpdateProperties(properties.filter(x => x.id !== p.id))} className="text-neutral-300 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                  <textarea
                    value={p.formula}
                    onChange={e => update(p.id, { formula: e.target.value })}
                    rows={2}
                    className="text-xs font-mono text-indigo-700 border border-neutral-100 rounded px-2 py-1 outline-none focus:border-blue-400 resize-y"
                  />
                </div>
              ))}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};
