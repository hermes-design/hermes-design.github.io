import React from 'react';
import { MonitorDefinition, MonitorTransition, ProbabilisticUpdate, CPCComponent, Constant } from '../types';
import { ModelType } from '../types';
import { updateWeightLabel } from '../lib/prismGenerator';
import { X, Plus, Trash2, Save, Info, Table as TableIcon, Hash } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface MonitorEditorProps {
  monitorName: string;
  monitorDefinition: MonitorDefinition;
  availableActions: string[];
  constants: Constant[];
  modelType?: ModelType;
  onUpdate: (def: MonitorDefinition) => void;
  onClose: () => void;
}

export const MonitorEditor: React.FC<MonitorEditorProps> = ({
  monitorName,
  monitorDefinition,
  availableActions,
  constants,
  modelType,
  onUpdate,
  onClose,
}) => {
  const [activeVarDropdown, setActiveVarDropdown] = React.useState<string | null>(null);

  React.useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (!(e.target as HTMLElement).closest('.addvar-dropdown-container')) {
        setActiveVarDropdown(null);
      }
    };
    if (activeVarDropdown) {
      document.addEventListener('click', handleClickOutside);
    }
    return () => document.removeEventListener('click', handleClickOutside);
  }, [activeVarDropdown]);

  const handleAddTransition = () => {
    const newTransition: MonitorTransition = {
      id: uuidv4(),
      actions: [],
      guard: 's = 0',
      updates: [{ probability: 1, assignments: { "s": "1" } }],
    };
    onUpdate({
      ...monitorDefinition,
      transitions: [...monitorDefinition.transitions, newTransition],
    });
  };

  const handleUpdateTransition = (id: string, updates: Partial<MonitorTransition>) => {
    const newTransitions = monitorDefinition.transitions.map((t) =>
      t.id === id ? { ...t, ...updates } : t
    );
    onUpdate({ ...monitorDefinition, transitions: newTransitions });
  };

  const handleDeleteTransition = (id: string) => {
    const newTransitions = monitorDefinition.transitions.filter((t) => t.id !== id);
    onUpdate({ ...monitorDefinition, transitions: newTransitions });
  };

  const handleAddUpdate = (transitionId: string) => {
    const transition = monitorDefinition.transitions.find(t => t.id === transitionId);
    if (!transition) return;
    const newUpdates = [...transition.updates, { probability: 0, assignments: {} }];
    handleUpdateTransition(transitionId, { updates: newUpdates });
  };

  const handleUpdateProbUpdate = (transitionId: string, updateIdx: number, updates: Partial<ProbabilisticUpdate>) => {
    const transition = monitorDefinition.transitions.find(t => t.id === transitionId);
    if (!transition) return;
    const newUpdates = [...transition.updates];
    newUpdates[updateIdx] = { ...newUpdates[updateIdx], ...updates };
    handleUpdateTransition(transitionId, { updates: newUpdates });
  };

  const handleRemoveProbUpdate = (transitionId: string, updateIdx: number) => {
    const transition = monitorDefinition.transitions.find(t => t.id === transitionId);
    if (!transition) return;
    const newUpdates = transition.updates.filter((_, i) => i !== updateIdx);
    handleUpdateTransition(transitionId, { updates: newUpdates });
  };

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col animate-in fade-in duration-200">
      {/* Header */}
      <div className="h-16 border-b border-neutral-200 px-6 flex items-center justify-between bg-neutral-50">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-neutral-200 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
          <div>
            <h2 className="font-bold text-neutral-900">Monitor Table: {monitorName}</h2>
            <p className="text-xs text-neutral-500 italic">PRISM Global Monitor Definition</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleAddTransition}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-bold shadow-lg shadow-blue-100"
          >
            <Plus className="w-4 h-4" /> Add Transition
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-8 bg-neutral-50">
        <div className="max-w-6xl mx-auto space-y-8">
          {/* Variables Section */}
          <div className="bg-white rounded-xl border border-neutral-200 shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-neutral-900 uppercase tracking-wider">Monitor Variables</h3>
              <button
                onClick={() => {
                  const newVar = { id: uuidv4(), name: 'v', min: 0, max: 1, init: 0 };
                  onUpdate({ ...monitorDefinition, variables: [...(monitorDefinition.variables || []), newVar] });
                }}
                className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1"
              >
                <Plus className="w-3 h-3" /> Add Variable
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {(monitorDefinition.variables || []).map((v) => (
                <div key={v.id} className="p-3 bg-neutral-50 rounded-lg border border-neutral-100 relative group">
                  <button
                    onClick={() => {
                      const variableToDelete = v;
                      const newVars = monitorDefinition.variables.filter(x => x.id !== variableToDelete.id);
                      
                      // Clean up assignments in all transitions
                      const newTransitions = monitorDefinition.transitions.map(t => ({
                        ...t,
                        updates: t.updates.map(u => {
                          const newAssignments = { ...u.assignments };
                          delete newAssignments[variableToDelete.name];
                          return { ...u, assignments: newAssignments };
                        })
                      }));

                      onUpdate({ 
                        ...monitorDefinition, 
                        variables: newVars,
                        transitions: newTransitions
                      });
                    }}
                    className="absolute top-1 right-1 p-1 text-neutral-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                  <div className="flex flex-col gap-2">
                    <input
                      type="text"
                      value={v.name}
                      onChange={(e) => onUpdate({ ...monitorDefinition, variables: monitorDefinition.variables.map(x => x.id === v.id ? { ...x, name: e.target.value } : x) })}
                      className="text-xs font-bold bg-transparent border-none outline-none focus:ring-1 focus:ring-blue-500 rounded px-1"
                    />
                    <div className="grid grid-cols-3 gap-1">
                      <div className="flex flex-col">
                        <label className="text-[8px] font-bold text-neutral-400 uppercase">Min</label>
                        <input
                          type="number"
                          value={isNaN(v.min) ? '' : v.min}
                          onChange={(e) => onUpdate({ ...monitorDefinition, variables: monitorDefinition.variables.map(x => x.id === v.id ? { ...x, min: parseInt(e.target.value) } : x) })}
                          className="p-1 text-[10px] border border-neutral-200 rounded outline-none"
                        />
                      </div>
                      <div className="flex flex-col">
                        <label className="text-[8px] font-bold text-neutral-400 uppercase">Max</label>
                        <input
                          type="number"
                          value={isNaN(v.max) ? '' : v.max}
                          onChange={(e) => onUpdate({ ...monitorDefinition, variables: monitorDefinition.variables.map(x => x.id === v.id ? { ...x, max: parseInt(e.target.value) } : x) })}
                          className="p-1 text-[10px] border border-neutral-200 rounded outline-none"
                        />
                      </div>
                      <div className="flex flex-col">
                        <label className="text-[8px] font-bold text-neutral-400 uppercase">Init</label>
                        <input
                          type="number"
                          value={isNaN(v.init) ? '' : v.init}
                          onChange={(e) => onUpdate({ ...monitorDefinition, variables: monitorDefinition.variables.map(x => x.id === v.id ? { ...x, init: parseInt(e.target.value) } : x) })}
                          className="p-1 text-[10px] border border-neutral-200 rounded outline-none"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Transitions Table */}
          <div className="bg-white rounded-xl border border-neutral-200 shadow-sm overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-neutral-50 border-b border-neutral-200">
                  <th className="p-4 text-xs font-bold text-neutral-500 uppercase tracking-wider w-1/4">Actions</th>
                  <th className="p-4 text-xs font-bold text-neutral-500 uppercase tracking-wider w-1/4">Guard (Current State)</th>
                  <th className="p-4 text-xs font-bold text-neutral-500 uppercase tracking-wider">Probabilistic Updates (Next State)</th>
                  <th className="p-4 text-xs font-bold text-neutral-500 uppercase tracking-wider w-16"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {monitorDefinition.transitions.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-12 text-center text-neutral-400 italic">
                      No transitions defined. Click "Add Transition" to start.
                    </td>
                  </tr>
                ) : (
                  monitorDefinition.transitions.map((t) => (
                    <tr key={t.id} className="hover:bg-neutral-50 transition-colors group">
                      <td className="p-4 align-top">
                        <div className="flex flex-wrap gap-1 mb-2">
                          {t.actions.map((action, idx) => (
                            <span key={idx} className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-[10px] font-bold">
                              {action}
                              <button 
                                onClick={() => handleUpdateTransition(t.id, { actions: t.actions.filter((_, i) => i !== idx) })}
                                className="hover:text-blue-900"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                        <select
                          className="w-full p-1 text-xs border border-neutral-200 rounded outline-none focus:ring-1 focus:ring-blue-500"
                          onChange={(e) => {
                            if (e.target.value && !t.actions.includes(e.target.value)) {
                              handleUpdateTransition(t.id, { actions: [...t.actions, e.target.value] });
                            }
                            e.target.value = "";
                          }}
                          value=""
                        >
                          <option value="">+ Add Action</option>
                          {availableActions.filter(a => !t.actions.includes(a)).map(a => (
                            <option key={a} value={a}>{a}</option>
                          ))}
                        </select>
                      </td>
                      <td className="p-4 align-top">
                        <input
                          type="text"
                          value={t.guard}
                          onChange={(e) => handleUpdateTransition(t.id, { guard: e.target.value })}
                          className="w-full p-2 border border-neutral-200 rounded font-mono text-xs focus:ring-1 focus:ring-blue-500 outline-none"
                          placeholder="e.g. s = 1"
                        />
                      </td>
                      <td className="p-4 align-top">
                        <div className="space-y-3">
                          {t.updates.map((u, idx) => (
                            <div key={idx} className="flex items-start gap-3 p-3 bg-neutral-50 rounded-lg border border-neutral-100 relative group/update">
                              <button
                                onClick={() => handleRemoveProbUpdate(t.id, idx)}
                                className="absolute -top-2 -right-2 p-1 bg-white border border-neutral-200 rounded-full text-red-400 hover:text-red-600 opacity-0 group-hover/update:opacity-100 transition-opacity shadow-sm"
                              >
                                <X className="w-3 h-3" />
                              </button>
                              <div className="flex flex-col gap-1 flex-1">
                                <div className="flex items-center justify-between">
                                  <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-wider">{updateWeightLabel(modelType)}</label>
                                  <div className="flex flex-wrap gap-1">
                                    {constants.filter(c => c.type === 'double').map(c => (
                                      <button
                                        key={c.id}
                                        onClick={() => handleUpdateProbUpdate(t.id, idx, { probability: c.name })}
                                        className="px-1 py-0.5 bg-indigo-50 text-indigo-600 rounded text-[8px] font-bold hover:bg-indigo-100 transition-colors border border-indigo-100"
                                        title={`Use constant: ${c.name}`}
                                      >
                                        {c.name}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                                <input
                                  type="text"
                                  placeholder="e.g. 0.8 or p"
                                  value={u.probability}
                                  onChange={(e) => handleUpdateProbUpdate(t.id, idx, { probability: e.target.value })}
                                  className="w-full px-2 py-1 bg-white border border-neutral-200 rounded text-xs font-mono focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                                />
                              </div>
                              <div className="flex-1 flex flex-col gap-1">
                                <label className="text-[9px] font-bold text-neutral-400 uppercase">Assignments</label>
                                <div className="flex flex-wrap gap-2">
                                  {Object.entries(u.assignments || {}).map(([varName, val]) => (
                                    <div key={varName} className="flex items-center gap-1 bg-white border border-neutral-200 rounded px-2 py-1 shadow-sm">
                                      <span className="text-[10px] font-mono text-neutral-500">{varName}'=</span>
                                      <input
                                        type="text"
                                        value={val}
                                        onChange={(e) => {
                                          const newAssignments = { ...(u.assignments || {}), [varName]: e.target.value };
                                          handleUpdateProbUpdate(t.id, idx, { assignments: newAssignments });
                                        }}
                                        className="w-20 p-0 text-[10px] font-mono outline-none focus:text-blue-600"
                                        placeholder="val"
                                      />
                                      <button 
                                        onClick={() => {
                                          const newAssignments = { ...(u.assignments || {}) };
                                          delete newAssignments[varName];
                                          handleUpdateProbUpdate(t.id, idx, { assignments: newAssignments });
                                        }}
                                        className="text-neutral-300 hover:text-red-500 transition-colors"
                                      >
                                        <X className="w-3 h-3" />
                                      </button>
                                    </div>
                                  ))}
                                  <div className="relative addvar-dropdown-container">
                                    <button
                                      onClick={() => setActiveVarDropdown(activeVarDropdown === `${t.id}-${idx}` ? null : `${t.id}-${idx}`)}
                                      className="px-2 py-1 border border-dashed border-neutral-300 rounded text-[10px] text-neutral-400 hover:border-blue-300 hover:text-blue-500 transition-colors"
                                    >
                                      + Var
                                    </button>
                                    {activeVarDropdown === `${t.id}-${idx}` && (
                                      <div className="absolute left-0 bottom-full mb-1 bg-white border border-neutral-200 rounded shadow-xl z-20 min-w-[120px]">
                                      <div className="p-2 border-b border-neutral-100 bg-neutral-50 text-[9px] font-bold text-neutral-400 uppercase">Select Variable</div>
                                      {(monitorDefinition.variables || []).filter(v => !(u.assignments || {})[v.name]).length === 0 ? (
                                        <div className="p-3 text-[10px] text-neutral-400 italic">No more variables</div>
                                      ) : (
                                        <div className="max-h-40 overflow-y-auto">
                                          {(monitorDefinition.variables || []).filter(v => !(u.assignments || {})[v.name]).map(v => (
                                            <button
                                              key={v.id}
                                              onClick={() => {
                                                const newAssignments = { ...(u.assignments || {}), [v.name]: "0" };
                                                handleUpdateProbUpdate(t.id, idx, { assignments: newAssignments });
                                                setActiveVarDropdown(null);
                                              }}
                                              className="w-full text-left px-3 py-2 text-[10px] hover:bg-blue-50 text-neutral-600 font-mono border-b border-neutral-50 last:border-0"
                                            >
                                              {v.name}'
                                            </button>
                                          ))}
                                        </div>
                                      )}
                                      <div className="p-1 bg-neutral-50">
                                        <button
                                          onClick={() => {
                                            const customVar = window.prompt("Enter custom variable name:");
                                            if (customVar) {
                                              const newAssignments = { ...(u.assignments || {}), [customVar]: "0" };
                                              handleUpdateProbUpdate(t.id, idx, { assignments: newAssignments });
                                              setActiveVarDropdown(null);
                                            }
                                          }}
                                          className="w-full text-left px-2 py-1.5 text-[9px] text-blue-500 hover:bg-white rounded font-bold"
                                        >
                                          + Custom Variable...
                                        </button>
                                      </div>
                                    </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                          <button
                            onClick={() => handleAddUpdate(t.id)}
                            className="text-[10px] font-bold text-blue-600 hover:underline flex items-center gap-1"
                          >
                            <Plus className="w-3 h-3" /> Add Probabilistic Branch
                          </button>
                        </div>
                      </td>
                      <td className="p-4 align-top">
                        <button
                          onClick={() => handleDeleteTransition(t.id)}
                          className="p-2 text-neutral-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-8 p-6 bg-blue-50 rounded-xl border border-blue-100 flex items-start gap-4">
            <Info className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
            <div className="text-sm text-blue-800 leading-relaxed">
              <p className="font-bold mb-1">PRISM Syntax Guide</p>
              <p>Each row represents a global transition. The syntax generated will be:</p>
              <code className="block mt-2 p-2 bg-white rounded border border-blue-200 text-xs font-mono">
                [ action1, action2, ..., actionN ] guard -{">"} prob1 : (var1'=val1) & ( ...) + prob2 : (var2'=val2) & (...);
              </code>
              <p className="mt-2">Actions are synchronized across all modules that share the same action label.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
