import React, { useState } from 'react';
import { Constant, Label, Formula, CPCComponent } from '../types';
import { X, Plus, Trash2, Info, Hash, Type, Code, Search, ChevronRight, AlertCircle } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface GlobalDefinitionsEditorProps {
  constants: Constant[];
  labels: Label[];
  formulas: Formula[];
  components: CPCComponent[];
  onUpdateConstants: (constants: Constant[]) => void;
  onUpdateLabels: (labels: Label[]) => void;
  onUpdateFormulas: (formulas: Formula[]) => void;
  onClose: () => void;
}

type Tab = 'constants' | 'labels' | 'formulas';

export const GlobalDefinitionsEditor: React.FC<GlobalDefinitionsEditorProps> = ({
  constants,
  labels,
  formulas,
  components,
  onUpdateConstants,
  onUpdateLabels,
  onUpdateFormulas,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<Tab>('constants');
  const [selectedCompId, setSelectedCompId] = useState<string | null>(components[0]?.id || null);

  const selectedComponent = components.find(c => c.id === selectedCompId);

  // Constants Handlers
  const addConstant = () => {
    const newConstant: Constant = {
      id: uuidv4(),
      name: `CONST_${constants.length + 1}`,
      type: 'int',
      value: '0',
    };
    onUpdateConstants([...constants, newConstant]);
  };

  const updateConstant = (id: string, updates: Partial<Constant>) => {
    onUpdateConstants(constants.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const removeConstant = (id: string) => {
    onUpdateConstants(constants.filter(c => c.id !== id));
  };

  // Labels Handlers
  const addLabel = () => {
    const newLabel: Label = {
      id: uuidv4(),
      name: `label_${labels.length + 1}`,
      expression: 'true',
    };
    onUpdateLabels([...labels, newLabel]);
  };

  const updateLabel = (id: string, updates: Partial<Label>) => {
    onUpdateLabels(labels.map(l => l.id === id ? { ...l, ...updates } : l));
  };

  const removeLabel = (id: string) => {
    onUpdateLabels(labels.filter(l => l.id !== id));
  };

  // Formulas Handlers
  const addFormula = () => {
    const newFormula: Formula = {
      id: uuidv4(),
      name: `formula_${formulas.length + 1}`,
      expression: '0',
    };
    onUpdateFormulas([...formulas, newFormula]);
  };

  const updateFormula = (id: string, updates: Partial<Formula>) => {
    onUpdateFormulas(formulas.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const removeFormula = (id: string) => {
    onUpdateFormulas(formulas.filter(f => f.id !== id));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[85vh] flex flex-col overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between bg-[#fdfdfd]">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center">
              <Hash className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-neutral-900">Global Definitions</h2>
              <p className="text-xs text-neutral-500 font-medium uppercase tracking-wider mt-1">Constants, Labels & Formulas</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-neutral-100 rounded-full transition-colors">
            <X className="w-6 h-6 text-neutral-400" />
          </button>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar Tabs */}
          <div className="w-64 border-r border-neutral-100 bg-[#fafafa] p-4 flex flex-col gap-2">
            <button
              onClick={() => setActiveTab('constants')}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all ${activeTab === 'constants' ? 'bg-white shadow-sm border border-neutral-200 text-indigo-600' : 'text-neutral-500 hover:bg-neutral-100'}`}
            >
              <Hash className="w-4 h-4" />
              <span className="text-sm font-bold">Constants</span>
              <span className="ml-auto text-[10px] bg-neutral-200 text-neutral-600 px-1.5 py-0.5 rounded-full">{constants.length}</span>
            </button>
            <button
              onClick={() => setActiveTab('labels')}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all ${activeTab === 'labels' ? 'bg-white shadow-sm border border-neutral-200 text-indigo-600' : 'text-neutral-500 hover:bg-neutral-100'}`}
            >
              <Type className="w-4 h-4" />
              <span className="text-sm font-bold">Labels</span>
              <span className="ml-auto text-[10px] bg-neutral-200 text-neutral-600 px-1.5 py-0.5 rounded-full">{labels.length}</span>
            </button>
            <button
              onClick={() => setActiveTab('formulas')}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all ${activeTab === 'formulas' ? 'bg-white shadow-sm border border-neutral-200 text-indigo-600' : 'text-neutral-500 hover:bg-neutral-100'}`}
            >
              <Code className="w-4 h-4" />
              <span className="text-sm font-bold">Formulas</span>
              <span className="ml-auto text-[10px] bg-neutral-200 text-neutral-600 px-1.5 py-0.5 rounded-full">{formulas.length}</span>
            </button>

            <div className="mt-auto p-4 bg-indigo-50 rounded-xl border border-indigo-100">
              <div className="flex items-center gap-2 mb-2">
                <Info className="w-3.5 h-3.5 text-indigo-600" />
                <span className="text-[10px] font-bold text-indigo-600 uppercase">Pro Tip</span>
              </div>
              <p className="text-[10px] text-indigo-700 leading-relaxed">
                Use constants for model parameters, labels for property checking, and formulas for reusable logic.
              </p>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
            {activeTab === 'constants' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-neutral-900">Model Constants</h3>
                    <p className="text-sm text-neutral-500">Define global parameters for your PRISM model.</p>
                  </div>
                  <button
                    onClick={addConstant}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-bold"
                  >
                    <Plus className="w-4 h-4" /> Add Constant
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {constants.map((c) => (
                    <div key={c.id} className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 flex items-center gap-4 group hover:border-indigo-200 transition-all">
                      <div className="flex-1 grid grid-cols-3 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Name</label>
                          <input
                            type="text"
                            value={c.name}
                            onChange={(e) => updateConstant(c.id, { name: e.target.value })}
                            className="w-full px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500/20 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Type</label>
                          <select
                            value={c.type}
                            onChange={(e) => updateConstant(c.id, { type: e.target.value as any })}
                            className="w-full px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
                          >
                            <option value="int">int</option>
                            <option value="double">double</option>
                            <option value="bool">bool</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Value (Optional)</label>
                          <input
                            type="text"
                            value={c.value || ''}
                            placeholder="Undefined"
                            onChange={(e) => updateConstant(c.id, { value: e.target.value })}
                            className="w-full px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500/20 outline-none"
                          />
                        </div>
                      </div>
                      <button
                        onClick={() => removeConstant(c.id)}
                        className="p-2 text-neutral-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  {constants.length === 0 && (
                    <div className="py-12 border-2 border-dashed border-neutral-100 rounded-2xl flex flex-col items-center justify-center text-neutral-400">
                      <Hash className="w-8 h-8 mb-2 opacity-20" />
                      <p className="text-sm font-medium">No constants defined yet</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'labels' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-neutral-900">Model Labels</h3>
                    <p className="text-sm text-neutral-500">Define boolean expressions to identify specific states.</p>
                  </div>
                  <button
                    onClick={addLabel}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-bold"
                  >
                    <Plus className="w-4 h-4" /> Add Label
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {labels.map((l) => (
                    <div key={l.id} className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 flex flex-col gap-4 group hover:border-indigo-200 transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex-1 max-w-xs">
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Label Name</label>
                          <input
                            type="text"
                            value={l.name}
                            onChange={(e) => updateLabel(l.id, { name: e.target.value })}
                            className="w-full px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500/20 outline-none"
                          />
                        </div>
                        <button
                          onClick={() => removeLabel(l.id)}
                          className="p-2 text-neutral-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Boolean Expression</label>
                        <textarea
                          value={l.expression}
                          onChange={(e) => updateLabel(l.id, { expression: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500/20 outline-none h-20 resize-none"
                          placeholder="(s=5) & (energy > 10)"
                        />
                      </div>
                    </div>
                  ))}
                  {labels.length === 0 && (
                    <div className="py-12 border-2 border-dashed border-neutral-100 rounded-2xl flex flex-col items-center justify-center text-neutral-400">
                      <Type className="w-8 h-8 mb-2 opacity-20" />
                      <p className="text-sm font-medium">No labels defined yet</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'formulas' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-neutral-900">Model Formulas</h3>
                    <p className="text-sm text-neutral-500">Define reusable mathematical or logical expressions.</p>
                  </div>
                  <button
                    onClick={addFormula}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-bold"
                  >
                    <Plus className="w-4 h-4" /> Add Formula
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {formulas.map((f) => (
                    <div key={f.id} className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 flex flex-col gap-4 group hover:border-indigo-200 transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex-1 max-w-xs">
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Formula Name</label>
                          <input
                            type="text"
                            value={f.name}
                            onChange={(e) => updateFormula(f.id, { name: e.target.value })}
                            className="w-full px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500/20 outline-none"
                          />
                        </div>
                        <button
                          onClick={() => removeFormula(f.id)}
                          className="p-2 text-neutral-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Expression</label>
                        <textarea
                          value={f.expression}
                          onChange={(e) => updateFormula(f.id, { expression: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500/20 outline-none h-20 resize-none"
                          placeholder="p * (1 - q)"
                        />
                      </div>
                    </div>
                  ))}
                  {formulas.length === 0 && (
                    <div className="py-12 border-2 border-dashed border-neutral-100 rounded-2xl flex flex-col items-center justify-center text-neutral-400">
                      <Code className="w-8 h-8 mb-2 opacity-20" />
                      <p className="text-sm font-medium">No formulas defined yet</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Component Browser Sidebar */}
          <div className="w-80 border-l border-neutral-100 bg-[#fdfdfd] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-neutral-100 bg-white">
              <div className="flex items-center gap-2 mb-3">
                <Search className="w-4 h-4 text-neutral-400" />
                <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Component Browser</h4>
              </div>
              <select
                value={selectedCompId || ''}
                onChange={(e) => setSelectedCompId(e.target.value)}
                className="w-full p-2 bg-neutral-50 border border-neutral-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                {components.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
              {selectedComponent ? (
                <>
                  {/* States & Variables */}
                  <div>
                    <h5 className="text-[10px] font-bold text-neutral-400 uppercase mb-3 flex items-center gap-2">
                      <div className="w-1 h-1 bg-indigo-400 rounded-full" />
                      States & Variables
                    </h5>
                    <div className="space-y-2">
                      {selectedComponent.stateMachine?.states.map(s => (
                        <button
                          key={s.id}
                          onClick={() => copyToClipboard(`${selectedComponent.name.toLowerCase()}.s=${s.value}`)}
                          className="w-full text-left p-2 rounded-lg hover:bg-indigo-50 border border-transparent hover:border-indigo-100 transition-all group"
                        >
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="text-xs font-bold text-neutral-700">{s.name}</span>
                            <span className="text-[9px] font-mono text-neutral-400 group-hover:text-indigo-500">s={s.value}</span>
                          </div>
                          <p className="text-[10px] text-neutral-400 truncate">{selectedComponent.name.toLowerCase()}.s=${s.value}</p>
                        </button>
                      ))}
                      {(selectedComponent.stateMachine?.variables || selectedComponent.monitorDefinition?.variables || []).map(v => (
                        <button
                          key={v.id}
                          onClick={() => copyToClipboard(`${selectedComponent.name.toLowerCase()}.${v.name}`)}
                          className="w-full text-left p-2 rounded-lg hover:bg-indigo-50 border border-transparent hover:border-indigo-100 transition-all group"
                        >
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="text-xs font-bold text-neutral-700">{v.name}</span>
                            <span className="text-[9px] font-mono text-neutral-400 group-hover:text-indigo-500">var</span>
                          </div>
                          <p className="text-[10px] text-neutral-400 truncate">{selectedComponent.name.toLowerCase()}.${v.name}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div>
                    <h5 className="text-[10px] font-bold text-neutral-400 uppercase mb-3 flex items-center gap-2">
                      <div className="w-1 h-1 bg-amber-400 rounded-full" />
                      Actions
                    </h5>
                    <div className="flex flex-wrap gap-2">
                      {Array.from(new Set([
                        ...(selectedComponent.stateMachine?.transitions.map(t => t.action) || []),
                        ...(selectedComponent.monitorDefinition?.transitions.flatMap(t => t.actions) || [])
                      ].filter(Boolean))).map(action => (
                        <button
                          key={action as string}
                          onClick={() => copyToClipboard(action as string)}
                          className="px-2 py-1 bg-amber-50 text-amber-700 border border-amber-100 rounded text-[10px] font-bold hover:bg-amber-100 transition-colors"
                        >
                          {action as string}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-4 text-neutral-400">
                  <Search className="w-8 h-8 mb-2 opacity-20" />
                  <p className="text-[10px] font-medium leading-relaxed">Select a component to browse its states and actions.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-100 bg-[#fdfdfd] flex items-center justify-between">
          <div className="flex items-center gap-2 text-neutral-400">
            <AlertCircle className="w-4 h-4" />
            <span className="text-[10px] font-medium">Changes are saved automatically to the model.</span>
          </div>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-neutral-900 text-white rounded-lg hover:bg-neutral-800 transition-colors text-sm font-bold shadow-sm"
          >
            Close Editor
          </button>
        </div>
      </div>
    </div>
  );
};
