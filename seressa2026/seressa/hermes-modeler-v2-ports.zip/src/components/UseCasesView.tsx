import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen, Upload, Download, Play, Search, RotateCcw, Copy, Check, FileCode, Target,
  ListChecks, Sliders, AlertTriangle, Layers, FileJson, RefreshCw,
} from 'lucide-react';
import { ArchitectureModel, ModelType, UseCase, UseCaseIndexEntry } from '../types';
import { applyParameters, generatePrismCode, generatePropertiesFile } from '../lib/prismGenerator';

interface UseCasesViewProps {
  /** Loads the configured use case into the modeler. */
  onLoad: (model: ArchitectureModel, useCase: UseCase) => void;
  /** The model currently open in the modeler (used to export it as a new use case template). */
  currentModel: ArchitectureModel;
}

const FORMALISM_STYLE: Record<ModelType, string> = {
  csg: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  ctmc: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  mdp: 'bg-amber-50 text-amber-700 border-amber-200',
  dtmc: 'bg-sky-50 text-sky-700 border-sky-200',
};

const USECASE_BASE = `${import.meta.env.BASE_URL}usecases/`;

function download(name: string, content: string, type = 'text/plain') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function isUseCase(x: any): x is UseCase {
  return x && typeof x.id === 'string' && typeof x.title === 'string' && x.model && Array.isArray(x.model.components);
}

export const UseCasesView: React.FC<UseCasesViewProps> = ({ onLoad, currentModel }) => {
  const [useCases, setUseCases] = useState<UseCase[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | ModelType>('all');
  const [paramValues, setParamValues] = useState<Record<string, Record<string, string>>>({});
  const [preview, setPreview] = useState<'model' | 'props' | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  // Dynamic loading: index.json lists the use-case files, each one is fetched at runtime.
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    (async () => {
      try {
        const res = await fetch(`${USECASE_BASE}index.json`, { cache: 'no-store' });
        if (!res.ok) throw new Error(`index.json: HTTP ${res.status}`);
        const index: { usecases: UseCaseIndexEntry[] } = await res.json();
        const loaded = await Promise.all(index.usecases.map(async e => {
          try {
            const r = await fetch(`${USECASE_BASE}${e.file}`, { cache: 'no-store' });
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            const uc = await r.json();
            return isUseCase(uc) ? uc : null;
          } catch (err) {
            console.warn(`Use case ${e.file} could not be loaded`, err);
            return null;
          }
        }));
        if (cancelled) return;
        setUseCases(prev => {
          const imported = prev.filter(u => (u as any).__imported);
          const list = [...(loaded.filter(Boolean) as UseCase[]), ...imported];
          return list;
        });
      } catch (err: any) {
        if (!cancelled) setError(err.message || String(err));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [reloadKey]);

  useEffect(() => {
    if (!selectedId && useCases.length > 0) setSelectedId(useCases[0].id);
  }, [useCases, selectedId]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return useCases
      .filter(u => filter === 'all' || u.formalism === filter)
      .filter(u => !q || [u.title, u.summary, u.chapter, u.slides || ''].join(' ').toLowerCase().includes(q))
      .sort((a, b) => a.chapterOrder - b.chapterOrder || a.title.localeCompare(b.title));
  }, [useCases, query, filter]);

  const chapters = useMemo(() => {
    const groups: { chapter: string; items: UseCase[] }[] = [];
    filtered.forEach(u => {
      const g = groups.find(g => g.chapter === u.chapter);
      if (g) g.items.push(u); else groups.push({ chapter: u.chapter, items: [u] });
    });
    return groups;
  }, [filtered]);

  const selected = useCases.find(u => u.id === selectedId) || null;
  const values = selected ? (paramValues[selected.id] || {}) : {};
  const effectiveParams = selected
    ? selected.parameters.map(p => ({ ...p, value: values[p.name] ?? p.value }))
    : [];
  const configuredModel = selected ? applyParameters(selected.model, effectiveParams) : null;
  const prismCode = configuredModel ? generatePrismCode(configuredModel) : '';
  const propsCode = configuredModel ? generatePropertiesFile(configuredModel) : '';
  const modified = selected ? selected.parameters.some(p => values[p.name] !== undefined && values[p.name] !== p.value) : false;

  const setParam = (name: string, value: string) => {
    if (!selected) return;
    setParamValues(prev => ({ ...prev, [selected.id]: { ...(prev[selected.id] || {}), [name]: value } }));
  };

  const copy = (key: string, text: string) => {
    navigator.clipboard?.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(null), 1200);
    });
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const uc = JSON.parse(ev.target?.result as string);
        if (!isUseCase(uc)) throw new Error('not a use case');
        (uc as any).__imported = true;
        setUseCases(prev => [...prev.filter(u => u.id !== uc.id), uc]);
        setSelectedId(uc.id);
      } catch {
        alert('This file is not a valid use case (expected fields: id, title, model, parameters…).');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleExportTemplate = () => {
    const template: UseCase = {
      id: 'my-use-case',
      title: 'My use case',
      chapter: 'Part X — Chapter title',
      chapterOrder: 99,
      formalism: currentModel.modelType || 'csg',
      tool: currentModel.modelType === 'csg' ? 'PRISM-games 3.x' : 'PRISM 4.x',
      slides: '',
      summary: 'One-sentence summary shown in the list.',
      description: ['Paragraph describing the scenario.'],
      objectives: ['Learning objective'],
      exercises: ['Exercise for the students'],
      parameters: currentModel.constants
        .filter(c => c.value !== undefined && c.value.trim() !== '' && (!isNaN(Number(c.value)) || c.value === 'true' || c.value === 'false'))
        .map(c => ({ name: c.name, label: c.name, value: c.value! })),
      model: currentModel,
    };
    download('my-use-case.json', JSON.stringify(template, null, 2), 'application/json');
  };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* List */}
      <aside className="w-80 bg-white border-r border-neutral-200 flex flex-col">
        <div className="p-4 border-b border-neutral-100 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> Course use cases
            </h2>
            <button onClick={() => setReloadKey(k => k + 1)} title="Reload from server" className="p-1 rounded hover:bg-neutral-100 text-neutral-400 hover:text-blue-600">
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-2.5 top-2 text-neutral-300" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search title, chapter, slide…"
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-neutral-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
            />
          </div>
          <div className="flex gap-1">
            {(['all', 'csg', 'ctmc'] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border transition-all ${filter === f ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-neutral-500 border-neutral-200 hover:border-blue-300'}`}
              >
                {f === 'all' ? 'All' : f}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-4">
          {loading && <p className="text-xs text-neutral-400 p-2">Loading use cases…</p>}
          {error && (
            <div className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg p-3 flex gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Could not load <code>usecases/index.json</code>: {error}</span>
            </div>
          )}
          {!loading && !error && chapters.length === 0 && <p className="text-xs text-neutral-400 p-2">No use case matches.</p>}
          {chapters.map(g => (
            <div key={g.chapter}>
              <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider px-1 mb-1.5">{g.chapter}</p>
              <div className="flex flex-col gap-1.5">
                {g.items.map(u => (
                  <button
                    key={u.id}
                    onClick={() => { setSelectedId(u.id); setPreview(null); }}
                    className={`text-left p-3 rounded-lg border transition-all ${selectedId === u.id ? 'border-blue-400 bg-blue-50 shadow-sm' : 'border-neutral-100 hover:border-blue-200 hover:bg-neutral-50'}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-sm font-semibold text-neutral-800 leading-snug">{u.title}</span>
                      <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded border shrink-0 ${FORMALISM_STYLE[u.formalism]}`}>{u.formalism}</span>
                    </div>
                    {u.slides && <p className="text-[10px] text-neutral-400 mt-1">{u.slides}{(u as any).__imported ? ' · imported' : ''}</p>}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="p-3 border-t border-neutral-100 flex flex-col gap-2">
          <label className="flex items-center justify-center gap-2 px-3 py-2 text-xs font-bold text-neutral-600 border border-dashed border-neutral-300 rounded-lg hover:border-blue-400 hover:text-blue-600 cursor-pointer transition-all">
            <Upload className="w-4 h-4" /> Import a use case (.json)
            <input type="file" accept=".json" onChange={handleImport} className="hidden" />
          </label>
          <button onClick={handleExportTemplate} className="flex items-center justify-center gap-2 px-3 py-1.5 text-[11px] font-semibold text-neutral-500 hover:text-blue-600 transition-all" title="Teachers: download the model open in the modeler as a use-case template">
            <FileJson className="w-3.5 h-3.5" /> Export current model as use case
          </button>
        </div>
      </aside>

      {/* Detail */}
      <section className="flex-1 overflow-y-auto">
        {!selected ? (
          <div className="h-full flex items-center justify-center text-sm text-neutral-400">Select a use case.</div>
        ) : (
          <div className="max-w-5xl mx-auto p-8 flex flex-col gap-6">
            <header className="flex items-start justify-between gap-6">
              <div>
                <p className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">{selected.chapter}</p>
                <h2 className="text-2xl font-bold text-neutral-900 tracking-tight mt-1">{selected.title}</h2>
                <div className="flex flex-wrap items-center gap-2 mt-3">
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${FORMALISM_STYLE[selected.formalism]}`}>{selected.formalism}</span>
                  <span className="text-[11px] text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">{selected.tool}</span>
                  {selected.slides && <span className="text-[11px] text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">{selected.slides}</span>}
                </div>
              </div>
              <div className="flex flex-col gap-2 shrink-0">
                <button
                  onClick={() => configuredModel && onLoad(configuredModel, selected)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium shadow-lg shadow-blue-100 transition-all"
                >
                  <Play className="w-4 h-4" /> Load into modeler
                </button>
                <div className="flex gap-2">
                  <button onClick={() => download(`${selected.id}.prism`, prismCode)} className="flex-1 flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-bold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 rounded-md">
                    <Download className="w-3.5 h-3.5" /> .prism
                  </button>
                  <button onClick={() => download(`${selected.id}.props`, propsCode)} className="flex-1 flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-bold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 rounded-md">
                    <Download className="w-3.5 h-3.5" /> .props
                  </button>
                </div>
              </div>
            </header>

            <p className="text-sm text-neutral-700 leading-relaxed bg-white border border-neutral-200 rounded-xl p-4">{selected.summary}</p>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              <div className="lg:col-span-3 flex flex-col gap-6">
                <Card icon={Layers} title="Scenario">
                  <div className="flex flex-col gap-2.5">
                    {selected.description.map((d, i) => <p key={i} className="text-sm text-neutral-600 leading-relaxed">{d}</p>)}
                  </div>
                </Card>
                {selected.objectives && selected.objectives.length > 0 && (
                  <Card icon={Target} title="Learning objectives">
                    <ul className="list-disc pl-5 flex flex-col gap-1">
                      {selected.objectives.map((o, i) => <li key={i} className="text-sm text-neutral-600">{o}</li>)}
                    </ul>
                  </Card>
                )}
                {selected.exercises && selected.exercises.length > 0 && (
                  <Card icon={ListChecks} title="Try it yourself">
                    <ol className="list-decimal pl-5 flex flex-col gap-1.5">
                      {selected.exercises.map((o, i) => <li key={i} className="text-sm text-neutral-600">{o}</li>)}
                    </ol>
                  </Card>
                )}
              </div>

              <div className="lg:col-span-2 flex flex-col gap-6">
                <Card
                  icon={Sliders}
                  title="Parameters"
                  action={modified ? (
                    <button
                      onClick={() => setParamValues(prev => ({ ...prev, [selected.id]: {} }))}
                      className="flex items-center gap-1 text-[10px] font-bold text-neutral-400 hover:text-blue-600 uppercase"
                    >
                      <RotateCcw className="w-3 h-3" /> Defaults
                    </button>
                  ) : undefined}
                >
                  <p className="text-[11px] text-neutral-400 mb-3">The model is regenerated from these values when you load or download it.</p>
                  <div className="flex flex-col gap-3">
                    {effectiveParams.map(p => (
                      <div key={p.name}>
                        <div className="flex items-baseline justify-between gap-2">
                          <label className="text-xs font-semibold text-neutral-700">{p.label}</label>
                          <code className="text-[10px] text-indigo-500">{p.name}</code>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <input
                            value={p.value}
                            onChange={e => setParam(p.name, e.target.value)}
                            className={`flex-1 px-2.5 py-1.5 text-xs font-mono border rounded-lg outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 ${values[p.name] !== undefined && values[p.name] !== selected.parameters.find(x => x.name === p.name)?.value ? 'border-amber-300 bg-amber-50' : 'border-neutral-200'}`}
                          />
                          {p.unit && <span className="text-[11px] text-neutral-400 w-10">{p.unit}</span>}
                        </div>
                        {(p.description || p.source) && (
                          <p className="text-[10px] text-neutral-400 mt-1 leading-snug">
                            {p.description}{p.description && p.source ? ' · ' : ''}{p.source && <span className="italic">{p.source}</span>}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </div>

            <Card icon={FileCode} title={`Properties (${selected.formalism === 'csg' ? 'rPATL' : 'CSL'})`}>
              <div className="flex flex-col divide-y divide-neutral-100">
                {(selected.model.properties || []).map(p => (
                  <div key={p.id} className="py-2.5 flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-neutral-700">{p.name}</p>
                      <code className="block text-xs font-mono text-indigo-700 mt-0.5 break-all">{p.formula}</code>
                      {p.description && <p className="text-[11px] text-neutral-400 mt-0.5">{p.description}</p>}
                    </div>
                    <button onClick={() => copy(p.id, p.formula)} className="p-1.5 rounded hover:bg-neutral-100 text-neutral-400 hover:text-blue-600" title="Copy">
                      {copied === p.id ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                ))}
              </div>
              <div className="mt-3 bg-neutral-900 text-neutral-300 rounded-lg px-3 py-2 text-[11px] font-mono flex items-center justify-between gap-3">
                <span className="truncate">prism {selected.id}.prism {selected.id}.props{selected.prismOptions ? ` ${selected.prismOptions}` : ''}</span>
                <button onClick={() => copy('cmd', `prism ${selected.id}.prism ${selected.id}.props${selected.prismOptions ? ` ${selected.prismOptions}` : ''}`)} className="text-neutral-400 hover:text-white">
                  {copied === 'cmd' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </Card>

            <div>
              <div className="flex gap-2 mb-2">
                {(['model', 'props'] as const).map(v => (
                  <button
                    key={v}
                    onClick={() => setPreview(preview === v ? null : v)}
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${preview === v ? 'bg-neutral-900 text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                  >
                    {preview === v ? 'Hide' : 'Preview'} {v === 'model' ? 'generated model' : 'properties file'}
                  </button>
                ))}
              </div>
              {preview && (
                <pre className="bg-neutral-900 text-neutral-100 text-xs font-mono rounded-xl p-4 overflow-auto max-h-[480px] leading-relaxed">
                  {preview === 'model' ? prismCode : propsCode}
                </pre>
              )}
            </div>
          </div>
        )}
      </section>
    </div>
  );
};

const Card: React.FC<{ icon: React.ElementType; title: string; action?: React.ReactNode; children: React.ReactNode }> = ({ icon: Icon, title, action, children }) => (
  <div className="bg-white border border-neutral-200 rounded-xl p-5 shadow-sm">
    <div className="flex items-center justify-between mb-3">
      <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-wider flex items-center gap-2"><Icon className="w-4 h-4" /> {title}</h3>
      {action}
    </div>
    {children}
  </div>
);
