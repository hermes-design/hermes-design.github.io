import React, { useState } from 'react';
import { RewardStructure, RewardItem, CPCComponent, Formula } from '../types';
import { X, Plus, Trash2, Info, Coins, ChevronRight, Search, Code } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface RewardEditorProps {
  rewards: RewardStructure[];
  components: CPCComponent[];
  formulas: Formula[];
  onUpdate: (rewards: RewardStructure[]) => void;
  onClose: () => void;
}

export const RewardEditor: React.FC<RewardEditorProps> = ({
  rewards,
  components,
  formulas,
  onUpdate,
  onClose,
}) => {
  const [selectedStructureId, setSelectedStructureId] = useState<string | null>(
    rewards.length > 0 ? rewards[0].id : null
  );
  const [selectedCompId, setSelectedCompId] = useState<string | null>(null);

  const lastFocusedInput = React.useRef<{ element: HTMLInputElement } | null>(null);

  const handleInputSelect = (e: React.SyntheticEvent<HTMLInputElement>) => {
    lastFocusedInput.current = { element: e.currentTarget };
  };

  const handleInsertText = (textToInsert: string) => {
    const current = lastFocusedInput.current;
    if (current && document.body.contains(current.element)) {
      const el = current.element;
      const start = el.selectionStart || 0;
      const end = el.selectionEnd || 0;
      const text = el.value;
      const newText = text.substring(0, start) + textToInsert + text.substring(end);
      
      const structureId = el.getAttribute('data-structure-id');
      const itemId = el.getAttribute('data-item-id');
      const field = el.getAttribute('data-field');

      if (structureId && itemId && field) {
        handleUpdateItem(structureId, itemId, { [field]: newText });
        
        setTimeout(() => {
          el.focus();
          el.setSelectionRange(start + textToInsert.length, start + textToInsert.length);
        }, 0);
      }
    } else {
      navigator.clipboard.writeText(textToInsert);
    }
  };

  const selectedStructure = rewards.find(r => r.id === selectedStructureId);
  const selectedComp = components.find(c => c.id === selectedCompId);

  const handleAddStructure = () => {
    const newStructure: RewardStructure = {
      id: uuidv4(),
      name: `rewards_${rewards.length + 1}`,
      items: []
    };
    onUpdate([...rewards, newStructure]);
    setSelectedStructureId(newStructure.id);
  };

  const handleUpdateStructure = (id: string, updates: Partial<RewardStructure>) => {
    onUpdate(rewards.map(r => r.id === id ? { ...r, ...updates } : r));
  };

  const handleDeleteStructure = (id: string) => {
    onUpdate(rewards.filter(r => r.id !== id));
    if (selectedStructureId === id) {
      setSelectedStructureId(rewards.length > 1 ? (rewards[0].id === id ? rewards[1].id : rewards[0].id) : null);
    }
  };

  const handleAddItem = (structureId: string) => {
    const structure = rewards.find(r => r.id === structureId);
    if (!structure) return;
    const newItem: RewardItem = {
      id: uuidv4(),
      reward: "1"
    };
    handleUpdateStructure(structureId, { items: [...structure.items, newItem] });
  };

  const handleUpdateItem = (structureId: string, itemId: string, updates: Partial<RewardItem>) => {
    const structure = rewards.find(r => r.id === structureId);
    if (!structure) return;
    const newItems = structure.items.map(item => item.id === itemId ? { ...item, ...updates } : item);
    handleUpdateStructure(structureId, { items: newItems });
  };

  const handleDeleteItem = (structureId: string, itemId: string) => {
    const structure = rewards.find(r => r.id === structureId);
    if (!structure) return;
    const newItems = structure.items.filter(item => item.id !== itemId);
    handleUpdateStructure(structureId, { items: newItems });
  };

  // Helper to get all actions from a component
  const getComponentActions = (comp: CPCComponent) => {
    const actions = new Set<string>();
    if (comp.stateMachine) {
      comp.stateMachine.transitions.forEach(t => {
        if (t.action) actions.add(t.action);
      });
    }
    if (comp.monitorDefinition) {
      comp.monitorDefinition.transitions.forEach(t => {
        t.actions.forEach(a => actions.add(a));
      });
    }
    return Array.from(actions);
  };

  // Helper to get all states/variables from a component
  const getComponentStates = (comp: CPCComponent) => {
    if (comp.stateMachine) {
      return comp.stateMachine.states.map(s => ({
        name: s.name,
        expr: `${s.variableName || 'state'}=${s.value ?? comp.stateMachine?.states.indexOf(s)}`
      }));
    }
    return [];
  };

  const getComponentVariables = (comp: CPCComponent) => {
    const vars: { name: string, expr: string }[] = [];
    if (comp.stateMachine?.variables) {
      comp.stateMachine.variables.forEach(v => vars.push({ name: v.name, expr: `${comp.name.toLowerCase()}.${v.name}` }));
    }
    if (comp.monitorDefinition?.variables) {
      comp.monitorDefinition.variables.forEach(v => vars.push({ name: v.name, expr: `${comp.name.toLowerCase()}.${v.name}` }));
    }
    return vars;
  };

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col animate-in fade-in duration-200">
      {/* Header */}
      <div className="h-16 border-b border-neutral-200 px-6 flex items-center justify-between bg-neutral-50 shrink-0">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-neutral-200 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center shadow-sm">
              <Coins className="text-white w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-neutral-900 leading-none">Reward Structures</h2>
              <p className="text-[10px] text-neutral-500 font-medium uppercase tracking-wider mt-1">PRISM Rewards Structure Definition</p>
            </div>
          </div>
        </div>
        <button
          onClick={handleAddStructure}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-bold shadow-lg shadow-blue-100"
        >
          <Plus className="w-4 h-4" /> New Reward Structure
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar: List of Reward Structures */}
        <div className="w-64 border-r border-neutral-200 bg-neutral-50 overflow-y-auto shrink-0">
          <div className="p-4">
            <h3 className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-4">Structures</h3>
            <div className="space-y-1">
              {rewards.map(r => (
                <div
                  key={r.id}
                  onClick={() => setSelectedStructureId(r.id)}
                  className={`group flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all ${
                    selectedStructureId === r.id ? 'bg-white shadow-sm border border-neutral-200 text-blue-600' : 'text-neutral-600 hover:bg-neutral-100'
                  }`}
                >
                  <span className="text-sm font-bold truncate">{r.name}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteStructure(r.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 p-1 text-neutral-400 hover:text-red-500 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
              {rewards.length === 0 && (
                <div className="text-center py-8 px-4">
                  <p className="text-xs text-neutral-400 italic">No reward structures defined.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Middle: Editor for selected structure */}
        <div className="flex-1 flex flex-col bg-white overflow-hidden">
          {selectedStructure ? (
            <>
              <div className="p-6 border-b border-neutral-100 flex items-center justify-between shrink-0">
                <div className="flex-1 max-w-md">
                  <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Structure Name</label>
                  <input
                    type="text"
                    value={selectedStructure.name}
                    onChange={(e) => handleUpdateStructure(selectedStructure.id, { name: e.target.value })}
                    className="w-full p-2 border border-neutral-200 rounded-md text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <button
                  onClick={() => handleAddItem(selectedStructure.id)}
                  className="flex items-center gap-2 px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg transition-colors text-sm font-bold"
                >
                  <Plus className="w-4 h-4" /> Add Reward Rule
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6">
                <div className="space-y-4 max-w-4xl">
                  {selectedStructure.items.map((item, idx) => (
                    <div key={item.id} className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 relative group">
                      <button
                        onClick={() => handleDeleteItem(selectedStructure.id, item.id)}
                        className="absolute top-2 right-2 p-1.5 text-neutral-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      
                      <div className="grid grid-cols-12 gap-4 items-end">
                        <div className="col-span-3">
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Action (Optional)</label>
                          <div className="relative">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-neutral-400 text-xs">[</span>
                            <input
                              type="text"
                              value={item.action || ''}
                              onChange={(e) => handleUpdateItem(selectedStructure.id, item.id, { action: e.target.value })}
                              onSelect={handleInputSelect}
                              onFocus={handleInputSelect}
                              onKeyUp={handleInputSelect}
                              onClick={handleInputSelect}
                              data-structure-id={selectedStructure.id}
                              data-item-id={item.id}
                              data-field="action"
                              placeholder="action"
                              className="w-full pl-4 pr-4 py-2 border border-neutral-200 rounded-md text-xs font-mono focus:ring-1 focus:ring-blue-500 outline-none"
                            />
                            <span className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 text-xs">]</span>
                          </div>
                        </div>
                        <div className="col-span-5">
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Guard / Condition</label>
                          <input
                            type="text"
                            value={item.guard || ''}
                            onChange={(e) => handleUpdateItem(selectedStructure.id, item.id, { guard: e.target.value })}
                            onSelect={handleInputSelect}
                            onFocus={handleInputSelect}
                            onKeyUp={handleInputSelect}
                            onClick={handleInputSelect}
                            data-structure-id={selectedStructure.id}
                            data-item-id={item.id}
                            data-field="guard"
                            placeholder="e.g. s=1 & power=0"
                            className="w-full p-2 border border-neutral-200 rounded-md text-xs font-mono focus:ring-1 focus:ring-blue-500 outline-none"
                          />
                        </div>
                        <div className="col-span-1 flex justify-center pb-2 text-neutral-300">
                          <ChevronRight className="w-4 h-4" />
                        </div>
                        <div className="col-span-3">
                          <label className="block text-[10px] font-bold text-neutral-400 uppercase mb-1">Reward Value</label>
                          <input
                            type="text"
                            value={item.reward}
                            onChange={(e) => handleUpdateItem(selectedStructure.id, item.id, { reward: e.target.value })}
                            onSelect={handleInputSelect}
                            onFocus={handleInputSelect}
                            onKeyUp={handleInputSelect}
                            onClick={handleInputSelect}
                            data-structure-id={selectedStructure.id}
                            data-item-id={item.id}
                            data-field="reward"
                            placeholder="e.g. 1 or energy_cost"
                            className="w-full p-2 border border-neutral-200 rounded-md text-xs font-mono focus:ring-1 focus:ring-blue-500 outline-none bg-amber-50 text-amber-700 border-amber-100"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  {selectedStructure.items.length === 0 && (
                    <div className="text-center py-12 border-2 border-dashed border-neutral-100 rounded-2xl">
                      <Coins className="w-12 h-12 text-neutral-200 mx-auto mb-4" />
                      <p className="text-neutral-400 text-sm">No rules in this structure yet.</p>
                      <button
                        onClick={() => handleAddItem(selectedStructure.id)}
                        className="mt-4 text-blue-600 font-bold text-xs hover:underline"
                      >
                        Add your first reward rule
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-neutral-400 p-12 text-center">
              <Coins className="w-16 h-16 mb-6 opacity-10" />
              <h3 className="text-lg font-bold text-neutral-900 mb-2">Select a Reward Structure</h3>
              <p className="max-w-xs text-sm">Choose a structure from the left or create a new one to define your model's rewards.</p>
            </div>
          )}
        </div>

        {/* Right Sidebar: Component Browser */}
        <div className="w-80 border-l border-neutral-200 bg-neutral-50 flex flex-col shrink-0">
          <div className="p-4 border-b border-neutral-200 shrink-0">
            <h3 className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-4">Component Browser</h3>
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
              <input
                type="text"
                placeholder="Search components..."
                className="w-full pl-8 pr-3 py-1.5 bg-white border border-neutral-200 rounded-md text-xs outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            <div className="p-2 space-y-1">
              {components.map(c => (
                <div key={c.id}>
                  <button
                    onClick={() => setSelectedCompId(selectedCompId === c.id ? null : c.id)}
                    className={`w-full flex items-center justify-between p-2 rounded-md transition-colors ${
                      selectedCompId === c.id ? 'bg-blue-50 text-blue-700' : 'hover:bg-neutral-100 text-neutral-600'
                    }`}
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <div className={`w-2 h-2 rounded-full ${c.type === 'MONITOR' ? 'bg-cyan-500' : 'bg-blue-500'}`} />
                      <span className="text-xs font-bold truncate">{c.name}</span>
                    </div>
                    <ChevronRight className={`w-3 h-3 transition-transform ${selectedCompId === c.id ? 'rotate-90' : ''}`} />
                  </button>
                  
                  {selectedCompId === c.id && (
                    <div className="mt-1 ml-4 space-y-3 p-2 bg-white rounded-md border border-neutral-100 shadow-sm">
                      {/* Actions */}
                      <div>
                        <h4 className="text-[9px] font-bold text-neutral-400 uppercase mb-1">Actions</h4>
                        <div className="flex flex-wrap gap-1">
                          {getComponentActions(c).map(action => (
                            <button
                              key={action}
                              onClick={() => {
                                if (selectedStructure && selectedStructure.items.length > 0) {
                                  handleInsertText(action);
                                }
                              }}
                              className="px-1.5 py-0.5 bg-neutral-100 text-neutral-600 rounded text-[9px] font-mono hover:bg-blue-100 hover:text-blue-700 transition-colors"
                              title="Click to copy"
                            >
                              {action}
                            </button>
                          ))}
                          {getComponentActions(c).length === 0 && <span className="text-[9px] text-neutral-400 italic">No actions</span>}
                        </div>
                      </div>
                      
                      {/* States */}
                      <div>
                        <h4 className="text-[9px] font-bold text-neutral-400 uppercase mb-1">States</h4>
                        <div className="space-y-1">
                          {getComponentStates(c).map(state => (
                            <button
                              key={state.name}
                              onClick={() => handleInsertText(state.name)}
                              className="w-full text-left px-1.5 py-1 bg-neutral-50 text-neutral-600 rounded text-[9px] font-mono hover:bg-blue-100 hover:text-blue-700 transition-colors flex justify-between items-center"
                              title="Click to insert or copy expression"
                            >
                              <span className="font-bold">{state.name}</span>
                              <span className="opacity-60">{state.expr}</span>
                            </button>
                          ))}
                          {getComponentStates(c).length === 0 && <span className="text-[9px] text-neutral-400 italic">No states</span>}
                        </div>
                      </div>

                      {/* Variables */}
                      <div>
                        <h4 className="text-[9px] font-bold text-neutral-400 uppercase mb-1">Variables</h4>
                        <div className="space-y-1">
                          {getComponentVariables(c).map(variable => (
                            <button
                              key={variable.name}
                              onClick={() => handleInsertText(variable.name)}
                              className="w-full text-left px-1.5 py-1 bg-neutral-50 text-neutral-600 rounded text-[9px] font-mono hover:bg-blue-100 hover:text-blue-700 transition-colors flex justify-between items-center"
                              title="Click to insert or copy variable"
                            >
                              <span className="font-bold">{variable.name}</span>
                              <span className="opacity-60">{variable.expr}</span>
                            </button>
                          ))}
                          {getComponentVariables(c).length === 0 && <span className="text-[9px] text-neutral-400 italic">No variables</span>}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            {/* Formulas Section */}
            {formulas && formulas.length > 0 && (
              <div className="p-2 border-t border-neutral-200 mt-2">
                <h3 className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-2 px-2">Formulas</h3>
                <div className="space-y-1 px-2">
                  {formulas.map(formula => (
                    <button
                      key={formula.id}
                      onClick={() => handleInsertText(formula.name)}
                      className="w-full text-left px-1.5 py-1 bg-neutral-50 text-neutral-600 rounded text-[9px] font-mono hover:bg-blue-100 hover:text-blue-700 transition-colors flex justify-between items-center"
                      title="Click to insert or copy formula name"
                    >
                      <span className="font-bold">{formula.name}</span>
                      <span className="opacity-60 truncate ml-2 max-w-[100px]">{formula.expression}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <div className="p-4 bg-blue-50 border-t border-blue-100">
            <div className="flex items-start gap-2">
              <Info className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
              <p className="text-[10px] text-blue-800 leading-tight">
                Click on an action, state, variable, or formula to insert it into the active input field (or copy it to your clipboard if no field is active).
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer / Info */}
      <div className="h-10 border-t border-neutral-200 px-6 flex items-center justify-between bg-neutral-50 shrink-0">
        <div className="flex items-center gap-4 text-[10px] font-bold text-neutral-400 uppercase tracking-widest">
          <span>Structures: {rewards.length}</span>
          <span>Total Rules: {rewards.reduce((acc, r) => acc + r.items.length, 0)}</span>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-neutral-500 italic">
          <Code className="w-3 h-3" />
          <span>PRISM Syntax: [action] guard : reward;</span>
        </div>
      </div>
    </div>
  );
};
