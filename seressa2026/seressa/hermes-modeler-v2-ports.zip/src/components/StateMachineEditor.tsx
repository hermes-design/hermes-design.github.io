import React, { useState, useRef, useEffect } from 'react';
import { Stage, Layer, Circle, Text, Group, Arrow, Rect, Transformer } from 'react-konva';
import { StateMachine, State, StateTransition, StateVariable, Constant } from '../types';
import { ModelType } from '../types';
import { updateWeightLabel } from '../lib/prismGenerator';
import { v4 as uuidv4 } from 'uuid';
import { Plus, Trash2, Save, X, Variable, ArrowRight, Code, Hash, ZoomIn, ZoomOut, Maximize } from 'lucide-react';

interface StateMachineEditorProps {
  componentName: string;
  stateMachine: StateMachine;
  constants: Constant[];
  modelType?: ModelType;
  onUpdate: (sm: StateMachine) => void;
  onClose: () => void;
}

export const StateMachineEditor: React.FC<StateMachineEditorProps> = ({
  componentName,
  stateMachine,
  constants,
  modelType,
  onUpdate,
  onClose,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [pendingTransition, setPendingTransition] = useState<string | null>(null);

  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const transformerRef = useRef<any>(null);
  const selectionRef = useRef<any>(null);

  useEffect(() => {
    if (selectedId && transformerRef.current && selectionRef.current) {
      const selectedState = stateMachine.states.find(s => s.id === selectedId);
      if (selectedState) {
        transformerRef.current.nodes([selectionRef.current]);
        transformerRef.current.getLayer()?.batchDraw();
      } else {
        transformerRef.current.nodes([]);
      }
    } else if (transformerRef.current) {
      transformerRef.current.nodes([]);
    }
  }, [selectedId, stateMachine]);

  const handleZoom = (e: any) => {
    e.evt.preventDefault();
    const stage = e.target.getStage();
    const oldScale = stage.scaleX();
    const pointer = stage.getPointerPosition();

    if (!pointer) return;

    const mousePointTo = {
      x: (pointer.x - stage.x()) / oldScale,
      y: (pointer.y - stage.y()) / oldScale,
    };

    const speed = 1.1;
    const newScale = e.evt.deltaY < 0 ? oldScale * speed : oldScale / speed;
    
    // Limit zoom
    const limitedScale = Math.max(0.1, Math.min(5, newScale));

    setScale(limitedScale);
    setPosition({
      x: pointer.x - mousePointTo.x * limitedScale,
      y: pointer.y - mousePointTo.y * limitedScale,
    });
  };

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        });
      }
    };
    window.addEventListener('resize', updateSize);
    updateSize();
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  const handleAddState = () => {
    const newState: State = {
      id: uuidv4(),
      name: `s${stateMachine.states.length}`,
      x: 100,
      y: 100,
    };
    onUpdate({
      ...stateMachine,
      states: [...stateMachine.states, newState],
    });
  };

  const handleStateDrag = (id: string, e: any) => {
    const newStates = stateMachine.states.map((s) =>
      s.id === id ? { ...s, x: e.target.x(), y: e.target.y() } : s
    );
    onUpdate({ ...stateMachine, states: newStates });
  };

  const handleStateClick = (id: string) => {
    if (pendingTransition) {
      const newTransition: StateTransition = {
        id: uuidv4(),
        sourceStateId: pendingTransition,
        targetStateId: id,
        updates: [{ probability: 1, assignments: {} }],
      };
      onUpdate({
        ...stateMachine,
        transitions: [...stateMachine.transitions, newTransition],
      });
      setPendingTransition(null);
    } else {
      setSelectedId(id);
    }
  };

  const handleDelete = () => {
    if (!selectedId) return;
    const newStates = stateMachine.states.filter((s) => s.id !== selectedId);
    const newTransitions = stateMachine.transitions.filter(
      (t) => t.id !== selectedId && t.sourceStateId !== selectedId && t.targetStateId !== selectedId
    );
    onUpdate({
      ...stateMachine,
      states: newStates,
      transitions: newTransitions,
    });
    setSelectedId(null);
  };

  const handleRemoveWaypoint = (transitionId: string, waypointIdx: number, e: any) => {
    e.cancelBubble = true;
    const newTransitions = stateMachine.transitions.map(t => {
      if (t.id === transitionId) {
        const waypoints = (t.waypoints || []).filter((_, i) => i !== waypointIdx);
        return { ...t, waypoints };
      }
      return t;
    });
    onUpdate({ ...stateMachine, transitions: newTransitions });
  };

  const handleWaypointDrag = (transitionId: string, waypointIdx: number, e: any) => {
    const newTransitions = stateMachine.transitions.map(t => {
      if (t.id === transitionId) {
        const waypoints = [...(t.waypoints || [])];
        waypoints[waypointIdx] = { x: e.target.x(), y: e.target.y() };
        return { ...t, waypoints };
      }
      return t;
    });
    onUpdate({ ...stateMachine, transitions: newTransitions });
  };

  const handleTransitionDblClick = (id: string, e: any) => {
    e.cancelBubble = true;
    const stage = e.target.getStage();
    const pointerPos = stage.getPointerPosition();
    if (!pointerPos) return;

    const newTransitions = stateMachine.transitions.map(t => {
      if (t.id === id) {
        const waypoints = t.waypoints || [];
        return { ...t, waypoints: [...waypoints, { x: pointerPos.x, y: pointerPos.y }] };
      }
      return t;
    });
    onUpdate({ ...stateMachine, transitions: newTransitions });
  };

  const selectedState = stateMachine.states.find((s) => s.id === selectedId);
  const selectedTransition = stateMachine.transitions.find((t) => t.id === selectedId);

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col animate-in fade-in duration-200">
      {/* Header */}
      <div className="h-16 border-b border-neutral-200 px-6 flex items-center justify-between bg-neutral-50">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-neutral-200 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
          <div>
            <h2 className="font-bold text-neutral-900">Behavior: {componentName}</h2>
            <p className="text-xs text-neutral-500 italic">PRISM Probabilistic State Machine</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => {
              // Generate code for this module only
              let moduleCode = `// Standalone Module: ${componentName}\n\n`;
              
              // Include constants if they exist
              if (constants.length > 0) {
                moduleCode += `// Constants\n`;
                constants.forEach(c => {
                  const valStr = c.value ? ` = ${c.value}` : ``;
                  moduleCode += `const ${c.type} ${c.name}${valStr};\n`;
                });
                moduleCode += `\n`;
              }

              moduleCode += `module ${componentName.toLowerCase()}\n`;
              stateMachine.variables.forEach(v => {
                moduleCode += `  ${v.name} : [${v.min}..${v.max}] init ${v.init};\n`;
              });
              if (stateMachine.states.length > 0) {
                const firstState = stateMachine.states[0];
                const varName = firstState.variableName || 'state';
                const maxVal = Math.max(...stateMachine.states.map(s => s.value ?? stateMachine.states.indexOf(s)));
                moduleCode += `  ${varName} : [0..${maxVal}] init ${firstState.value ?? 0}; // 0: ${firstState.name}\n\n`;
              }
              // Group transitions by source, action, and guard
              const groups: { [key: string]: StateTransition[] } = {};
              stateMachine.transitions.forEach(t => {
                const key = `${t.sourceStateId}|${t.action || ''}|${t.guard || ''}`;
                if (!groups[key]) groups[key] = [];
                groups[key].push(t);
              });

              Object.entries(groups).forEach(([key, transitions]) => {
                const [sourceId, action, guard] = key.split('|');
                const source = stateMachine.states.find(s => s.id === sourceId);
                if (!source) return;

                const sourceVar = source.variableName || 'state';
                const sourceVal = source.value ?? stateMachine.states.indexOf(source);
                
                const actionStr = action ? `[${action}] ` : `[] `;
                const guardStr = `${sourceVar}=${sourceVal}${guard ? ` & (${guard})` : ''}`;

                const updates: string[] = [];
                transitions.forEach(t => {
                  const target = stateMachine.states.find(s => s.id === t.targetStateId);
                  if (!target) return;
                  const targetVar = target.variableName || 'state';
                  const targetVal = target.value ?? stateMachine.states.indexOf(target);

                  if (t.updates.length > 0) {
                    t.updates.forEach(u => {
                      const assignments = Object.entries(u.assignments)
                        .filter(([v]) => stateMachine.variables.some(sv => sv.name === v))
                        .map(([v, val]) => `(${v}'=${val})`)
                        .concat([`(${targetVar}'=${targetVal})`])
                        .join(' & ');
                      updates.push(`${u.probability} : ${assignments}`);
                    });
                  } else {
                    updates.push(`1.0 : (${targetVar}'=${targetVal})`);
                  }
                });

                if (updates.length > 0) {
                  moduleCode += `  ${actionStr}${guardStr} -> ${updates.join(' + ')};\n`;
                }
              });
              moduleCode += `endmodule`;
              const blob = new Blob([moduleCode], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              window.open(url, '_blank');
            }}
            className="flex items-center gap-2 px-4 py-2 bg-neutral-200 text-neutral-700 rounded-lg hover:bg-neutral-300 transition-colors text-sm font-bold"
          >
            <Code className="w-4 h-4" /> View Code
          </button>
          <button
            onClick={handleAddState}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-bold"
          >
            <Plus className="w-4 h-4" /> Add State
          </button>
          <button
            onClick={() => setSelectedId(null)}
            className="px-4 py-2 bg-white border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors text-sm font-bold"
          >
            Deselect
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar: Variables & Properties */}
        <div className="w-80 border-r border-neutral-200 flex flex-col bg-white">
          <div className="p-4 border-b border-neutral-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-2">
                <Variable className="w-3 h-3" /> Variables
              </h3>
              <button
                onClick={() => {
                  const newVar: StateVariable = { id: uuidv4(), name: 'v', min: 0, max: 10, init: 0 };
                  onUpdate({ ...stateMachine, variables: [...stateMachine.variables, newVar] });
                }}
                className="p-1 hover:bg-neutral-100 rounded text-blue-600"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2">
              {stateMachine.variables.map((v) => (
                <div key={v.id} className="p-2 bg-neutral-50 rounded border border-neutral-100">
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={v.name}
                      onChange={(e) => {
                        const newVars = stateMachine.variables.map((varItem) =>
                          varItem.id === v.id ? { ...varItem, name: e.target.value } : varItem
                        );
                        onUpdate({ ...stateMachine, variables: newVars });
                      }}
                      className="w-1/2 p-1 text-xs border rounded font-mono"
                      placeholder="Name"
                    />
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        value={isNaN(v.min) ? '' : v.min}
                        onChange={(e) => {
                          const newVars = stateMachine.variables.map((varItem) =>
                            varItem.id === v.id ? { ...varItem, min: parseInt(e.target.value) } : varItem
                          );
                          onUpdate({ ...stateMachine, variables: newVars });
                        }}
                        className="w-10 p-1 text-[10px] border rounded"
                        title="Min"
                      />
                      <span className="text-[10px]">..</span>
                      <input
                        type="number"
                        value={isNaN(v.max) ? '' : v.max}
                        onChange={(e) => {
                          const newVars = stateMachine.variables.map((varItem) =>
                            varItem.id === v.id ? { ...varItem, max: parseInt(e.target.value) } : varItem
                          );
                          onUpdate({ ...stateMachine, variables: newVars });
                        }}
                        className="w-10 p-1 text-[10px] border rounded"
                        title="Max"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-[10px] text-neutral-400">Init:</label>
                    <input
                      type="number"
                      value={isNaN(v.init) ? '' : v.init}
                      onChange={(e) => {
                        const newVars = stateMachine.variables.map((varItem) =>
                          varItem.id === v.id ? { ...varItem, init: parseInt(e.target.value) } : varItem
                        );
                        onUpdate({ ...stateMachine, variables: newVars });
                      }}
                      className="w-12 p-1 text-[10px] border rounded"
                    />
                    <button
                      onClick={() => {
                        const variableToDelete = v;
                        const newVars = stateMachine.variables.filter(varItem => varItem.id !== variableToDelete.id);
                        
                        // Clean up assignments in all transitions
                        const newTransitions = stateMachine.transitions.map(t => ({
                          ...t,
                          updates: t.updates.map(u => {
                            const newAssignments = { ...u.assignments };
                            delete newAssignments[variableToDelete.name];
                            return { ...u, assignments: newAssignments };
                          })
                        }));

                        onUpdate({ 
                          ...stateMachine, 
                          variables: newVars,
                          transitions: newTransitions
                        });
                      }}
                      className="ml-auto text-red-400 hover:text-red-600"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 p-4 overflow-y-auto">
            {selectedState ? (
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">State Properties</h3>
                <div>
                  <label className="block text-[10px] text-neutral-500 mb-1">Name / Label</label>
                  <input
                    type="text"
                    value={selectedState.name}
                    onChange={(e) => {
                      const newStates = stateMachine.states.map((s) =>
                        s.id === selectedId ? { ...s, name: e.target.value } : s
                      );
                      onUpdate({ ...stateMachine, states: newStates });
                    }}
                    className="w-full p-2 border rounded text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-neutral-500 mb-1">Variable</label>
                    <input
                      type="text"
                      placeholder="e.g. s"
                      value={selectedState.variableName || ''}
                      onChange={(e) => {
                        const newStates = stateMachine.states.map((s) =>
                          s.id === selectedId ? { ...s, variableName: e.target.value } : s
                        );
                        onUpdate({ ...stateMachine, states: newStates });
                      }}
                      className="w-full p-2 border rounded text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-neutral-500 mb-1">Value</label>
                    <input
                      type="number"
                      value={selectedState.value !== undefined && isNaN(selectedState.value) ? '' : (selectedState.value ?? '')}
                      onChange={(e) => {
                        const newStates = stateMachine.states.map((s) =>
                          s.id === selectedId ? { ...s, value: e.target.value ? parseInt(e.target.value) : undefined } : s
                        );
                        onUpdate({ ...stateMachine, states: newStates });
                      }}
                      className="w-full p-2 border rounded text-sm font-mono"
                    />
                  </div>
                </div>
                <button
                  onClick={() => setPendingTransition(selectedId)}
                  className={`w-full p-2 rounded text-xs font-bold transition-colors ${
                    pendingTransition === selectedId ? 'bg-orange-100 text-orange-600' : 'bg-blue-50 text-blue-600'
                  }`}
                >
                  {pendingTransition === selectedId ? 'Click target state...' : 'Add Transition'}
                </button>
                <button onClick={handleDelete} className="w-full p-2 bg-red-50 text-red-600 rounded text-xs font-bold">
                  Delete State
                </button>
              </div>
            ) : selectedTransition ? (
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Transition</h3>
                <div>
                  <label className="block text-[10px] text-neutral-500 mb-1">Action (Sync)</label>
                  <input
                    type="text"
                    placeholder="e.g. send_data"
                    value={selectedTransition.action || ''}
                    onChange={(e) => {
                      const newTransitions = stateMachine.transitions.map((t) =>
                        t.id === selectedId ? { ...t, action: e.target.value } : t
                      );
                      onUpdate({ ...stateMachine, transitions: newTransitions });
                    }}
                    className="w-full p-2 border rounded text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-500 mb-1">Guard (Condition)</label>
                  <input
                    type="text"
                    placeholder="e.g. v < 10"
                    value={selectedTransition.guard || ''}
                    onChange={(e) => {
                      const newTransitions = stateMachine.transitions.map((t) =>
                        t.id === selectedId ? { ...t, guard: e.target.value } : t
                      );
                      onUpdate({ ...stateMachine, transitions: newTransitions });
                    }}
                    className="w-full p-2 border rounded text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-500 uppercase mb-2">Routing</label>
                  <button
                    onClick={() => {
                      const newTransitions = stateMachine.transitions.map((t) =>
                        t.id === selectedId ? { ...t, waypoints: [] } : t
                      );
                      onUpdate({ ...stateMachine, transitions: newTransitions });
                    }}
                    className="w-full p-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-600 rounded-md text-xs font-bold transition-colors"
                  >
                    Reset Waypoints
                  </button>
                  <p className="text-[10px] text-neutral-400 mt-2 italic">
                    Double-click the transition line to add a waypoint. Drag waypoints to adjust routing. Double-click a waypoint to remove it.
                  </p>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-[10px] text-neutral-500">Probabilistic Updates</label>
                    <button
                      onClick={() => {
                        // Automatically create a new state and a corresponding transition
                        const sourceState = stateMachine.states.find(s => s.id === selectedTransition.sourceStateId);
                        const targetState = stateMachine.states.find(s => s.id === selectedTransition.targetStateId);
                        if (!sourceState || !targetState) return;

                        const newStateId = uuidv4();
                        const newState: State = {
                          id: newStateId,
                          name: `s${stateMachine.states.length}`,
                          variableName: targetState.variableName,
                          value: (targetState.value ?? 0) + 1,
                          x: targetState.x + 100,
                          y: targetState.y + 50,
                        };

                        const newTransitionId = uuidv4();
                        const newTransition: StateTransition = {
                          id: newTransitionId,
                          sourceStateId: selectedTransition.sourceStateId,
                          targetStateId: newStateId,
                          action: selectedTransition.action,
                          guard: selectedTransition.guard,
                          updates: [{ probability: 0.5, assignments: {} }],
                        };

                        onUpdate({
                          ...stateMachine,
                          states: [...stateMachine.states, newState],
                          transitions: [...stateMachine.transitions, newTransition],
                        });
                        setSelectedId(newTransitionId);
                      }}
                      className="text-[10px] text-blue-600 font-bold hover:underline"
                    >
                      + Add Branch (New State)
                    </button>
                  </div>
                  {selectedTransition.updates.map((u, idx) => (
                    <div key={idx} className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 mb-3 relative group">
                       <button
                         onClick={() => {
                           const newUpdates = selectedTransition.updates.filter((_, i) => i !== idx);
                           const newTransitions = stateMachine.transitions.map((t) =>
                             t.id === selectedId ? { ...t, updates: newUpdates } : t
                           );
                           onUpdate({ ...stateMachine, transitions: newTransitions });
                         }}
                         className="absolute top-2 right-2 p-1 bg-white border border-neutral-200 rounded-full text-red-400 opacity-0 group-hover:opacity-100 transition-all hover:text-red-600 shadow-sm z-10"
                       >
                         <X className="w-3 h-3" />
                       </button>
                       
                       <div className="flex flex-col gap-2 mb-4">
                         <div className="flex items-center justify-between">
                           <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">{updateWeightLabel(modelType)}</label>
                           <div className="flex flex-wrap gap-1">
                             {constants.filter(c => c.type === 'double').map(c => (
                               <button
                                 key={c.id}
                                 onClick={() => {
                                   const newUpdates = [...selectedTransition.updates];
                                   newUpdates[idx] = { ...u, probability: c.name };
                                   const newTransitions = stateMachine.transitions.map((t) =>
                                     t.id === selectedId ? { ...t, updates: newUpdates } : t
                                   );
                                   onUpdate({ ...stateMachine, transitions: newTransitions });
                                 }}
                                 className="px-1.5 py-0.5 bg-indigo-50 text-indigo-600 rounded text-[9px] font-bold hover:bg-indigo-100 transition-colors border border-indigo-100"
                                 title={`Use constant: ${c.name}`}
                               >
                                 {c.name}
                               </button>
                             ))}
                           </div>
                         </div>
                         <input
                           type="text"
                           placeholder="e.g. 0.8 or p"
                           value={u.probability}
                           onChange={(e) => {
                             const newUpdates = [...selectedTransition.updates];
                             newUpdates[idx] = { ...u, probability: e.target.value };
                             const newTransitions = stateMachine.transitions.map((t) =>
                               t.id === selectedId ? { ...t, updates: newUpdates } : t
                             );
                             onUpdate({ ...stateMachine, transitions: newTransitions });
                           }}
                           className="w-full px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-xs font-mono focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                         />
                       </div>

                       <div className="space-y-2">
                         <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Assignments</label>
                         <div className="grid grid-cols-1 gap-1.5">
                           {stateMachine.variables.map(v => (
                             <div key={v.id} className="flex items-center gap-2 bg-white/50 p-1.5 rounded-lg border border-neutral-100">
                               <span className="text-[10px] font-mono font-bold text-neutral-500 w-12 truncate">{v.name}'=</span>
                               <input
                                 type="text"
                                 placeholder="value"
                                 value={u.assignments[v.name] || ''}
                                 onChange={(e) => {
                                   const newAssignments = { ...u.assignments };
                                   if (e.target.value) {
                                     newAssignments[v.name] = e.target.value;
                                   } else {
                                     delete newAssignments[v.name];
                                   }
                                   const newUpdates = [...selectedTransition.updates];
                                   newUpdates[idx] = { ...u, assignments: newAssignments };
                                   const newTransitions = stateMachine.transitions.map((t) =>
                                     t.id === selectedId ? { ...t, updates: newUpdates } : t
                                   );
                                   onUpdate({ ...stateMachine, transitions: newTransitions });
                                 }}
                                 className="flex-1 bg-transparent text-[10px] font-mono outline-none focus:text-blue-600"
                               />
                             </div>
                           ))}
                         </div>
                       </div>
                    </div>
                  ))}
                </div>
                <button onClick={handleDelete} className="w-full p-2 bg-red-50 text-red-600 rounded text-xs font-bold">
                  Delete Transition
                </button>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-neutral-400">
                <Save className="w-12 h-12 mb-4 opacity-10" />
                <p className="text-xs">Select a state or transition to edit properties</p>
              </div>
            )}
          </div>
        </div>

        {/* Canvas Area */}
        <div ref={containerRef} className="flex-1 bg-neutral-100 relative overflow-hidden">
          <div className="absolute top-4 left-4 z-10 flex flex-col bg-white rounded-lg shadow-md border border-neutral-200 p-1">
            <button
              onClick={() => setScale(s => Math.min(5, s * 1.2))}
              className="p-2 hover:bg-neutral-100 rounded-md text-neutral-600"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => setScale(s => Math.max(0.1, s / 1.2))}
              className="p-2 hover:bg-neutral-100 rounded-md text-neutral-600"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
          </div>
          <Stage 
            width={dimensions.width} 
            height={dimensions.height} 
            onClick={(e) => {
              if (e.target === e.target.getStage()) setSelectedId(null);
            }}
            scaleX={scale}
            scaleY={scale}
            x={position.x}
            y={position.y}
            draggable
            onWheel={handleZoom}
            onDragEnd={(e) => {
              if (e.target === e.target.getStage()) {
                setPosition({ x: e.target.x(), y: e.target.y() });
              }
            }}
          >
            <Layer>
              {/* Transitions */}
              {stateMachine.transitions.map((t) => {
                const source = stateMachine.states.find((s) => s.id === t.sourceStateId);
                const target = stateMachine.states.find((s) => s.id === t.targetStateId);
                if (!source || !target) return null;

                const waypoints = t.waypoints || [];
                const isSelfLoop = t.sourceStateId === t.targetStateId;
                
                let startX, startY, endX, endY;
                let points: number[] = [];
                let labelX, labelY;

                if (isSelfLoop && waypoints.length === 0) {
                  const r = source.radius || 30;
                  const loopSize = 30;
                  // Start at 45 degrees, end at 135 degrees (top-ish)
                  const startAngle = -Math.PI / 4;
                  const endAngle = -3 * Math.PI / 4;
                  
                  startX = source.x + r * Math.cos(startAngle);
                  startY = source.y + r * Math.sin(startAngle);
                  endX = source.x + r * Math.cos(endAngle);
                  endY = source.y + r * Math.sin(endAngle);

                  points = [
                    startX, startY,
                    source.x + (r + loopSize) * Math.cos(startAngle), source.y + (r + loopSize) * Math.sin(startAngle),
                    source.x + (r + loopSize) * Math.cos(-Math.PI / 2), source.y + (r + loopSize) * Math.sin(-Math.PI / 2),
                    source.x + (r + loopSize) * Math.cos(endAngle), source.y + (r + loopSize) * Math.sin(endAngle),
                    endX, endY
                  ];
                  
                  labelX = source.x;
                  labelY = source.y - r - loopSize - 15;
                } else {
                  if (waypoints.length > 0) {
                    const firstWP = waypoints[0];
                    const lastWP = waypoints[waypoints.length - 1];
                    
                    const dxStart = firstWP.x - source.x;
                    const dyStart = firstWP.y - source.y;
                    const angleStart = Math.atan2(dyStart, dxStart);
                    const startRadius = source.radius || 30;
                    startX = source.x + startRadius * Math.cos(angleStart);
                    startY = source.y + startRadius * Math.sin(angleStart);
                    
                    const dxEnd = target.x - lastWP.x;
                    const dyEnd = target.y - lastWP.y;
                    const angleEnd = Math.atan2(dyEnd, dxEnd);
                    const endRadius = target.radius || 30;
                    endX = target.x - (endRadius + 5) * Math.cos(angleEnd);
                    endY = target.y - (endRadius + 5) * Math.sin(angleEnd);
                  } else {
                    const dx = target.x - source.x;
                    const dy = target.y - source.y;
                    const angle = Math.atan2(dy, dx);
                    const startRadius = source.radius || 30;
                    const endRadius = target.radius || 30;
                    startX = source.x + startRadius * Math.cos(angle);
                    startY = source.y + startRadius * Math.sin(angle);
                    endX = target.x - (endRadius + 5) * Math.cos(angle);
                    endY = target.y - (endRadius + 5) * Math.sin(angle);
                  }

                  points = [startX, startY, ...waypoints.flatMap(w => [w.x, w.y]), endX, endY];

                  // Calculate label position (middle of the path)
                  if (waypoints.length > 0) {
                    const midIdx = Math.floor(waypoints.length / 2);
                    labelX = waypoints[midIdx].x;
                    labelY = waypoints[midIdx].y - 20;
                  } else {
                    labelX = (startX + endX) / 2;
                    labelY = (startY + endY) / 2 - 20;
                  }
                }

                return (
                  <Group key={t.id}>
                    {/* Hit area for easier selection and waypoint adding */}
                    <Arrow
                      points={points}
                      stroke="transparent"
                      strokeWidth={15}
                      tension={0.5}
                      onClick={(e) => { e.cancelBubble = true; setSelectedId(t.id); }}
                      onDblClick={(e) => handleTransitionDblClick(t.id, e)}
                    />
                    <Arrow
                      points={points}
                      stroke={selectedId === t.id ? '#3b82f6' : '#000000'}
                      fill={selectedId === t.id ? '#3b82f6' : '#000000'}
                      strokeWidth={selectedId === t.id ? 3 : 2}
                      tension={0.5}
                      pointerLength={10}
                      pointerWidth={10}
                      onClick={(e) => { e.cancelBubble = true; setSelectedId(t.id); }}
                      onDblClick={(e) => handleTransitionDblClick(t.id, e)}
                    />
                    {t.action && (
                      <Text
                        text={`[${t.action}]`}
                        x={labelX - 50}
                        y={labelY}
                        width={100}
                        fontSize={10}
                        fontStyle="bold"
                        fill="#3b82f6"
                        align="center"
                      />
                    )}
                    {/* Waypoint handles */}
                    {selectedId === t.id && waypoints.map((wp, idx) => (
                      <Circle
                        key={`${t.id}-wp-${idx}`}
                        x={wp.x}
                        y={wp.y}
                        radius={5}
                        fill="#3b82f6"
                        stroke="white"
                        strokeWidth={1}
                        draggable
                        onDragMove={(e) => handleWaypointDrag(t.id, idx, e)}
                        onDblClick={(e) => handleRemoveWaypoint(t.id, idx, e)}
                        onClick={(e) => e.cancelBubble = true}
                      />
                    ))}
                  </Group>
                );
              })}

              {/* States */}
              {stateMachine.states.map((s) => (
                <Group
                  key={s.id}
                  x={s.x}
                  y={s.y}
                  ref={selectedId === s.id ? selectionRef : null}
                  draggable
                  onDragMove={(e) => handleStateDrag(s.id, e)}
                  onClick={(e) => {
                    e.cancelBubble = true;
                    handleStateClick(s.id);
                  }}
                  onTransformEnd={(e) => {
                    const node = selectionRef.current;
                    if (!node) return;
                    const scaleX = node.scaleX();
                    
                    const newRadius = Math.max(10, (s.radius || 30) * scaleX);
                    
                    node.scaleX(1);
                    node.scaleY(1);

                    const newStates = stateMachine.states.map((st) =>
                      st.id === s.id ? { ...st, radius: newRadius } : st
                    );
                    onUpdate({ ...stateMachine, states: newStates });
                  }}
                >
                  <Circle
                    radius={s.radius || 30}
                    fill={selectedId === s.id ? '#dbeafe' : 'white'}
                    stroke={selectedId === s.id ? '#3b82f6' : '#cbd5e1'}
                    strokeWidth={2}
                    shadowBlur={selectedId === s.id ? 10 : 0}
                    shadowColor="#3b82f6"
                  />
                  <Text
                    text={s.name}
                    width={(s.radius || 30) * 2}
                    height={20}
                    offsetX={s.radius || 30}
                    offsetY={s.variableName ? 20 : 10}
                    align="center"
                    verticalAlign="middle"
                    fontSize={12}
                    fontStyle="bold"
                    fill="#1e293b"
                  />
                  {s.variableName && (
                    <Text
                      text={`${s.variableName}=${s.value ?? '?'}`}
                      width={(s.radius || 30) * 2}
                      height={20}
                      offsetX={s.radius || 30}
                      offsetY={0}
                      align="center"
                      verticalAlign="middle"
                      fontSize={10}
                      fontFamily="JetBrains Mono"
                      fill="#3b82f6"
                    />
                  )}
                </Group>
              ))}

              {/* Transformer */}
              {selectedId && stateMachine.states.find(s => s.id === selectedId) && (
                <Transformer
                  ref={transformerRef}
                  boundBoxFunc={(oldBox, newBox) => {
                    if (newBox.width < 20 || newBox.height < 20) {
                      return oldBox;
                    }
                    return newBox;
                  }}
                  enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right']}
                  rotationSnaps={[0, 90, 180, 270]}
                  rotateEnabled={false}
                  keepRatio={true}
                />
              )}
            </Layer>
          </Stage>
        </div>
      </div>
    </div>
  );
};
