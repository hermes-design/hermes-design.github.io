import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Stage, Layer, Rect, Text, Group, Arrow, Circle, Image as KonvaImage, Line, Transformer } from 'react-konva';
import { CPCComponent, Connector, Port } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { Maximize, ZoomIn, ZoomOut, Grid, MousePointer2, Hand } from 'lucide-react';

const GRID_SIZE = 20;

const ComponentIcon = ({ type, iconUrl, colors, width, height }: { type: string, iconUrl?: string, colors: any, width: number, height: number }) => {
  const [image, setImage] = useState<HTMLImageElement | null>(null);

  useEffect(() => {
    if (iconUrl) {
      const img = new window.Image();
      img.src = iconUrl;
      img.onload = () => setImage(img);
      img.onerror = () => setImage(null);
    } else {
      setImage(null);
    }
  }, [iconUrl]);

  const iconSize = Math.min(width, height) * 0.45;
  const centerX = width / 2;
  const centerY = height / 2 + 10; // Offset down slightly to account for the label at top

  if (image) {
    const scale = Math.min(iconSize / image.width, iconSize / image.height);
    const imgWidth = image.width * scale;
    const imgHeight = image.height * scale;
    return (
      <KonvaImage
        image={image}
        x={centerX - imgWidth / 2}
        y={centerY - imgHeight / 2}
        width={imgWidth}
        height={imgHeight}
      />
    );
  }

  // Default Icons using Konva shapes to match Lucide icons
  const renderDefaultIcon = () => {
    const scale = iconSize / 30; // Base size of default icons is ~30px

    const iconProps = {
      x: centerX,
      y: centerY,
      scaleX: scale,
      scaleY: scale,
      offsetX: 15,
      offsetY: 15
    };

    switch (type) {
      case 'SENSOR': // Activity icon
        return (
          <Group {...iconProps}>
            <Line 
              points={[2, 15, 7, 15, 10, 5, 15, 25, 20, 15, 28, 15]} 
              stroke={colors.text} 
              strokeWidth={2} 
              lineJoin="round" 
              lineCap="round" 
            />
          </Group>
        );
      case 'ACTUATOR': // Radio icon
        return (
          <Group {...iconProps}>
            <Circle x={15} y={18} radius={3} fill={colors.text} />
            <Line points={[15, 15, 15, 5]} stroke={colors.text} strokeWidth={2} lineCap="round" />
            <Circle x={15} y={18} radius={8} stroke={colors.text} strokeWidth={1.5} dash={[2, 2]} />
            <Circle x={15} y={18} radius={13} stroke={colors.text} strokeWidth={1.5} dash={[3, 3]} />
          </Group>
        );
      case 'GATEWAY': // Cpu icon
        return (
          <Group {...iconProps}>
            <Rect x={6} y={6} width={18} height={18} stroke={colors.text} strokeWidth={2} cornerRadius={2} />
            <Rect x={10} y={10} width={10} height={10} stroke={colors.text} strokeWidth={1.5} />
            {/* Pins */}
            <Line points={[12, 2, 12, 6]} stroke={colors.text} strokeWidth={2} />
            <Line points={[18, 2, 18, 6]} stroke={colors.text} strokeWidth={2} />
            <Line points={[12, 24, 12, 28]} stroke={colors.text} strokeWidth={2} />
            <Line points={[18, 24, 18, 28]} stroke={colors.text} strokeWidth={2} />
            <Line points={[2, 12, 6, 12]} stroke={colors.text} strokeWidth={2} />
            <Line points={[2, 18, 6, 18]} stroke={colors.text} strokeWidth={2} />
            <Line points={[24, 12, 28, 12]} stroke={colors.text} strokeWidth={2} />
            <Line points={[24, 18, 28, 18]} stroke={colors.text} strokeWidth={2} />
          </Group>
        );
      case 'ATTACKER': // ShieldAlert icon
        return (
          <Group {...iconProps}>
            <Line 
              points={[15, 2, 26, 6, 26, 15, 15, 28, 4, 15, 4, 6, 15, 2]} 
              stroke={colors.text} 
              strokeWidth={2} 
              closed 
              fill="white"
            />
            <Line points={[15, 8, 15, 16]} stroke={colors.text} strokeWidth={2.5} lineCap="round" />
            <Circle x={15} y={21} radius={1.5} fill={colors.text} />
          </Group>
        );
      case 'MONITOR': // Monitor icon
        return (
          <Group {...iconProps}>
            <Rect width={30} height={22} stroke={colors.text} strokeWidth={2} cornerRadius={2} fill="white" />
            <Rect x={4} y={4} width={22} height={14} fill="#f1f5f9" />
            <Line points={[10, 22, 10, 26, 20, 26, 20, 22]} stroke={colors.text} strokeWidth={2} />
            <Line points={[7, 28, 23, 28]} stroke={colors.text} strokeWidth={2} />
          </Group>
        );
      case 'SATELLITE': // Satellite icon
        return (
          <Group {...iconProps}>
            <Rect x={10} y={10} width={10} height={10} fill="white" stroke={colors.text} strokeWidth={2} />
            <Rect x={0} y={12} width={8} height={6} fill="white" stroke={colors.text} strokeWidth={1.5} />
            <Rect x={22} y={12} width={8} height={6} fill="white" stroke={colors.text} strokeWidth={1.5} />
            <Line points={[15, 10, 15, 4]} stroke={colors.text} strokeWidth={2} />
            <Circle x={15} y={4} radius={2} fill={colors.text} />
          </Group>
        );
      case 'STATION': // TowerControl icon
        return (
          <Group {...iconProps}>
            <Line points={[10, 28, 15, 5, 20, 28]} stroke={colors.text} strokeWidth={2} />
            <Rect x={10} y={5} width={10} height={6} fill="white" stroke={colors.text} strokeWidth={2} cornerRadius={1} />
            <Line points={[15, 5, 15, 0]} stroke={colors.text} strokeWidth={1.5} />
            <Circle x={15} y={0} radius={1.5} fill={colors.text} />
          </Group>
        );
      case 'BASIC': // Box icon
        return (
          <Group {...iconProps}>
            <Rect x={5} y={5} width={20} height={20} stroke={colors.text} strokeWidth={2} cornerRadius={2} />
            <Line points={[5, 5, 12, 12, 25, 5]} stroke={colors.text} strokeWidth={1.5} />
            <Line points={[12, 12, 12, 25]} stroke={colors.text} strokeWidth={1.5} />
          </Group>
        );
      default:
        return (
          <Group {...iconProps}>
            <Rect width={30} height={30} fill="white" stroke={colors.text} strokeWidth={1.5} cornerRadius={4} />
            <Circle x={15} y={15} radius={5} fill={colors.text} />
          </Group>
        );
    }
  };

  return renderDefaultIcon();
};

interface CanvasProps {
  components: CPCComponent[];
  connectors: Connector[];
  onUpdateComponents: (components: CPCComponent[]) => void;
  onUpdateConnectors: (connectors: Connector[]) => void;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onConnect: (sourceCompId: string, sourcePortId: string, targetCompId: string, targetPortId: string) => void;
  onEditBehavior: (id: string) => void;
}

export const Canvas: React.FC<CanvasProps & { stageRef: React.RefObject<any> }> = ({
  components,
  connectors,
  onUpdateComponents,
  onUpdateConnectors,
  selectedId,
  onSelect,
  onConnect,
  onEditBehavior,
  stageRef,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const [pendingConn, setPendingConn] = useState<{ compId: string; portId: string } | null>(null);
  
  // Canvas Navigation State
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [snapToGrid, setSnapToGrid] = useState(true);

  const transformerRef = useRef<any>(null);
  const selectionRef = useRef<any>(null);

  useEffect(() => {
    if (selectedId && transformerRef.current && selectionRef.current) {
      transformerRef.current.nodes([selectionRef.current]);
      transformerRef.current.getLayer()?.batchDraw();
    }
  }, [selectedId, components]);

  useEffect(() => {
    if (stageRef.current) {
      const container = stageRef.current.container();
      container.style.cursor = isPanning ? 'grab' : 'default';
    }
  }, [isPanning]);

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        });
      }
    };
    window.addEventListener('resize', updateSize);
    updateSize();
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  const handleZoom = (e: any) => {
    e.evt.preventDefault();
    const stage = e.target.getStage();
    const oldScale = stage.scaleX();
    const pointer = stage.getPointerPosition();

    const mousePointTo = {
      x: (pointer.x - stage.x()) / oldScale,
      y: (pointer.y - stage.y()) / oldScale,
    };

    const speed = 1.1;
    const newScale = e.evt.deltaY < 0 ? oldScale * speed : oldScale / speed;
    
    // Limit zoom
    const limitedScale = Math.max(0.1, Math.min(5, newScale));

    setScale(limitedScale);
    setPosition({
      x: pointer.x - mousePointTo.x * limitedScale,
      y: pointer.y - mousePointTo.y * limitedScale,
    });
  };

  const handleFitToScreen = () => {
    if (components.length === 0) {
      setScale(1);
      setPosition({ x: 0, y: 0 });
      return;
    }

    const padding = 50;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

    components.forEach(c => {
      const w = c.width || 120;
      const h = c.height || Math.max(80, c.ports.length * 20 + 30);
      minX = Math.min(minX, c.x);
      minY = Math.min(minY, c.y);
      maxX = Math.max(maxX, c.x + w);
      maxY = Math.max(maxY, c.y + h);
    });

    const contentWidth = maxX - minX;
    const contentHeight = maxY - minY;

    const scaleX = (dimensions.width - padding * 2) / contentWidth;
    const scaleY = (dimensions.height - padding * 2) / contentHeight;
    const newScale = Math.min(scaleX, scaleY, 1);

    setScale(newScale);
    setPosition({
      x: (dimensions.width - contentWidth * newScale) / 2 - minX * newScale,
      y: (dimensions.height - contentHeight * newScale) / 2 - minY * newScale,
    });
  };

  const handleDragMove = (id: string, e: any) => {
    const newX = e.target.x();
    const newY = e.target.y();

    const newComponents = components.map((c) => {
      if (c.id === id) {
        return { ...c, x: newX, y: newY };
      }
      return c;
    });
    onUpdateComponents(newComponents);
  };

  const getPortPosition = (compId: string, portId: string) => {
    const comp = components.find((c) => c.id === compId);
    if (!comp) return { x: 0, y: 0 };
    
    const port = comp.ports.find(p => p.id === portId);
    if (!port) return { x: 0, y: 0 };

    const compWidth = comp.width || 120;
    const compHeight = comp.height || Math.max(80, comp.ports.length * 20 + 30);
    
    const side = port.side || (port.type === 'INPUT' ? 'LEFT' : 'RIGHT');
    
    // Calculate even distribution for ports on the same side
    const portsOnSide = comp.ports.filter(p => (p.side || (p.type === 'INPUT' ? 'LEFT' : 'RIGHT')) === side);
    const indexOnSide = portsOnSide.findIndex(p => p.id === portId);
    
    const sideLength = (side === 'LEFT' || side === 'RIGHT') ? compHeight : compWidth;
    const distributedOffset = (indexOnSide + 1) * (sideLength / (portsOnSide.length + 1));
    
    // Use manual offset if provided, otherwise use distributed
    const offset = port.offset !== undefined ? port.offset : distributedOffset;
    
    switch (side) {
      case 'LEFT': return { x: comp.x, y: comp.y + offset };
      case 'RIGHT': return { x: comp.x + compWidth, y: comp.y + offset };
      case 'TOP': return { x: comp.x + offset, y: comp.y };
      case 'BOTTOM': return { x: comp.x + offset, y: comp.y + compHeight };
      default: return { x: comp.x, y: comp.y + offset };
    }
  };

  const handlePortDragMove = (compId: string, portId: string, e: any) => {
    const comp = components.find(c => c.id === compId);
    if (!comp) return;

    const stage = e.target.getStage();
    const pointerPos = stage.getPointerPosition();
    if (!pointerPos) return;

    const pos = {
      x: (pointerPos.x - stage.x()) / stage.scaleX(),
      y: (pointerPos.y - stage.y()) / stage.scaleY(),
    };

    const compWidth = comp.width || 120;
    const compHeight = comp.height || Math.max(80, comp.ports.length * 20 + 30);

    const rx = pos.x - comp.x;
    const ry = pos.y - comp.y;

    const distLeft = Math.abs(rx);
    const distRight = Math.abs(rx - compWidth);
    const distTop = Math.abs(ry);
    const distBottom = Math.abs(ry - compHeight);

    const minDist = Math.min(distLeft, distRight, distTop, distBottom);
    
    let side: 'LEFT' | 'RIGHT' | 'TOP' | 'BOTTOM' = 'LEFT';
    let offset = 0;

    if (minDist === distLeft) {
      side = 'LEFT';
      offset = Math.max(10, Math.min(compHeight - 10, ry));
    } else if (minDist === distRight) {
      side = 'RIGHT';
      offset = Math.max(10, Math.min(compHeight - 10, ry));
    } else if (minDist === distTop) {
      side = 'TOP';
      offset = Math.max(10, Math.min(compWidth - 10, rx));
    } else {
      side = 'BOTTOM';
      offset = Math.max(10, Math.min(compWidth - 10, rx));
    }

    const newComponents = components.map((c) => {
      if (c.id === compId) {
        // Update the port and potentially reorder based on offset to maintain distribution order
        let updatedPorts = c.ports.map(p => p.id === portId ? { ...p, side, offset } : p);
        
        // Separate ports by side
        const portsBySide: Record<string, Port[]> = {
          'LEFT': [], 'RIGHT': [], 'TOP': [], 'BOTTOM': []
        };
        
        updatedPorts.forEach(p => {
          const s = p.side || (p.type === 'INPUT' ? 'LEFT' : 'RIGHT');
          portsBySide[s].push(p);
        });
        
        // Sort the ports on the active side by their current drag offset
        portsBySide[side].sort((a, b) => (a.offset || 0) - (b.offset || 0));
        
        // Reconstruct the ports array
        const finalPorts = [
          ...portsBySide['LEFT'],
          ...portsBySide['RIGHT'],
          ...portsBySide['TOP'],
          ...portsBySide['BOTTOM']
        ];
        
        return { ...c, ports: finalPorts };
      }
      return c;
    });
    onUpdateComponents(newComponents);
  };

  const handlePortClick = (compId: string, portId: string, e: any) => {
    e.cancelBubble = true;
    if (!pendingConn) {
      setPendingConn({ compId, portId });
    } else {
      if (pendingConn.compId !== compId) {
        onConnect(pendingConn.compId, pendingConn.portId, compId, portId);
      }
      setPendingConn(null);
    }
  };

  const handleWaypointDrag = (connId: string, idx: number, e: any) => {
    const newConnectors = connectors.map((c) => {
      if (c.id === connId) {
        const newWaypoints = [...(c.waypoints || [])];
        newWaypoints[idx] = { x: e.target.x(), y: e.target.y() };
        return { ...c, waypoints: newWaypoints };
      }
      return c;
    });
    onUpdateConnectors(newConnectors);
  };

  const handleAddWaypoint = (connId: string, e: any) => {
    e.cancelBubble = true;
    const stage = e.target.getStage();
    const pointerPos = stage.getPointerPosition();
    if (!pointerPos) return;

    // Transform screen position to stage position
    const pos = {
      x: (pointerPos.x - stage.x()) / stage.scaleX(),
      y: (pointerPos.y - stage.y()) / stage.scaleY(),
    };

    const newConnectors = connectors.map((c) => {
      if (c.id === connId) {
        const newWaypoints = [...(c.waypoints || []), { x: pos.x, y: pos.y }];
        return { ...c, waypoints: newWaypoints };
      }
      return c;
    });
    onUpdateConnectors(newConnectors);
  };

  const handleRemoveWaypoint = (connId: string, idx: number, e: any) => {
    e.cancelBubble = true;
    const newConnectors = connectors.map((c) => {
      if (c.id === connId) {
        const newWaypoints = (c.waypoints || []).filter((_, i) => i !== idx);
        return { ...c, waypoints: newWaypoints };
      }
      return c;
    });
    onUpdateConnectors(newConnectors);
  };

  return (
    <div ref={containerRef} className="w-full h-full canvas-container relative overflow-hidden bg-white border border-neutral-200 rounded-lg shadow-inner">
      {/* Toolbar */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
        <div className="flex flex-col bg-white rounded-lg shadow-md border border-neutral-200 p-1">
          <button
            onClick={() => setScale(s => Math.min(5, s * 1.2))}
            className="p-2 hover:bg-neutral-100 rounded-md text-neutral-600"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setScale(s => Math.max(0.1, s / 1.2))}
            className="p-2 hover:bg-neutral-100 rounded-md text-neutral-600"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <div className="h-px bg-neutral-200 mx-1" />
          <button
            onClick={handleFitToScreen}
            className="p-2 hover:bg-neutral-100 rounded-md text-neutral-600"
            title="Fit to Screen"
          >
            <Maximize className="w-4 h-4" />
          </button>
        </div>

        <div className="flex flex-col bg-white rounded-lg shadow-md border border-neutral-200 p-1">
          <button
            onClick={() => setShowGrid(!showGrid)}
            className={`p-2 rounded-md transition-colors ${showGrid ? 'bg-blue-50 text-blue-600' : 'hover:bg-neutral-100 text-neutral-600'}`}
            title="Toggle Grid"
          >
            <Grid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSnapToGrid(!snapToGrid)}
            className={`p-2 rounded-md transition-colors ${snapToGrid ? 'bg-blue-50 text-blue-600' : 'hover:bg-neutral-100 text-neutral-600'}`}
            title="Snap to Grid"
          >
            <MousePointer2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsPanning(!isPanning)}
            className={`p-2 rounded-md transition-colors ${isPanning ? 'bg-blue-50 text-blue-600' : 'hover:bg-neutral-100 text-neutral-600'}`}
            title="Pan Mode"
          >
            <Hand className="w-4 h-4" />
          </button>
        </div>
      </div>

      <Stage
        ref={stageRef}
        width={dimensions.width}
        height={dimensions.height}
        scaleX={scale}
        scaleY={scale}
        x={position.x}
        y={position.y}
        draggable={isPanning}
        onWheel={handleZoom}
        onDragEnd={(e) => {
          if (e.target === stageRef.current) {
            setPosition({ x: e.target.x(), y: e.target.y() });
          }
        }}
        onClick={(e) => {
          if (e.target === stageRef.current) {
            onSelect(null);
            setPendingConn(null);
          }
        }}
        onMouseEnter={(e) => {
          const container = e.target.getStage()?.container();
          if (container) container.style.cursor = isPanning ? 'grab' : 'default';
        }}
      >
        <Layer>
          {/* Grid */}
          {showGrid && (() => {
            const lines = [];
            const startX = Math.floor(-position.x / scale / GRID_SIZE) * GRID_SIZE - GRID_SIZE * 10;
            const startY = Math.floor(-position.y / scale / GRID_SIZE) * GRID_SIZE - GRID_SIZE * 10;
            const endX = startX + (dimensions.width / scale) + GRID_SIZE * 20;
            const endY = startY + (dimensions.height / scale) + GRID_SIZE * 20;

            for (let i = startX; i <= endX; i += GRID_SIZE) {
              lines.push(<Line key={`v-${i}`} points={[i, startY, i, endY]} stroke="#f1f5f9" strokeWidth={1 / scale} />);
            }
            for (let i = startY; i <= endY; i += GRID_SIZE) {
              lines.push(<Line key={`h-${i}`} points={[startX, i, endX, i]} stroke="#f1f5f9" strokeWidth={1 / scale} />);
            }
            return lines;
          })()}

          {/* Connectors */}
          {connectors.map((conn) => {
            const start = getPortPosition(conn.sourceComponentId, conn.sourcePortId);
            const end = getPortPosition(conn.targetComponentId, conn.targetPortId);
            
            const points = [
              start.x, start.y,
              ...(conn.waypoints || []).flatMap(w => [w.x, w.y]),
              end.x, end.y
            ];

            return (
              <Group key={conn.id}>
                {/* Hit area (wider invisible line) */}
                <Arrow
                  points={points}
                  stroke="transparent"
                  strokeWidth={20}
                  tension={0.2}
                  onClick={(e) => {
                    e.cancelBubble = true;
                    onSelect(conn.id);
                  }}
                  onDblClick={(e) => handleAddWaypoint(conn.id, e)}
                />
                
                <Arrow
                  points={points}
                  stroke={selectedId === conn.id ? "#3b82f6" : "#94a3b8"}
                  fill={selectedId === conn.id ? "#3b82f6" : "#94a3b8"}
                  strokeWidth={selectedId === conn.id ? 4 / scale : 2 / scale}
                  tension={0.2}
                  pointerAtBeginning={false}
                  hitStrokeWidth={0}
                  listening={false}
                />
                
                {/* Waypoint Handles */}
                {selectedId === conn.id && (conn.waypoints || []).map((w, idx) => (
                  <Circle
                    key={`${conn.id}-w-${idx}`}
                    x={w.x}
                    y={w.y}
                    radius={6 / scale}
                    fill="#3b82f6"
                    stroke="#fff"
                    strokeWidth={2 / scale}
                    draggable
                    dragBoundFunc={(pos) => {
                      const stage = stageRef.current;
                      if (!stage) return pos;
                      const stageScale = stage.scaleX();
                      const stageX = stage.x();
                      const stageY = stage.y();
                      
                      // For waypoints, we don't have a strict boundary, 
                      // but we might want to snap to grid if enabled
                      let wx = (pos.x - stageX) / stageScale;
                      let wy = (pos.y - stageY) / stageScale;
                      
                      if (snapToGrid) {
                        wx = Math.round(wx / GRID_SIZE) * GRID_SIZE;
                        wy = Math.round(wy / GRID_SIZE) * GRID_SIZE;
                      }
                      
                      return {
                        x: wx * stageScale + stageX,
                        y: wy * stageScale + stageY
                      };
                    }}
                    onDragMove={(e) => handleWaypointDrag(conn.id, idx, e)}
                    onDblClick={(e) => handleRemoveWaypoint(conn.id, idx, e)}
                    onClick={(e) => e.cancelBubble = true}
                  />
                ))}
              </Group>
            );
          })}

          {/* Pending Connection Line */}
          {pendingConn && (
            <Arrow
              points={[
                getPortPosition(pendingConn.compId, pendingConn.portId).x,
                getPortPosition(pendingConn.compId, pendingConn.portId).y,
                // This is a bit tricky with Konva without mouse tracking, 
                // but we can just show the source port highlighted
              ]}
              stroke="#3b82f6"
              dash={[5, 5]}
            />
          )}

          {/* Components */}
          {components.map((comp) => {
            const isSelected = selectedId === comp.id;
            const getCompColors = (type: string) => {
              switch (type) {
                case 'ATTACKER': return { fill: "#fee2e2", stroke: isSelected ? "#3b82f6" : "#ef4444", text: "#b91c1c" };
                case 'SATELLITE': return { fill: "#e0e7ff", stroke: isSelected ? "#3b82f6" : "#4f46e5", text: "#3730a3" };
                case 'STATION': return { fill: "#ffedd5", stroke: isSelected ? "#3b82f6" : "#f97316", text: "#9a3412" };
                case 'GATEWAY': return { fill: "#f3e8ff", stroke: isSelected ? "#3b82f6" : "#9333ea", text: "#6b21a8" };
                case 'MONITOR': return { fill: "#ecfeff", stroke: isSelected ? "#3b82f6" : "#0891b2", text: "#164e63" };
                case 'SENSOR': return { fill: "#e0f2fe", stroke: isSelected ? "#3b82f6" : "#0284c7", text: "#075985" };
                case 'ACTUATOR': return { fill: "#dcfce7", stroke: isSelected ? "#3b82f6" : "#16a34a", text: "#166534" };
                default: return { fill: "#f8fafc", stroke: isSelected ? "#3b82f6" : "#cbd5e1", text: "#1e293b" };
              }
            };
            const colors = getCompColors(comp.type);
            const compWidth = comp.width || 120;
            const compHeight = comp.height || Math.max(80, comp.ports.length * 20 + 30);

            return (
              <Group
                key={comp.id}
                x={comp.x}
                y={comp.y}
                draggable
                dragBoundFunc={(pos) => {
                  const stage = stageRef.current;
                  if (!stage) return pos;
                  const stageScale = stage.scaleX();
                  const stageX = stage.x();
                  const stageY = stage.y();
                  
                  let nx = (pos.x - stageX) / stageScale;
                  let ny = (pos.y - stageY) / stageScale;
                  
                  if (snapToGrid) {
                    nx = Math.round(nx / GRID_SIZE) * GRID_SIZE;
                    ny = Math.round(ny / GRID_SIZE) * GRID_SIZE;
                  }
                  
                  return {
                    x: nx * stageScale + stageX,
                    y: ny * stageScale + stageY
                  };
                }}
                onDragMove={(e) => handleDragMove(comp.id, e)}
                onDragEnd={(e) => handleDragMove(comp.id, e)}
                onClick={(e) => {
                  e.cancelBubble = true;
                  onSelect(comp.id);
                }}
                onDblClick={(e) => {
                  e.cancelBubble = true;
                  onEditBehavior(comp.id);
                }}
                onMouseEnter={(e) => {
                  if (isPanning) return;
                  const container = e.target.getStage()?.container();
                  if (container) container.style.cursor = 'grab';
                }}
                onMouseLeave={(e) => {
                  if (isPanning) return;
                  const container = e.target.getStage()?.container();
                  if (container) container.style.cursor = 'default';
                }}
              >
                <Rect
                  ref={isSelected ? selectionRef : null}
                  width={compWidth}
                  height={compHeight}
                  fill={colors.fill}
                  stroke={colors.stroke}
                  strokeWidth={2}
                  cornerRadius={8}
                  shadowBlur={isSelected ? 10 : 0}
                  shadowColor="#3b82f6"
                  onTransformEnd={(e) => {
                    const node = selectionRef.current;
                    const scaleX = node.scaleX();
                    const scaleY = node.scaleY();
                    
                    // Konva Transformer changes the node's x and y when resizing from top or left
                    const nodeX = node.x();
                    const nodeY = node.y();
                    
                    // Reset scale and local position
                    node.scaleX(1);
                    node.scaleY(1);
                    node.x(0);
                    node.y(0);
                    
                    const newWidth = Math.max(50, compWidth * scaleX);
                    const newHeight = Math.max(50, compHeight * scaleY);
                    
                    const newComponents = components.map((c) => {
                      if (c.id === comp.id) {
                        const widthRatio = newWidth / compWidth;
                        const heightRatio = newHeight / compHeight;
                        
                        // Update component's root coordinates
                        const newX = c.x + nodeX;
                        const newY = c.y + nodeY;
                        
                        const updatedPorts = c.ports.map(p => {
                          if (p.offset !== undefined) {
                            const side = p.side || (p.type === 'INPUT' ? 'LEFT' : 'RIGHT');
                            let newOffset = p.offset;
                            if (side === 'LEFT' || side === 'RIGHT') {
                              newOffset = p.offset * heightRatio;
                              newOffset = Math.max(10, Math.min(newHeight - 10, newOffset));
                            } else {
                              newOffset = p.offset * widthRatio;
                              newOffset = Math.max(10, Math.min(newWidth - 10, newOffset));
                            }
                            return { ...p, offset: newOffset };
                          }
                          return p;
                        });

                        return { ...c, x: newX, y: newY, width: newWidth, height: newHeight, ports: updatedPorts };
                      }
                      return c;
                    });
                    onUpdateComponents(newComponents);
                  }}
                />
                <Text
                  text={comp.name}
                  width={compWidth}
                  height={30}
                  y={10}
                  align="center"
                  verticalAlign="middle"
                  fontSize={12}
                  fontFamily="Inter"
                  fontStyle="bold"
                  fill={colors.text}
                  ellipsis={true}
                />
                
                <ComponentIcon 
                  type={comp.type} 
                  iconUrl={comp.icon} 
                  colors={colors} 
                  width={compWidth} 
                  height={compHeight} 
                />
              
              {/* Ports visualization */}
              {comp.ports?.map((port, idx) => {
                const side = port.side || (port.type === 'INPUT' ? 'LEFT' : 'RIGHT');
                
                // Calculate even distribution for ports on the same side
                const portsOnSide = comp.ports.filter(p => (p.side || (p.type === 'INPUT' ? 'LEFT' : 'RIGHT')) === side);
                const indexOnSide = portsOnSide.findIndex(p => p.id === port.id);
                
                const sideLength = (side === 'LEFT' || side === 'RIGHT') ? compHeight : compWidth;
                const distributedOffset = (indexOnSide + 1) * (sideLength / (portsOnSide.length + 1));
                
                const offset = port.offset !== undefined ? port.offset : distributedOffset;
                
                let portX, portY, labelX, labelY, align;

                switch (side) {
                  case 'LEFT':
                    portX = 0; portY = offset;
                    labelX = 10; labelY = offset - 4;
                    align = 'left';
                    break;
                  case 'RIGHT':
                    portX = compWidth; portY = offset;
                    labelX = compWidth - 50; labelY = offset - 4;
                    align = 'right';
                    break;
                  case 'TOP':
                    portX = offset; portY = 0;
                    labelX = offset - 20; labelY = 10;
                    align = 'center';
                    break;
                  case 'BOTTOM':
                    portX = offset; portY = compHeight;
                    labelX = offset - 20; labelY = compHeight - 18;
                    align = 'center';
                    break;
                  default:
                    portX = 0; portY = offset;
                    labelX = 10; labelY = offset - 4;
                    align = 'left';
                }

                return (
                  <Group 
                    key={port.id} 
                    onClick={(e) => handlePortClick(comp.id, port.id, e)}
                  >
                    <Circle
                      x={portX}
                      y={portY}
                      radius={6}
                      fill={port.commMode === 'SYNCHRONOUS' ? "#3b82f6" : "#a855f7"}
                      stroke={pendingConn?.portId === port.id ? "#000" : "#fff"}
                      strokeWidth={pendingConn?.portId === port.id ? 2 : 1}
                      scaleX={pendingConn?.portId === port.id ? 1.5 : 1}
                      scaleY={pendingConn?.portId === port.id ? 1.5 : 1}
                      draggable
                      dragBoundFunc={(pos) => {
                        const stage = stageRef.current;
                        if (!stage) return pos;
                        
                        // Transform absolute screen position to stage space
                        const stageScale = stage.scaleX();
                        const stageX = stage.x();
                        const stageY = stage.y();
                        
                        const rx = (pos.x - stageX) / stageScale - comp.x;
                        const ry = (pos.y - stageY) / stageScale - comp.y;
                        
                        const distLeft = Math.abs(rx);
                        const distRight = Math.abs(rx - compWidth);
                        const distTop = Math.abs(ry);
                        const distBottom = Math.abs(ry - compHeight);
                        
                        const minDist = Math.min(distLeft, distRight, distTop, distBottom);
                        
                        let newStageX, newStageY;
                        if (minDist === distLeft) {
                          newStageX = comp.x;
                          newStageY = comp.y + Math.max(10, Math.min(compHeight - 10, ry));
                        } else if (minDist === distRight) {
                          newStageX = comp.x + compWidth;
                          newStageY = comp.y + Math.max(10, Math.min(compHeight - 10, ry));
                        } else if (minDist === distTop) {
                          newStageX = comp.x + Math.max(10, Math.min(compWidth - 10, rx));
                          newStageY = comp.y;
                        } else {
                          newStageX = comp.x + Math.max(10, Math.min(compWidth - 10, rx));
                          newStageY = comp.y + compHeight;
                        }

                        // Transform back to absolute screen position
                        return {
                          x: newStageX * stageScale + stageX,
                          y: newStageY * stageScale + stageY
                        };
                      }}
                      onDragMove={(e) => {
                        e.cancelBubble = true;
                        handlePortDragMove(comp.id, port.id, e);
                      }}
                      onDragEnd={(e) => {
                        e.cancelBubble = true;
                        const newComponents = components.map((c) => {
                          if (c.id === comp.id) {
                            return {
                              ...c,
                              ports: c.ports.map(p => p.id === port.id ? { ...p, offset: undefined } : p)
                            };
                          }
                          return c;
                        });
                        onUpdateComponents(newComponents);
                      }}
                      onMouseEnter={(e) => {
                        e.cancelBubble = true;
                        if (isPanning) return;
                        const container = e.target.getStage()?.container();
                        if (container) container.style.cursor = 'move';
                      }}
                      onMouseLeave={(e) => {
                        e.cancelBubble = true;
                        if (isPanning) return;
                        const container = e.target.getStage()?.container();
                        if (container) container.style.cursor = 'default';
                      }}
                    />
                    <Text
                      text={port.name}
                      x={labelX}
                      y={labelY}
                      width={side === 'TOP' || side === 'BOTTOM' ? 40 : 40}
                      align={align}
                      fontSize={8}
                      fontFamily="Inter"
                      fill="#94a3b8"
                      listening={false}
                    />
                  </Group>
                );
              })}
            </Group>
          );
        })}

        {selectedId && (
          <Transformer
            ref={transformerRef}
            boundBoxFunc={(oldBox, newBox) => {
              if (newBox.width < 50 || newBox.height < 50) {
                return oldBox;
              }
              return newBox;
            }}
            rotateEnabled={false}
            keepRatio={false}
            enabledAnchors={[
              'top-left', 'top-right', 'bottom-left', 'bottom-right',
              'top-center', 'bottom-center', 'left-center', 'right-center'
            ]}
            anchorSize={8}
            anchorCornerRadius={2}
            anchorStroke="#3b82f6"
            anchorFill="#fff"
            borderStroke="#3b82f6"
            borderDash={[2, 2]}
          />
        )}
      </Layer>
      </Stage>
    </div>
  );
};
