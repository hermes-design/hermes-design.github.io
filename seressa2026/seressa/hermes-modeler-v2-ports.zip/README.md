# HERMES Modeler

Interactive graphical tool for Component-Port-Connector (CPC) models with PRISM code generation,
used for the SERESSA 2026 lecture *From Particle Strikes to Mission Dependability* (A. Baouya).

* **Modeler** — draw components, edit their state machines / monitors, constants, labels, formulas,
  rewards and properties, then generate PRISM code.
* **Model types** — `CSG` (PRISM-games concurrent stochastic games, with players and a `rounds` module),
  `CTMC` (continuous-time Markov chains: update weights are **rates**), plus `MDP` and `DTMC`.
* **Use Cases tab** — course case studies loaded at runtime from `public/usecases/*.json`.
  Students pick a case by chapter, adjust its parameters, preview / download the generated
  `.prism` + `.props`, or load it into the modeler.

## Run locally

```bash
npm install
npm run dev          # http://localhost:3000
npm run build        # static site in dist/ (use cases are copied to dist/usecases/)
```

## Course use cases

| Chapter | Use case | Formalism | Slides |
|---|---|---|---|
| Part 1 — Context | Radiation upsets and operator response | CTMC | 5, 19 |
| Part 3 — Foundations | Bus write access (shared resource) | CSG | 17, 18, 46 |
| Part 4 — Case study 1 | GPS SPS collaborative maintenance (reduced CSG) | CSG | 23–31, 46 |
| Part 5 — Case study 2 | Galileo SAR link under jamming | CTMC | 39–42 |
| Part 6 — Communication | Sync vs async ports: IoT pipeline | CTMC | — |
| Part 6 — Communication | Async port in a game: producer / consumer | CSG | — |

All generated models have been checked with PRISM-games (master branch, November 2026):

```bash
npm run usecases:export            # writes prism-out/<id>.prism and <id>.props
prism prism-out/bus-write-access.prism prism-out/bus-write-access.props
prism prism-out/radiation-ctmc-primer.prism prism-out/radiation-ctmc-primer.props -gaussseidel
```

### Adding or editing a use case

* **Without code**: build the model in the Modeler, then *Use Cases → Export current model as use case*.
  Edit the texts / parameters in the downloaded JSON, copy it to `public/usecases/` and add it to
  `public/usecases/index.json`. No rebuild is needed when serving the `dist/` folder: copy the file to
  `dist/usecases/` too. Students can also open a JSON file with *Import a use case*.
* **From the script**: the four course cases are authored in `scripts/build-usecases.ts`
  (`npm run usecases:build` regenerates the JSON files).

A use case is `{ id, title, chapter, chapterOrder, formalism, tool, prismOptions?, slides?, summary,
description[], objectives[], exercises[], parameters[], model }`. Each parameter
`{ name, label, value, unit?, description?, source? }` overrides the value of the PRISM constant
with the same `name`; derived constants (e.g. `lambda_jam = 1/MTTA`,
`pr_lt = 1 - pow(EULER, -t_round/MTBF_LT)`) are recomputed by PRISM.

## Synchronous and asynchronous ports

Since the "ports" version, connectors have a semantics in the generated PRISM code: synchronous ports
become a rendezvous on a shared action (a joint action in a CSG) and asynchronous ports become a
generated FIFO channel module. See [docs/sync-async-ports.md](docs/sync-async-ports.md) for the
experiments and the rules.
