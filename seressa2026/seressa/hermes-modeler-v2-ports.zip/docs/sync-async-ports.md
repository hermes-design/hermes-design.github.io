# Synchronous and asynchronous ports in PRISM

*HERMES Modeler — "ports" version. All experiments below were run with PRISM-games (master, Nov. 2026);
the models are in `docs/experiments/`.*

## Short answer

PRISM has **one** communication primitive: CSP-style multi-way synchronisation of modules on a shared
action label. There are no channels, no buffers and no message values.

| Model type | Synchronous port | Asynchronous port |
|---|---|---|
| DTMC / MDP / CTMC | **Direct**: both endpoints share one action label (rendezvous). | **Transformation**: a FIFO channel module is inserted. |
| CSG (PRISM-games) | **Transformation**: the players' action sets must be disjoint, so the rendezvous is the joint action `[a_s, a_r]`. Its effect goes in a non-player module (Monitor). | **Transformation over joint actions**: the channel lists `[s,r]`, `[s,b]`, `[a,r]` explicitly. |

So the answer is: synchronous ports are native except in CSGs; asynchronous ports always need a
transformation. The generator now performs these transformations automatically
(`src/lib/portSemantics.ts`).

## Experiments

| Id | Model | Encoding | Outcome |
|---|---|---|---|
| E1 | CTMC | sync port = shared action `[msg]` | Works natively (4 states). |
| E2 | CTMC | async port = channel module `n:[0..N]`, `[send] n<N → n+1`, `[recv] n>0 → n−1` | Works. Throughput over 100 time units: 112.5 (sync) → 125.1 (N=1) → 141.6 (N=5) → 145.8 (N=50); blocked-time ratio 0.42 → 0.04. |
| C0 | CSG | same action `[msg]` in two player modules | **Rejected**: “Action sets must be disjoint”. |
| C0b | CSG | rendezvous as joint action `[send,recv]` in a non-player module | Works. `<<sender,receiver>> Pmax=? [F d=1]` = 1. |
| C1 | CSG | channel with independent `[send]` and `[recv]` commands | **Rejected** when both players act in the same round: “multiple active commands”. |
| C2 | CSG | channel over joint actions (`[send,recv]` keeps n, `[send,idle]` push, `[idle,recv]` pop) | Works, also with a third player not mentioned in the lists; the order inside a joint list does not matter. |
| C3 | CSG | shared `global` counter updated by both players | **Accepted but wrong**: at n=1 the joint action `(send,recv)` leads to n=0. One update is silently lost. |
| D | MDP | FIFO carrying message values (D = 4 values) | States grow as D^N: 20, 84, 340, 1 364, 5 460, 21 844 for N = 1…6. |

### Lessons

1. In interleaving models (DTMC, MDP, CTMC) the transformation is cheap: one module, two (or three with
   DROP) commands, and the state space grows **linearly** with the capacity
   (IoT pipeline use case: 24, 36, 72, 132, 252 states for CAP = 1, 2, 5, 10, 20).
2. In CSGs, simultaneity is the whole difficulty: push and pop can happen in the same round. The only
   correct encoding we found is over joint actions. Its size is `1 + 2·|B\{r}| + |A\{s}|` commands
   (A, B = action sets of sender and receiver): linear in the number of actions, generated automatically.
3. Never use a shared global variable for communication between CSG players: PRISM-games accepts the
   model but drops one of the two updates (C3).
4. In a CSG a player cannot be blocked: if a channel is full the message is dropped (policy DROP);
   the "BLOCK" policy only exists for DTMC/MDP/CTMC.
5. In a CSG, a player's own update on `send` happens even when the partner does not choose `recv`.
   Communication effects that require both partners must be written in a non-player module over the
   joint action — exactly the Monitor pattern used in the bus and GPS games.
6. Carry message *values* only when they matter: a data FIFO costs D^N states, the counter abstraction N+1.
7. Steady-state properties of these CTMCs often do not converge with the default Jacobi method; use
   transient/cumulative properties (`C<=T`) or `-gaussseidel`.

## What the generator does

* **Port action**: each port carries a PRISM action (field *Action* in the properties panel, default:
  the port name). A connector whose port actions are not used by any command is kept as
  documentation only (as in the course use cases built before this version).
* **Sync connector, DTMC/MDP/CTMC**: endpoints with different action names are renamed to one label
  `sync_<a>_<b>` (union–find, so chains and broadcasts get a single label).
* **Sync connector, CSG**: a reward `rdv_<k>` counts the rendezvous `[a_s,a_r]`; a comment reminds that
  the effect belongs in a Monitor.
* **Async connector**: module `ch<k>` with counter `ch<k>_n : [0..CAP_ch<k>]`, labels `ch<k>_full`,
  `ch<k>_empty`, rewards `ch<k>_received` and (DROP) `ch<k>_lost`. Capacity and overflow policy are set
  on the connector; declaring a constant `CAP_ch<k>` overrides the capacity (useful as a use-case parameter).

## Use cases of this version

* *Sync vs async ports: IoT pipeline* (CTMC) — Sensor →sync→ Gateway →async→ Actuator.
  CAP = 2: 122.9 messages received and 51.1 lost over 100 s (loss ratio 0.29); with BLOCK, 132.4 received.
* *Async port in a game: producer / consumer* (CSG) — `<<prod>> Pmax=? [F ("ch1_full" & rounds<=k)]`
  = 0.998 (CAP 1), 0.965 (CAP 2), 0.031 (CAP 5), 0 (CAP 10).
