/**
 * Builds the course use cases (public/usecases/*.json) from the SERESSA 2026 lecture
 * "From Particle Strikes to Mission Dependability" (A. Baouya).
 *
 *   npm run usecases:build
 *
 * The JSON files are what the "Use Cases" tab loads at runtime: teachers can also add a
 * new use case by dropping a JSON file in public/usecases/ and listing it in index.json
 * (no rebuild of the application is needed).
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { UseCase, UseCaseIndexEntry } from '../src/types';
import {
  component, connect, constant, formula, label, model, monitor, property, reward, stateMachine,
} from './usecase-dsl';

const OUT = join(process.cwd(), 'public', 'usecases');

/* ------------------------------------------------------------------------------------------ */
/* 1. Radiation upsets and operator response — CTMC primer (Part 1 + slide "From Failure      */
/*    Data to Model Parameters": λ = 1/MTBF, μ = 1/MTTR)                                       */
/* ------------------------------------------------------------------------------------------ */
function radiationPrimer(): UseCase {
  const obc = component('SATELLITE', 'OBC', 80, 120, {
    width: 190, height: 120,
    ports: [{ name: 'reset', type: 'INPUT', side: 'RIGHT', offset: 60 }],
    stateMachine: stateMachine('obc', [
      { name: 'NOMINAL', value: 0, x: 120, y: 200 },
      { name: 'SEU', value: 1, x: 380, y: 80 },
      { name: 'SEFI', value: 2, x: 380, y: 320 },
    ], [
      { from: 'NOMINAL', to: 'SEU', updates: [['lambda_seu']] },
      { from: 'SEU', to: 'NOMINAL', updates: [['mu_scrub']] },
      { from: 'NOMINAL', to: 'SEFI', updates: [['lambda_sefi']] },
      { from: 'SEFI', to: 'NOMINAL', action: 'reset', updates: [['mu_reset']] },
    ]),
  });
  const op = component('STATION', 'Operator', 440, 120, {
    width: 190, height: 120,
    ports: [{ name: 'reset', type: 'OUTPUT', side: 'LEFT', offset: 60 }],
    stateMachine: stateMachine('op', [
      { name: 'ON_DUTY', value: 0, x: 150, y: 200 },
      { name: 'OFF_DUTY', value: 1, x: 420, y: 200 },
    ], [
      { from: 'ON_DUTY', to: 'OFF_DUTY', updates: [['lambda_off']] },
      { from: 'OFF_DUTY', to: 'ON_DUTY', updates: [['mu_on']] },
      // the reset is only possible while an operator is on duty (rate given by the OBC: 1 * mu_reset)
      { from: 'ON_DUTY', action: 'reset', updates: [[1]] },
    ]),
  });

  return {
    id: 'radiation-ctmc-primer',
    title: 'Radiation upsets and operator response',
    chapter: 'Part 1 — Context: radiation effects seen from the mission',
    chapterOrder: 1,
    formalism: 'ctmc',
    tool: 'PRISM 4.x (or PRISM-games)',
    prismOptions: '-gaussseidel',
    slides: 'Slides 5, 19',
    summary: 'A first CTMC: an on-board computer hit by SEUs (scrubbed automatically) and SEFIs (reset by a human operator who is not always on duty).',
    description: [
      'The on-board computer (OBC) is NOMINAL, suffers a Single Event Upset (SEU) that EDAC/scrubbing corrects, or a Single Event Functional Interrupt (SEFI) that needs a reset command.',
      'The reset is a synchronised action between the OBC and the Operator module: it can only happen while an operator is ON_DUTY. This is the right-hand side of the chain on slide 5: a device effect becomes an outage only if nobody repairs it in time.',
      'Rates follow slide 19: λ = 1/MTBF and μ = 1/MTTR. The default values are teaching values (hours) — replace them with SEE rates from radiation testing.',
    ],
    objectives: [
      'Translate MTBF / MTTR figures into CTMC rates.',
      'Understand synchronisation of rates in a CTMC (rate of [reset] = 1 × mu_reset).',
      'Read steady-state (S) and time-bounded (P, R with C<=T) CSL properties.',
    ],
    exercises: [
      'Halve MTTR_reset: how much does the steady-state availability improve?',
      'Set the operator always on duty (MTTF_shift very large): what is the gain? What does it cost in staff?',
      'Plot P=? [ F<=T "sefi" ] for T from 24 h to 8760 h (Experiments in PRISM).',
    ],
    parameters: [
      { name: 'MTBF_SEU', label: 'MTBF between SEUs', value: '48', unit: 'h', description: 'Mean time between two single event upsets on the OBC memory', source: 'Teaching value — use SEE rate σ·Φ from testing' },
      { name: 'MTTR_scrub', label: 'Scrubbing time', value: '0.1', unit: 'h', description: 'Mean time for EDAC / scrubbing to correct an SEU', source: 'Teaching value' },
      { name: 'MTBF_SEFI', label: 'MTBF between SEFIs', value: '2000', unit: 'h', description: 'Mean time between functional interrupts', source: 'Teaching value' },
      { name: 'MTTR_reset', label: 'Operator reset time', value: '4', unit: 'h', description: 'Mean time for the operator to diagnose and reset', source: 'Teaching value' },
      { name: 'MTTF_shift', label: 'Mean on-duty period', value: '8', unit: 'h', description: 'Mean time an operator stays on duty', source: 'Teaching value' },
      { name: 'MTTR_shift', label: 'Mean off-duty period', value: '16', unit: 'h', description: 'Mean time without operator', source: 'Teaching value' },
      { name: 'T', label: 'Mission time bound', value: '720', unit: 'h', description: 'Time bound of the transient properties (720 h = 1 month)' },
    ],
    model: model({
      modelType: 'ctmc',
      components: [obc, op],
      connectors: [connect(op, 'reset', obc, 'reset')],
      constants: [
        constant('MTBF_SEU', 'double', '48'),
        constant('MTTR_scrub', 'double', '0.1'),
        constant('MTBF_SEFI', 'double', '2000'),
        constant('MTTR_reset', 'double', '4'),
        constant('MTTF_shift', 'double', '8'),
        constant('MTTR_shift', 'double', '16'),
        constant('T', 'double', '720'),
        constant('lambda_seu', 'double', '1/MTBF_SEU'),
        constant('mu_scrub', 'double', '1/MTTR_scrub'),
        constant('lambda_sefi', 'double', '1/MTBF_SEFI'),
        constant('mu_reset', 'double', '1/MTTR_reset'),
        constant('lambda_off', 'double', '1/MTTF_shift'),
        constant('mu_on', 'double', '1/MTTR_shift'),
      ],
      labels: [
        label('up', 'obc=0'),
        label('seu', 'obc=1'),
        label('sefi', 'obc=2'),
      ],
      rewards: [
        reward('downtime', [{ guard: 'obc>0', reward: '1' }]),
        reward('resets', [{ action: 'reset', guard: 'true', reward: '1' }]),
      ],
      properties: [
        property('Availability', 'S=? [ "up" ]', 'long-run probability that the OBC is nominal'),
        property('SEFI within T', 'P=? [ F<=T "sefi" ]', 'probability of at least one SEFI within T'),
        property('Expected downtime', 'R{"downtime"}=? [ C<=T ]', 'expected time (h) without service up to T'),
        property('Expected resets', 'R{"resets"}=? [ C<=T ]', 'expected number of operator resets up to T'),
        property('Long-run downtime rate', 'R{"downtime"}=? [ S ]', 'fraction of time without service'),
      ],
    }),
  };
}

/* ------------------------------------------------------------------------------------------ */
/* 2. Bus write access — shared-resource CSG (Part 3, slides 17–18, hands-on slide 46)        */
/* ------------------------------------------------------------------------------------------ */
function busWriteAccess(): UseCase {
  const player = (i: 1 | 2, x: number) => component('BASIC', `Player${i}`, x, 60, {
    playerName: `p${i}`,
    ports: [{ name: 'bus', type: 'OUTPUT', side: i === 1 ? 'RIGHT' : 'LEFT', offset: 55 }],
    stateMachine: stateMachine(`ready${i}`, [{ name: 'READY', value: 0, x: 250, y: 200 }], [
      { from: 'READY', action: `w${i}`, guard: 's=0' },
      { from: 'READY', action: `r${i}`, guard: 's=0' },
      { from: 'READY', action: `unlock_${i}`, guard: 's=0' },
      { from: 'READY', action: `reset_${i}`, guard: 's>0' },
    ]),
  });
  const p1 = player(1, 40);
  const p2 = player(2, 620);
  const bus = component('MONITOR', 'CommunicationBus', 320, 60, {
    isPlayer: false,
    ports: [
      { name: 'in1', type: 'INPUT', side: 'LEFT', offset: 55 },
      { name: 'in2', type: 'INPUT', side: 'RIGHT', offset: 55 },
    ],
    monitorDefinition: monitor(
      [{ name: 's', min: 0, max: 10, init: 0 }, { name: 'win', min: 0, max: 2, init: 0 }],
      [
        { actions: ['unlock_1', 'unlock_2'], guard: 's=0', updates: [[1, { s: '0', win: '0' }]] },
        { actions: ['w1', 'w2'], guard: 's=0', updates: [[1, { s: '1', win: '0' }]] },
        { actions: ['r1', 'r2'], guard: 's=0', updates: [[1, { s: '1', win: '0' }]] },
        { actions: ['w1', 'r2'], guard: 's=0', updates: [[1, { s: '3', win: '1' }]] },
        { actions: ['r1', 'w2'], guard: 's=0', updates: [[1, { s: '2', win: '2' }]] },
        { actions: ['reset_1', 'reset_2'], guard: 's=1|s=2|s=3', updates: [[1, { s: '0', win: '0' }]] },
      ],
    ),
  });

  return {
    id: 'bus-write-access',
    title: 'Bus write access (shared resource)',
    chapter: 'Part 3 — Foundations: concurrent stochastic games',
    chapterOrder: 3,
    formalism: 'csg',
    tool: 'PRISM-games 3.x',
    slides: 'Slides 17, 18, 46',
    summary: 'Two players concurrently read or write a shared object (buffer of size 1). The writer who succeeds wins; same action at the same time: no winner.',
    description: [
      'Each player chooses, at the same time and without knowing the other\'s choice, to write (w), read (r) or keep the bus unlocked (unlock). A non-player Monitor (CommunicationBus) records the outcome in win.',
      '(w1, r2) gives the bus to player 1 (win = 1, +1 for player 1, −1 for player 2); (r1, w2) gives it to player 2; (w1, w2) and (r1, r2) end with no winner. (reset_1, reset_2) brings the game back to s = 0.',
      'The rounds module counts the rounds; k bounds the horizon of the properties.',
    ],
    objectives: [
      'Write concurrent joint actions [a1, a2] in a non-player module.',
      'Use rPATL coalitions: what can a player guarantee alone, and with a partner?',
      'Read action rewards as utilities.',
    ],
    exercises: [
      'Predict first: which of <<p1>> Pmax=? [F win=1] and <<p1,p2>> Pmax=? [F win=1] is 0? Then check.',
      'Compute the utility player 1 can guarantee over k rounds, then vary k.',
      'Add a third player p3: how many monitor commands do you need? How does the state space grow?',
    ],
    parameters: [
      { name: 'k', label: 'Number of rounds', value: '10', description: 'Horizon used by the rounds module and by the bounded properties' },
    ],
    model: model({
      modelType: 'csg',
      components: [p1, bus, p2],
      connectors: [connect(p1, 'bus', bus, 'in1'), connect(p2, 'bus', bus, 'in2')],
      constants: [constant('k', 'int', '10')],
      labels: [label('win1', 'win=1'), label('win2', 'win=2')],
      rewards: [
        reward('utility1', [
          { action: 'r1,w2', reward: '-1' },
          { action: 'r1,r2', reward: '0' },
          { action: 'w1,r2', reward: '1' },
          { action: 'w1,w2', reward: '0' },
        ]),
        reward('utility2', [
          { action: 'w1,r2', reward: '-1' },
          { action: 'r1,r2', reward: '0' },
          { action: 'r1,w2', reward: '1' },
          { action: 'w1,w2', reward: '0' },
        ]),
      ],
      properties: [
        property('P1 alone', '<<p1>> Pmax=? [ F win=1 ]', 'can player 1 force a win on its own? (expected: 0)'),
        property('Coalition', '<<p1,p2>> Pmax=? [ F win=1 ]', 'can the coalition make player 1 win? (expected: 1)'),
        property('P1 alone, bounded', '<<p1>> P>0.99 [ F win=1 ]', 'slide 17 — Boolean query'),
        property('Win within k rounds', '<<p1,p2>> Pmax=? [ F (win=1 & rounds<=k) ]', ''),
        property('Guaranteed utility of P1', '<<p1>> R{"utility1"}max=? [ F rounds=k ]', 'what player 1 can guarantee within k rounds, whatever p2 does'),
        property('Cooperative utility of P1', '<<p1,p2>> R{"utility1"}max=? [ F rounds=k ]', ''),
      ],
    }),
  };
}

/* ------------------------------------------------------------------------------------------ */
/* 3. GPS SPS collaborative maintenance — reduced CSG (Part 4, slides 23–31, 46)              */
/* ------------------------------------------------------------------------------------------ */
function gpsMaintenance(): UseCase {
  const svc = { name: 'mon', type: 'OUTPUT' as const, side: 'BOTTOM' as const, offset: 85 };
  const env = component('BASIC', 'Environment', 40, 40, {
    playerName: 'env', ports: [svc],
    stateMachine: stateMachine('env_ready', [{ name: 'ENV', value: 0, x: 280, y: 220 }], [
      { from: 'ENV', action: 'e_none', guard: 'sat=0' },
      { from: 'ENV', action: 'e_uns', guard: 'sat=0' },
      { from: 'ENV', action: 'e_st', guard: 'sat=0' },
      { from: 'ENV', action: 'e_lt', guard: 'sat=0' },
      { from: 'ENV', action: 'e_soft', guard: 'sat=0' },
      { from: 'ENV', action: 'e_wait', guard: 'sat>0' },
    ]),
  });
  const orbit = component('SATELLITE', 'OnOrbitStaff', 330, 40, {
    playerName: 'o', ports: [svc],
    stateMachine: stateMachine('o_ready', [{ name: 'PO', value: 0, x: 280, y: 220 }], [
      { from: 'PO', action: 'o_stby' },
      { from: 'PO', action: 'o_take', guard: 'sat=2' },
      { from: 'PO', action: 'o_switch', guard: '(sat=4 & ostage=0) | sat=7' },
      { from: 'PO', action: 'o_replace', guard: 'sat=4 & ostage=1' },
    ]),
  });
  const ground = component('STATION', 'OnGroundStaff', 620, 40, {
    playerName: 'g', ports: [svc],
    stateMachine: stateMachine('g_ready', [{ name: 'PG', value: 0, x: 280, y: 220 }], [
      { from: 'PG', action: 'g_stby' },
      { from: 'PG', action: 'g_take', guard: 'sat=2' },
      { from: 'PG', action: 'g_check', guard: 'sat=5 & gstage=0' },
      { from: 'PG', action: 'g_build', guard: 'sat=5 & gstage=1' },
      { from: 'PG', action: 'g_launch', guard: 'sat=5 & gstage=2' },
    ]),
  });
  const ow = 'o_stby', gw = 'g_stby';
  const mon = component('MONITOR', 'Maintenance', 330, 260, {
    isPlayer: false, width: 190,
    ports: [
      { name: 'env', type: 'INPUT', side: 'TOP', offset: 30 },
      { name: 'orbit', type: 'INPUT', side: 'TOP', offset: 95 },
      { name: 'ground', type: 'INPUT', side: 'TOP', offset: 160 },
    ],
    monitorDefinition: monitor(
      [
        { name: 'sat', min: 0, max: 7, init: 0 },
        { name: 'ostage', min: 0, max: 1, init: 0 },
        { name: 'gstage', min: 0, max: 2, init: 0 },
        { name: 'win', min: 0, max: 2, init: 0 },
        { name: 'last', min: 0, max: 2, init: 0 },
      ],
      [
        // NORMAL: the environment chooses which hazard it tries
        { actions: ['e_none', ow, gw], guard: 'sat=0', updates: [[1, { last: '0' }]] },
        { actions: ['e_uns', ow, gw], guard: 'sat=0', updates: [['pr_uns', { sat: '1', last: '0' }], ['1-pr_uns', { last: '0' }]] },
        { actions: ['e_st', ow, gw], guard: 'sat=0', updates: [['pr_st', { sat: '7', last: '0' }], ['1-pr_st', { last: '0' }]] },
        { actions: ['e_lt', ow, gw], guard: 'sat=0', updates: [['pr_lt', { sat: '2', last: '0' }], ['1-pr_lt', { last: '0' }]] },
        { actions: ['e_soft', ow, gw], guard: 'sat=0', updates: [['pr_soft', { sat: '3', last: '0' }], ['1-pr_soft', { last: '0' }]] },
        // unscheduled interruption: self-correcting, no human action needed
        { actions: ['e_wait', ow, gw], guard: 'sat=1', updates: [[1, { sat: '0' }]] },
        // soft failure: alerted in time (AMSI) or not (UMSI = loss of integrity)
        { actions: ['e_wait', ow, gw], guard: 'sat=3', updates: [['1-p_umsi', { sat: '0' }], ['p_umsi', { sat: '6' }]] },
        { actions: ['e_wait', ow, gw], guard: 'sat=6', updates: [[1, { sat: '0' }]] },
        // hard failure: which team takes the task? (slides 28, 30)
        { actions: ['e_wait', 'o_take', gw], guard: 'sat=2', updates: [[1, { sat: '4', win: '1', ostage: '0' }]] },
        { actions: ['e_wait', ow, 'g_take'], guard: 'sat=2', updates: [[1, { sat: '5', win: '2', gstage: '0' }]] },
        { actions: ['e_wait', 'o_take', 'g_take'], guard: 'sat=2', updates: [
          ['OnGroundPriority', { sat: '5', win: '2', gstage: '0' }],
          ['1-OnGroundPriority', { sat: '4', win: '1', ostage: '0' }],
        ] },
        // short-term hard failure: only the on-orbit staff can switch to a redundant subsystem
        { actions: ['e_wait', 'o_switch', gw], guard: 'sat=7', updates: [['Pbeta', { sat: '0', last: '1' }], ['1-Pbeta', {}]] },
        // long-term hard failure, on-orbit staff: switch / software commands, then move & replace a redundant satellite
        { actions: ['e_wait', 'o_switch', gw], guard: 'sat=4 & ostage=0', updates: [
          ['Pbeta*(1-p_eol)', { sat: '0', win: '0', last: '1' }],
          ['1-Pbeta*(1-p_eol)', { ostage: '1' }],
        ] },
        { actions: ['e_wait', 'o_replace', gw], guard: 'sat=4 & ostage=1', updates: [
          ['Pbeta', { sat: '0', win: '0', ostage: '0', last: '1' }],
          ['1-Pbeta', { sat: '5', win: '2', ostage: '0', gstage: '0' }],
        ] },
        // on-ground staff: check spare, build + manufacture (24 h + 24 h), launch
        { actions: ['e_wait', ow, 'g_check'], guard: 'sat=5 & gstage=0', updates: [['pr_build', { gstage: '1' }], ['1-pr_build', {}]] },
        { actions: ['e_wait', ow, 'g_build'], guard: 'sat=5 & gstage=1', updates: [[1, { gstage: '2' }]] },
        { actions: ['e_wait', ow, 'g_launch'], guard: 'sat=5 & gstage=2', updates: [
          ['Pn', { sat: '0', win: '0', gstage: '0', last: '2' }],
          ['1-Pn', {}],
        ] },
      ],
    ),
  });

  const lossC = 'sat=1 | sat=2 | sat=4 | sat=5 | sat=7';
  return {
    id: 'gps-sps-maintenance',
    title: 'GPS SPS collaborative maintenance (reduced CSG)',
    chapter: 'Part 4 — Case study 1: GPS SPS with humans in the loop',
    chapterOrder: 4,
    formalism: 'csg',
    tool: 'PRISM-games 3.x',
    slides: 'Slides 23–31, 46',
    summary: 'Reduced teaching version of the GPS game: Environment vs. on-orbit staff (Po) vs. on-ground staff (Pg), arbitrated by a non-player Monitor. Probabilities are generated from the GPS SPS parameters.',
    description: [
      'Three players act concurrently each round: the Environment (env) tries a hazard — unscheduled interruption, short-term or long-term hard failure, soft failure; the on-orbit staff (o) and the on-ground staff (g) decide whether to take a failure and how to repair it.',
      'Short-term hard failure: only Po can repair it, by switching to a redundant subsystem (success Pbeta). Long-term hard failure: if both teams take the task, the Monitor allocates it with OnGroundPriority (slide 30). Po switches to a redundant subsystem / sends software commands (success Pbeta, unless the satellite is at end of life, p_eol), then tries to move & replace a redundant satellite (Pbeta). If that fails, the task goes to Pg: check spare (pr_build), build + manufacture, launch (Pn).',
      'Per-round failure probabilities are derived from the MTBFs with p_fail = 1 − e^(−t/MTBF) (slide 19), t being the duration of a round. Change t_round or an MTBF and the whole model is regenerated.',
      'This is a reduced model written for the hands-on session (a few hundred states): it keeps the structure of the journal model but not its full detail (24 slots, O&M degradation, costs), so the numbers differ from the paper\'s figures.',
    ],
    objectives: [
      'Model humans as strategic players, not as failure probabilities.',
      'Isolate the contribution of each team by comparing the coalitions <<env,o>>, <<env,g>>, <<env,o,g>>.',
      'Sweep a human priority (OnGroundPriority) and observe the trade-off.',
    ],
    exercises: [
      'Compare PRO5, PRO6 and PRO7: which team reaches the reliability target first?',
      'Sweep OnGroundPriority from 0 to 1 (PRISM Experiments) and compare <<env,o>> R{"replace"} with <<env,g>> R{"manufacture"}.',
      'Lower Pbeta to 0.5: how does the load move to the on-ground staff?',
      'Bonus: duplicate OnOrbitStaff into a second on-orbit player and watch the state space grow (slide 37).',
    ],
    parameters: [
      { name: 'k', label: 'Number of rounds', value: '30', description: 'Horizon of the properties (slides use k = 1 … 30)' },
      { name: 't_round', label: 'Duration of a round', value: '0.5', unit: 'years', description: '30 rounds × 0.5 y = 15-year design life', source: 'Teaching choice' },
      { name: 'MTBF_ST', label: 'Short-term hard failure MTBF', value: '0.5', unit: 'years', description: 'Handled by the on-orbit staff only (switch to a redundant subsystem)', source: 'GPS SPS PS — slide 26' },
      { name: 'MTBF_LT', label: 'Long-term hard failure MTBF', value: '15', unit: 'years', source: 'GPS SPS PS — slide 26' },
      { name: 'MTBF_SOFT', label: 'Soft failure MTBF', value: '7.5', unit: 'years', source: 'GPS SPS PS — slide 26' },
      { name: 'pr_uns', label: 'P(unscheduled interruption) per round', value: '0.1', description: 'Radiation-induced, self-correcting interruption', source: 'Teaching value' },
      { name: 'p_umsi', label: 'P(soft failure not alerted in time)', value: '1e-5', description: 'Unalerted misleading signal information = loss of integrity', source: 'Slide 26 (NTE without timely alert)' },
      { name: 'p_eol', label: 'End-of-life probability', value: '0.6', source: 'Slide 26' },
      { name: 'Pbeta', label: 'On-orbit repair success (pβ)', value: '0.8', source: 'Slide 26' },
      { name: 'pr_build', label: 'P(spare available on ground)', value: '0.9', source: 'Teaching value' },
      { name: 'Pn', label: 'Launch success (pn)', value: '0.9', source: 'Slide 26' },
      { name: 'OnGroundPriority', label: 'On-ground priority', value: '0.5', description: 'Probability that the ground team gets the task when both teams take it (swept from 0 to 1)', source: 'Slide 30' },
    ],
    model: model({
      modelType: 'csg',
      components: [env, orbit, ground, mon],
      connectors: [connect(env, 'mon', mon, 'env'), connect(orbit, 'mon', mon, 'orbit'), connect(ground, 'mon', mon, 'ground')],
      constants: [
        constant('k', 'int', '30'),
        constant('t_round', 'double', '0.5'),
        constant('MTBF_ST', 'double', '0.5'),
        constant('MTBF_LT', 'double', '15'),
        constant('MTBF_SOFT', 'double', '7.5'),
        constant('EULER', 'double', '2.718281828459045'),
        constant('pr_st', 'double', '1 - pow(EULER, -t_round/MTBF_ST)'),
        constant('pr_lt', 'double', '1 - pow(EULER, -t_round/MTBF_LT)'),
        constant('pr_soft', 'double', '1 - pow(EULER, -t_round/MTBF_SOFT)'),
        constant('pr_uns', 'double', '0.1'),
        constant('p_umsi', 'double', '1e-5'),
        constant('p_eol', 'double', '0.6'),
        constant('Pbeta', 'double', '0.8'),
        constant('pr_build', 'double', '0.9'),
        constant('Pn', 'double', '0.9'),
        constant('OnGroundPriority', 'double', '0.5'),
      ],
      labels: [
        label('normal', 'sat=0'),
        label('Loss_Continuity', lossC),
        label('Loss_Integrity', 'sat=6'),
        label('replace', 'last=1'),
        label('manufacture', 'last=2'),
      ],
      rewards: [
        reward('Loss_Continuity', [{ guard: lossC, reward: '1' }]),
        reward('Loss_Integrity', [{ guard: 'sat=6', reward: '1' }]),
        reward('replace', [{ guard: 'last=1', reward: '1' }]),
        reward('manufacture', [{ guard: 'last=2', reward: '1' }]),
        reward('replaceOrManufacture', [{ guard: 'last>0', reward: '1' }]),
      ],
      properties: [
        property('PRO1 Continuity', '<<env>> Pmax=? [ F ("Loss_Continuity" & rounds<=k) ]'),
        property('PRO2 Continuity (expected)', '<<env>> R{"Loss_Continuity"}max=? [ F rounds=k ]', 'expected rounds without service within k rounds'),
        property('PRO3 Integrity', '<<env>> Pmax=? [ F ("Loss_Integrity" & rounds<=k) ]'),
        property('PRO4 Integrity (expected)', '<<env>> R{"Loss_Integrity"}max=? [ F rounds=k ]'),
        property('PRO5 Reliability, on-orbit staff', '<<env,o>> Pmax=? [ F ("replace" & rounds<=k) ]'),
        property('PRO6 Reliability, on-ground staff', '<<env,g>> Pmax=? [ F ("manufacture" & rounds<=k) ]'),
        property('PRO7 Reliability, both teams', '<<env,o,g>> Pmax=? [ F (("replace" | "manufacture") & rounds<=k) ]'),
        property('PRO8 Maintainability, on-orbit', '<<env,o>> R{"replace"}max=? [ F rounds=k ]'),
        property('PRO8b Maintainability, on-ground', '<<env,g>> R{"manufacture"}max=? [ F rounds=k ]'),
        property('PRO9 Maintainability, both teams', '<<env,o,g>> R{"replaceOrManufacture"}max=? [ F rounds=k ]'),
        property('Humans vs. environment', '<<o,g>> R{"Loss_Continuity"}min=? [ F rounds=k ]', 'outage the two teams can guarantee against a worst-case environment — the same zero-sum game as PRO2, hence the same value'),
      ],
    }),
  };
}

/* ------------------------------------------------------------------------------------------ */
/* 4. Galileo SAR under jamming — CTMC (Part 5, slides 39–42)                                 */
/* ------------------------------------------------------------------------------------------ */
function galileoJamming(): UseCase {
  const twoState = (
    type: Parameters<typeof component>[0], name: string, x: number, y: number,
    v: string, s0: string, s1: string, up: string, down: string, guardUp?: string,
  ) => component(type, name, x, y, {
    stateMachine: stateMachine(v, [
      { name: s0, value: 0, x: 150, y: 200 },
      { name: s1, value: 1, x: 450, y: 200 },
    ], [
      { from: s0, to: s1, guard: guardUp, updates: [[down]] },
      { from: s1, to: s0, updates: [[up]] },
    ]),
  });
  const sat = twoState('SATELLITE', 'Satellite', 40, 40, 'SAT', 'OPERATIONAL', 'DEGRADED', 'mu_sat', 'lambda_sat');
  const sig = twoState('BASIC', 'Signal', 300, 40, 'SIG', 'OPERATIONAL', 'DEGRADED', 'mu_sig', 'lambda_sig');
  const att = twoState('ATTACKER', 'Attack', 40, 240, 'ATT', 'NO_ATTACK', 'JAMMED', 'mu_jam', 'lambda_jam');
  const def = twoState('GATEWAY', 'Defence', 300, 240, 'DEF', 'IDLE', 'NULLING', 'mu_null', 'lambda_null', '!REACTIVE | ATT=JAMMED');

  return {
    id: 'galileo-sar-jamming',
    title: 'Galileo SAR link under jamming (CTMC)',
    chapter: 'Part 5 — Case study 2: Galileo SAR under jamming',
    chapterOrder: 5,
    formalism: 'ctmc',
    tool: 'PRISM 4.x (or PRISM-games)',
    slides: 'Slides 39–42',
    summary: 'Four CTMC modules (Satellite, Signal, Attack, Defence) and one service formula. The jammer (SPARTA EX-0016) is countered by antenna nulling (CM0083) at rate λnull = α·λjam.',
    description: [
      'Each module alternates between two states with exponential rates (slide 40): Satellite and Signal fail and recover; the Attack module switches between NO_ATTACK and JAMMED with λjam = 1/MTTA and μjam = 1/2; the Defence module activates nulling at λnull = α·λjam and stops at μnull = 1/2.',
      'The service is up when satellite and signal are healthy and either no attack is active, or nulling is active during the attack: formula system_up.',
      'α scales the defence rate relative to the attack rate (α = 1: same rate; α > 1: faster defence). REACTIVE = false keeps the four modules independent as on slide 40; REACTIVE = true lets nulling start only while the link is jammed.',
      'Nobody decides in this model (fixed attack and defence rates), which is why a CTMC is enough (slide 13).',
      'Rates span ten orders of magnitude (10⁻⁸ … 1): iterative steady-state solvers do not converge, so the properties use transient (U<=T, F<=T) and cumulative (C<=T) analysis.',
    ],
    objectives: [
      'Build a CTMC from rates (λ = 1/MTBF, μ = 1/MTTR) and a service formula.',
      'Write CSL properties: time-bounded until, steady state, cumulative rewards.',
      'Study the effect of α and of the attack frequency (MTTA) on resilience.',
    ],
    exercises: [
      'Run P=? [ "up" U<=T !"up" ] for α = 1, 2, 5, 10: are the curves parallel when α = 1?',
      'Increase MTTA (rarer attacks): how fast does the effect of jamming fade?',
      'Compare the expected defence reward with the 5.85 % defended/total signals of the GNU Radio simulation (slide 42).',
      'Set REACTIVE = true: what changes, and why?',
      'Check the long-run signal availability μsig / (λsig + μsig) with the slide-40 rates against the 99.22 % of slide 39. What do you conclude?',
    ],
    parameters: [
      { name: 'lambda_sat', label: 'Satellite failure rate λ', value: '2.03e-8', source: 'Slide 40' },
      { name: 'mu_sat', label: 'Satellite recovery rate μ', value: '4.03e-6', source: 'Slide 40' },
      { name: 'lambda_sig', label: 'Signal degradation rate λsig', value: '1e-3', source: 'Slide 40' },
      { name: 'mu_sig', label: 'Signal recovery rate μsig', value: '8.7e-6', source: 'Slide 40' },
      { name: 'MTTA', label: 'Mean time to attack (MTTA)', value: '10', description: 'λjam = 1/MTTA', source: 'Teaching value' },
      { name: 'mu_jam', label: 'Jamming end rate μjam', value: '0.5', source: 'Slide 40 (1/2)' },
      { name: 'alpha', label: 'Defence/attack rate ratio α', value: '10', source: 'Slides 40, 42' },
      { name: 'mu_null', label: 'Nulling end rate μnull', value: '0.5', source: 'Slide 40 (1/2)' },
      { name: 'REACTIVE', label: 'Reactive defence', value: 'false', description: 'true: nulling only starts while jammed' },
      { name: 'T', label: 'Time bound T', value: '100', description: 'Same time unit as the rates' },
    ],
    model: model({
      modelType: 'ctmc',
      components: [sat, sig, att, def],
      constants: [
        constant('OPERATIONAL', 'int', '0'), constant('DEGRADED', 'int', '1'),
        constant('NO_ATTACK', 'int', '0'), constant('JAMMED', 'int', '1'),
        constant('IDLE', 'int', '0'), constant('NULLING', 'int', '1'),
        constant('lambda_sat', 'double', '2.03e-8'),
        constant('mu_sat', 'double', '4.03e-6'),
        constant('lambda_sig', 'double', '1e-3'),
        constant('mu_sig', 'double', '8.7e-6'),
        constant('MTTA', 'double', '10'),
        constant('lambda_jam', 'double', '1/MTTA'),
        constant('mu_jam', 'double', '0.5'),
        constant('alpha', 'double', '10'),
        constant('lambda_null', 'double', 'alpha*lambda_jam'),
        constant('mu_null', 'double', '0.5'),
        constant('REACTIVE', 'bool', 'false'),
        constant('T', 'double', '100'),
      ],
      formulas: [
        formula('system_up', '(SAT=OPERATIONAL) & (SIG=OPERATIONAL) & ((ATT=NO_ATTACK) | (ATT=JAMMED & DEF=NULLING))'),
      ],
      labels: [
        label('up', 'system_up'),
        label('jammed', 'ATT=JAMMED'),
        label('defended', 'ATT=JAMMED & DEF=NULLING'),
      ],
      rewards: [
        reward('defense', [{ guard: 'ATT=JAMMED & DEF=NULLING', reward: '1' }]),
        reward('downtime', [{ guard: '!system_up', reward: '1' }]),
      ],
      properties: [
        property('Degraded within T', 'P=? [ "up" U<=T !"up" ]', 'slide 40 — probability that the service goes down within T'),
        property('Jammed within T', 'P=? [ F<=T "jammed" ]'),
        property('Availability over [0,T]', '1 - R{"downtime"}=? [ C<=T ] / T', 'mean fraction of [0,T] with the service up'),
        property('Expected defence reward', 'R{"defense"}=? [ C<=T ] / T', 'fraction of [0,T] spent jammed AND defended (compare with slide 42)'),
        property('Expected downtime', 'R{"downtime"}=? [ C<=T ]'),
      ],
    }),
  };
}

/* ------------------------------------------------------------------------------------------ */
mkdirSync(OUT, { recursive: true });
const cases = [radiationPrimer(), busWriteAccess(), gpsMaintenance(), galileoJamming()];
const index: UseCaseIndexEntry[] = [];
for (const uc of cases) {
  const file = `${uc.id}.json`;
  writeFileSync(join(OUT, file), JSON.stringify(uc, null, 2) + '\n');
  index.push({ id: uc.id, file });
  console.log(`wrote public/usecases/${file}`);
}
writeFileSync(join(OUT, 'index.json'), JSON.stringify({ version: 1, usecases: index }, null, 2) + '\n');
console.log('wrote public/usecases/index.json');
