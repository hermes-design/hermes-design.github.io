/**
 * Small DSL used by build-usecases.ts to author course use cases in a compact way.
 * The output is a plain ArchitectureModel (the same JSON the modeler saves/loads).
 */
import { v4 as uuidv4 } from 'uuid';
import {
  ArchitectureModel, CPCComponent, ComponentType, Connector, Constant, Label, Formula,
  RewardStructure, PropertySpec, ModelType, StateMachine, MonitorDefinition, Port,
} from '../src/types';

export type Upd = [string | number, Record<string, string>?];

export interface SMState { name: string; value: number; x: number; y: number }
export interface SMTrans { from: string; to?: string; action?: string; guard?: string; updates?: Upd[] }

export function stateMachine(
  stateVar: string,
  states: SMState[],
  transitions: SMTrans[],
  variables: { name: string; min: number; max: number; init: number }[] = [],
): StateMachine {
  const ids = new Map<string, string>();
  const st = states.map(s => {
    const id = uuidv4();
    ids.set(s.name, id);
    return { id, name: s.name, variableName: stateVar, value: s.value, x: s.x, y: s.y };
  });
  return {
    variables: variables.map(v => ({ id: uuidv4(), ...v })),
    states: st,
    transitions: transitions.map((t, i) => ({
      id: uuidv4(),
      sourceStateId: ids.get(t.from)!,
      targetStateId: ids.get(t.to ?? t.from)!,
      action: t.action,
      guard: t.guard,
      updates: (t.updates ?? [[1]]).map(([p, a]) => ({ probability: p, assignments: a ?? {} })),
      // spread self-loops a bit so that they stay readable in the state-machine editor
      waypoints: undefined,
    })),
  };
}

export interface MonTrans { actions: string[]; guard: string; updates: Upd[] }

export function monitor(
  variables: { name: string; min: number; max: number; init: number }[],
  transitions: MonTrans[],
): MonitorDefinition {
  return {
    variables: variables.map(v => ({ id: uuidv4(), ...v })),
    transitions: transitions.map(t => ({
      id: uuidv4(),
      actions: t.actions,
      guard: t.guard,
      updates: t.updates.map(([p, a]) => ({ probability: p, assignments: a ?? {} })),
    })),
  };
}

export function component(
  type: ComponentType,
  name: string,
  x: number,
  y: number,
  opts: {
    ports?: { name: string; type: 'INPUT' | 'OUTPUT'; side: Port['side']; offset: number }[];
    stateMachine?: StateMachine;
    monitorDefinition?: MonitorDefinition;
    playerName?: string;
    isPlayer?: boolean;
    width?: number;
    height?: number;
  },
): CPCComponent {
  return {
    id: uuidv4(),
    type,
    name,
    x: x + 80, // keep clear of the canvas toolbar
    y: y + 20,
    width: opts.width ?? 170,
    height: opts.height ?? 110,
    ports: (opts.ports ?? []).map(p => ({ id: uuidv4(), commMode: 'SYNCHRONOUS', ...p })),
    properties: {
      ...(opts.playerName ? { playerName: opts.playerName } : {}),
      ...(opts.isPlayer === false ? { isPlayer: false } : {}),
    },
    stateMachine: opts.stateMachine,
    monitorDefinition: opts.monitorDefinition,
  };
}

export function connect(a: CPCComponent, aPort: string, b: CPCComponent, bPort: string): Connector {
  return {
    id: uuidv4(),
    sourceComponentId: a.id,
    sourcePortId: a.ports.find(p => p.name === aPort)!.id,
    targetComponentId: b.id,
    targetPortId: b.ports.find(p => p.name === bPort)!.id,
    type: 'PUSH',
  };
}

export const constant = (name: string, type: Constant['type'], value?: string): Constant =>
  ({ id: uuidv4(), name, type, value });
export const label = (name: string, expression: string): Label => ({ id: uuidv4(), name, expression });
export const formula = (name: string, expression: string): Formula => ({ id: uuidv4(), name, expression });
export const property = (name: string, formula: string, description?: string): PropertySpec =>
  ({ id: uuidv4(), name, formula, description });

export function reward(name: string, items: { action?: string; guard?: string; reward: string }[]): RewardStructure {
  return { id: uuidv4(), name, items: items.map(i => ({ id: uuidv4(), ...i })) };
}

export function model(m: {
  modelType: ModelType;
  includeRounds?: boolean;
  components: CPCComponent[];
  connectors?: Connector[];
  constants?: Constant[];
  formulas?: Formula[];
  labels?: Label[];
  rewards?: RewardStructure[];
  properties?: PropertySpec[];
}): ArchitectureModel {
  return {
    modelType: m.modelType,
    includeRounds: m.includeRounds,
    components: m.components,
    connectors: m.connectors ?? [],
    constants: m.constants ?? [],
    formulas: m.formulas ?? [],
    labels: m.labels ?? [],
    rewards: m.rewards ?? [],
    properties: m.properties ?? [],
  };
}
