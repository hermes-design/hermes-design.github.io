import React from 'react';
import { CPCComponent, Connector, CommunicationMode, Port } from '../types';
import { 
  Settings, 
  Trash2, 
  Plus, 
  X, 
  ArrowRight, 
  Table as TableIcon, 
  Copy,
  Info,
  Activity,
  Layers,
  Link as LinkIcon,
  Maximize2,
  RefreshCw,
  Image as ImageIcon,
  Upload,
  RotateCcw
} from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface PropertiesPanelProps {
  selectedElement: CPCComponent | Connector | null;
  onUpdateComponent: (comp: CPCComponent) => void;
  onUpdateConnector: (conn: Connector) => void;
  onDelete: (id: string) => void;
  onDuplicateComponent: (id: string) => void;
  onEditBehavior: (id: string) => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  selectedElement,
  onUpdateComponent,
  onUpdateConnector,
  onDelete,
  onDuplicateComponent,
  onEditBehavior,
}) => {
  if (!selectedElement) {
    return (
      <div className="w-80 bg-[#fbfbfb] border-l border-neutral-200 p-8 flex flex-col items-center justify-center text-center">
        <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-neutral-100 flex items-center justify-center mb-6">
          <Settings className="w-8 h-8 text-neutral-300" />
        </div>
        <h3 className="text-neutral-900 font-semibold mb-2">No Selection</h3>
        <p className="text-sm text-neutral-500 leading-relaxed max-w-[200px]">
          Select a component or connector on the canvas to view and edit its properties.
        </p>
      </div>
    );
  }

  const isComponent = 'ports' in selectedElement;
  const component = isComponent ? selectedElement as CPCComponent : null;
  const connector = !isComponent ? selectedElement as Connector : null;

  const handleAddPort = (mode: CommunicationMode) => {
    if (!component) return;
    const newPort: Port = {
      id: uuidv4(),
      name: `p${component.ports.length + 1}`,
      type: component.ports.length % 2 === 0 ? 'OUTPUT' : 'INPUT',
      commMode: mode,
    };
    onUpdateComponent({
      ...component,
      ports: [...component.ports, newPort],
    });
  };

  const handleRemovePort = (portId: string) => {
    if (!component) return;
    onUpdateComponent({
      ...component,
      ports: component.ports.filter((p) => p.id !== portId),
    });
  };

  const handleUpdatePort = (portId: string, updates: Partial<Port>) => {
    if (!component) return;
    onUpdateComponent({
      ...component,
      ports: component.ports.map((p) => (p.id === portId ? { ...p, ...updates } : p)),
    });
  };

  return (
    <div className="w-80 bg-white border-l border-neutral-200 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="p-5 border-b border-neutral-100 flex items-center justify-between bg-[#fdfdfd]">
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isComponent ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'}`}>
            {isComponent ? <Layers className="w-4 h-4" /> : <LinkIcon className="w-4 h-4" />}
          </div>
          <div>
            <h3 className="text-sm font-bold text-neutral-900">
              {isComponent ? 'Component' : 'Connector'}
            </h3>
            <p className="text-[10px] text-neutral-400 font-medium uppercase tracking-wider">
              {isComponent ? component?.type : connector?.type}
            </p>
          </div>
        </div>
        <div className="flex gap-1">
          {component && (
            <button
              onClick={() => onDuplicateComponent(component.id)}
              className="p-2 text-neutral-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
              title="Duplicate"
            >
              <Copy className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => onDelete(selectedElement.id)}
            className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-8 custom-scrollbar">
        {component ? (
          <>
            {/* General Section */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Info className="w-3.5 h-3.5 text-neutral-400" />
                <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">General</h4>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-[11px] font-medium text-neutral-500 mb-1.5 ml-1">Name</label>
                  <input
                    type="text"
                    value={component.name}
                    onChange={(e) => onUpdateComponent({ ...component, name: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                    placeholder="Component name..."
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-medium text-neutral-500 mb-1.5 ml-1">Width</label>
                    <input
                      type="number"
                      value={component.width || 120}
                      onChange={(e) => onUpdateComponent({ ...component, width: parseInt(e.target.value) || 120 })}
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-neutral-500 mb-1.5 ml-1">Height</label>
                    <input
                      type="number"
                      value={component.height || Math.max(80, component.ports.length * 20 + 30)}
                      onChange={(e) => onUpdateComponent({ ...component, height: parseInt(e.target.value) || 80 })}
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* Visuals Section */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <ImageIcon className="w-3.5 h-3.5 text-neutral-400" />
                <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Visuals</h4>
              </div>
              <div className="space-y-4">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-medium text-neutral-500 ml-1">Component Icon</label>
                    {component.icon && (
                      <button
                        onClick={() => onUpdateComponent({ ...component, icon: undefined })}
                        className="text-[10px] font-bold text-red-500 hover:text-red-600 flex items-center gap-1 transition-colors"
                      >
                        <RotateCcw className="w-3 h-3" />
                        Reset to Default
                      </button>
                    )}
                  </div>
                  
                  <div 
                    className="relative group cursor-pointer"
                    onClick={() => document.getElementById('icon-upload')?.click()}
                    onDragOver={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                    onDrop={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      const file = e.dataTransfer.files?.[0];
                      if (file && file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          onUpdateComponent({ ...component, icon: reader.result as string });
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  >
                    <div className="w-full h-24 bg-neutral-50 border-2 border-dashed border-neutral-200 rounded-xl flex flex-col items-center justify-center gap-2 group-hover:border-blue-400 group-hover:bg-blue-50/30 transition-all overflow-hidden">
                      {component.icon ? (
                        <img 
                          src={component.icon} 
                          alt="Custom Icon" 
                          className="w-full h-full object-contain p-2"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <>
                          <Upload className="w-5 h-5 text-neutral-300 group-hover:text-blue-400 transition-colors" />
                          <span className="text-[10px] font-bold text-neutral-400 group-hover:text-blue-500 uppercase tracking-wider">Upload Image</span>
                        </>
                      )}
                    </div>
                    <input
                      id="icon-upload"
                      type="file"
                      accept="image/png, image/jpeg, image/gif"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            onUpdateComponent({ ...component, icon: reader.result as string });
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </div>
                  <p className="text-[9px] text-neutral-400 italic text-center">Supports PNG, JPEG, GIF. Max 2MB recommended.</p>
                </div>
              </div>
            </section>

            {/* Properties Section */}
            {component.type === 'ATTACKER' && (
              <section>
                <div className="flex items-center gap-2 mb-4">
                  <Activity className="w-3.5 h-3.5 text-neutral-400" />
                  <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Properties</h4>
                </div>
                <div className="space-y-5 bg-neutral-50/50 p-4 rounded-xl border border-neutral-100">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-[11px] font-medium text-neutral-600">Success Rate</label>
                      <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                        {Math.round((component.properties.successRate || 0.5) * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={component.properties.successRate || 0.5}
                      onChange={(e) => onUpdateComponent({
                        ...component,
                        properties: { ...component.properties, successRate: parseFloat(e.target.value) }
                      })}
                      className="w-full h-1.5 bg-neutral-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                  </div>
                </div>
              </section>
            )}

            {/* Ports Section */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Maximize2 className="w-3.5 h-3.5 text-neutral-400" />
                  <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Interface</h4>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => onUpdateComponent({
                      ...component,
                      ports: component.ports.map(p => ({ ...p, side: undefined, offset: undefined }))
                    })}
                    className="p-1.5 bg-neutral-50 text-neutral-500 hover:bg-neutral-100 rounded-md transition-colors"
                    title="Reset All Ports to Auto-Distribution"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleAddPort('SYNCHRONOUS')}
                    className="p-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-md transition-colors"
                    title="Add Sync Port"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleAddPort('ASYNCHRONOUS')}
                    className="p-1.5 bg-purple-50 text-purple-600 hover:bg-purple-100 rounded-md transition-colors"
                    title="Add Async Port"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                {component.ports.length === 0 ? (
                  <div className="py-8 border-2 border-dashed border-neutral-100 rounded-xl flex flex-col items-center justify-center text-neutral-400">
                    <p className="text-[10px] font-medium">No ports defined</p>
                  </div>
                ) : (
                  component.ports.map((port, idx) => (
                    <div key={port.id} className="group relative bg-white border border-neutral-200 rounded-xl p-3 shadow-sm hover:border-blue-200 transition-all">
                      <button
                        onClick={() => handleRemovePort(port.id)}
                        className="absolute -top-2 -right-2 w-5 h-5 bg-white border border-neutral-200 text-neutral-400 hover:text-red-500 hover:border-red-200 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all shadow-sm z-10"
                      >
                        <X className="w-3 h-3" />
                      </button>
                      
                      <div className="flex items-center gap-2 mb-3">
                        <input
                          type="text"
                          value={port.name}
                          onChange={(e) => handleUpdatePort(port.id, { name: e.target.value })}
                          className="flex-1 min-w-0 bg-transparent text-xs font-bold text-neutral-700 outline-none focus:text-blue-600"
                          placeholder="Port name"
                        />
                        <div className={`text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter ${port.type === 'INPUT' ? 'bg-emerald-50 text-emerald-600' : 'bg-orange-50 text-orange-600'}`}>
                          {port.type}
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <select
                          value={port.commMode}
                          onChange={(e) => handleUpdatePort(port.id, { commMode: e.target.value as any })}
                          className={`text-[10px] font-bold px-2 py-1 rounded-md outline-none cursor-pointer transition-colors ${
                            port.commMode === 'SYNCHRONOUS' 
                              ? 'bg-blue-50 text-blue-700 hover:bg-blue-100' 
                              : 'bg-purple-50 text-purple-700 hover:bg-purple-100'
                          }`}
                        >
                          <option value="SYNCHRONOUS">SYNC</option>
                          <option value="ASYNCHRONOUS">ASYNC</option>
                        </select>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleUpdatePort(port.id, { side: undefined, offset: undefined })}
                            className="p-1 text-neutral-300 hover:text-neutral-500 transition-colors"
                            title="Reset Position"
                          >
                            <RefreshCw className="w-3 h-3" />
                          </button>
                          <select
                            value={port.type}
                            onChange={(e) => handleUpdatePort(port.id, { type: e.target.value as any })}
                            className="text-[10px] text-neutral-400 bg-transparent border-none outline-none cursor-pointer hover:text-neutral-600"
                          >
                            <option value="INPUT">Input</option>
                            <option value="OUTPUT">Output</option>
                          </select>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 mt-3">
                        <div className="flex flex-col gap-1">
                          <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-wider">Side</label>
                          <select
                            value={port.side || (port.type === 'INPUT' ? 'LEFT' : 'RIGHT')}
                            onChange={(e) => handleUpdatePort(port.id, { side: e.target.value as any })}
                            className="text-[10px] bg-neutral-50 border border-neutral-200 rounded px-2 py-1 outline-none"
                          >
                            <option value="LEFT">Left</option>
                            <option value="RIGHT">Right</option>
                            <option value="TOP">Top</option>
                            <option value="BOTTOM">Bottom</option>
                          </select>
                        </div>
                        <div className="flex flex-col gap-1">
                          <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-wider">Offset</label>
                          <input
                            type="number"
                            value={port.offset !== undefined ? port.offset : (50 + idx * 20)}
                            onChange={(e) => handleUpdatePort(port.id, { offset: parseInt(e.target.value) })}
                            className="text-[10px] bg-neutral-50 border border-neutral-200 rounded px-2 py-1 outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </section>

            {/* Actions Section */}
            <section className="pt-4">
              <button
                onClick={() => onEditBehavior(component.id)}
                className={`w-full group relative overflow-hidden p-4 rounded-xl transition-all shadow-sm hover:shadow-md active:scale-[0.98] ${
                  component.type === 'MONITOR' 
                    ? 'bg-cyan-600 text-white' 
                    : 'bg-blue-600 text-white'
                }`}
              >
                <div className="relative z-10 flex items-center justify-center gap-3">
                  {component.type === 'MONITOR' ? (
                    <TableIcon className="w-4 h-4 opacity-80" />
                  ) : (
                    <ArrowRight className="w-4 h-4 opacity-80" />
                  )}
                  <span className="text-sm font-bold tracking-tight">
                    {component.type === 'MONITOR' ? 'Edit Monitor Table' : 'Edit Behavior'}
                  </span>
                </div>
                <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
              <p className="text-[10px] text-neutral-400 mt-3 text-center leading-relaxed px-4 italic">
                {component.type === 'MONITOR' 
                  ? 'Define global transitions and multi-module synchronizations'
                  : 'Define states, transitions and probabilistic updates (PRISM)'}
              </p>
            </section>
          </>
        ) : connector ? (
          <>
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Info className="w-3.5 h-3.5 text-neutral-400" />
                <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Configuration</h4>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-[11px] font-medium text-neutral-500 mb-1.5 ml-1">Connector Type</label>
                  <select
                    value={connector.type}
                    onChange={(e) => onUpdateConnector({ ...connector, type: e.target.value as any })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                  >
                    <option value="PUSH">Push</option>
                    <option value="PULL">Pull</option>
                    <option value="UPDATE">Update</option>
                    <option value="COMPOSITION">Composition</option>
                  </select>
                </div>
              </div>
            </section>

            <section>
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-3.5 h-3.5 text-neutral-400" />
                <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-widest">Routing</h4>
              </div>
              <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-100">
                <button
                  onClick={() => onUpdateConnector({ ...connector, waypoints: [] })}
                  className="w-full py-2.5 bg-white border border-neutral-200 text-neutral-600 rounded-lg text-xs font-bold hover:bg-neutral-50 hover:border-neutral-300 transition-all shadow-sm active:scale-[0.98]"
                >
                  Reset Waypoints
                </button>
                <div className="mt-4 flex gap-3">
                  <div className="w-1 h-auto bg-blue-100 rounded-full" />
                  <p className="text-[10px] text-neutral-500 leading-relaxed italic">
                    Double-click the connector line to add a waypoint. Drag waypoints to adjust routing. Double-click a waypoint to remove it.
                  </p>
                </div>
              </div>
            </section>
          </>
        ) : null}
      </div>
    </div>
  );
};
