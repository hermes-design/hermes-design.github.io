export type ComponentType = 'SENSOR' | 'ACTUATOR' | 'GATEWAY' | 'ATTACKER' | 'SATELLITE' | 'STATION' | 'BASIC' | 'MONITOR';
export type CommunicationMode = 'SYNCHRONOUS' | 'ASYNCHRONOUS';

export interface Port {
  id: string;
  name: string;
  type: 'INPUT' | 'OUTPUT';
  commMode: CommunicationMode;
  side?: 'LEFT' | 'RIGHT' | 'TOP' | 'BOTTOM';
  offset?: number; // Distance from the start of the side
}

export interface StateVariable {
  id: string;
  name: string;
  min: number;
  max: number;
  init: number;
}

export interface State {
  id: string;
  name: string;
  variableName?: string; // Optional variable name (e.g., 's')
  value?: number; // Optional state value (e.g., 0, 1, 2)
  x: number;
  y: number;
  radius?: number;
}

export interface ProbabilisticUpdate {
  probability: string | number; // 0 to 1 or constant name/expression
  assignments: { [varName: string]: string }; // e.g., { "s": "1" }
}

export interface StateTransition {
  id: string;
  sourceStateId: string;
  targetStateId: string;
  action?: string; // Synchronized action name
  guard?: string; // Boolean condition
  updates: ProbabilisticUpdate[];
  waypoints?: { x: number; y: number }[];
}

export interface StateMachine {
  variables: StateVariable[];
  states: State[];
  transitions: StateTransition[];
}

export interface MonitorTransition {
  id: string;
  actions: string[]; // [action1, action2, ..., actionN]
  guard: string; // e.g., "s = 1"
  updates: ProbabilisticUpdate[]; // e.g., (s' = 2) & (win' = 2)
}

export interface MonitorDefinition {
  variables: StateVariable[];
  transitions: MonitorTransition[];
}

export interface CPCComponent {
  id: string;
  type: ComponentType;
  name: string;
  x: number;
  y: number;
  width?: number;
  height?: number;
  ports: Port[];
  properties: {
    frequency?: number;
    successRate?: number;
    energyConsumption?: number;
    initialState?: string;
    /** CSG only: name used in the `player ... endplayer` block (e.g. env, o, g). Defaults to p<i>. */
    playerName?: string;
    /** CSG only: set to false for non-player modules that have a state machine. */
    isPlayer?: boolean;
  };
  stateMachine?: StateMachine;
  monitorDefinition?: MonitorDefinition;
  icon?: string; // Icon name or URL
}

export interface Connector {
  id: string;
  sourceComponentId: string;
  sourcePortId: string;
  targetComponentId: string;
  targetPortId: string;
  type: 'PUSH' | 'PULL' | 'UPDATE' | 'COMPOSITION';
  waypoints?: { x: number; y: number }[];
}

export interface RewardItem {
  id: string;
  action?: string;
  guard?: string;
  reward: string;
}

export interface RewardStructure {
  id: string;
  name: string;
  items: RewardItem[];
}

export interface Constant {
  id: string;
  name: string;
  type: 'int' | 'double' | 'bool';
  value?: string;
}

export interface Label {
  id: string;
  name: string;
  expression: string;
}

export interface Formula {
  id: string;
  name: string;
  expression: string;
}

/** Target PRISM model type. CSG = PRISM-games concurrent stochastic game, CTMC = continuous-time Markov chain. */
export type ModelType = 'csg' | 'ctmc' | 'mdp' | 'dtmc';

/** A temporal-logic property exported to the .props file (rPATL for CSG, CSL for CTMC, PCTL for DTMC/MDP). */
export interface PropertySpec {
  id: string;
  name?: string;
  formula: string;
  description?: string;
}

export interface ArchitectureModel {
  /** Defaults to 'csg' for backward compatibility with older project files. */
  modelType?: ModelType;
  /** CSG only: emit the `rounds` counter module (default true). */
  includeRounds?: boolean;
  properties?: PropertySpec[];
  components: CPCComponent[];
  connectors: Connector[];
  rewards: RewardStructure[];
  constants: Constant[];
  labels: Label[];
  formulas: Formula[];
}

/** An editable parameter of a use case; it overrides the value of the constant with the same name. */
export interface UseCaseParameter {
  name: string;          // name of the PRISM constant
  label: string;
  value: string;
  unit?: string;
  description?: string;
  source?: string;       // where the number comes from (slide, standard, ...)
}

/** A course use case, loaded at runtime from public/usecases/*.json */
export interface UseCase {
  id: string;
  title: string;
  chapter: string;       // e.g. "Part 3 — Foundations"
  chapterOrder: number;
  formalism: ModelType;
  tool: string;          // e.g. "PRISM-games 3.x" or "PRISM 4.x"
  prismOptions?: string; // recommended command-line options (e.g. -gaussseidel)
  slides?: string;
  summary: string;
  description: string[];
  objectives?: string[];
  exercises?: string[];
  parameters: UseCaseParameter[];
  model: ArchitectureModel;
}

export interface UseCaseIndexEntry {
  id: string;
  file: string;
}
